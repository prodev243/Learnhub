// Returns the list of banks Paystack supports for the platform currency.
import { corsHeaders, errorResponse, json } from '../_shared/cors.ts';
import { paystackRequest, platformCurrency, requireUser } from '../_shared/paystack.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    await requireUser(req);
    const currency = platformCurrency();
    const res = await paystackRequest(`/bank?currency=${currency}&perPage=200`);
    const banks = (res.data as { name: string; code: string }[])
      .map((b) => ({ name: b.name, code: b.code }))
      .sort((a, b) => a.name.localeCompare(b.name));
    return json({ banks });
  } catch (err) {
    return errorResponse(err);
  }
});
