// Called by the browser right after the Paystack popup reports success.
// We never trust the browser: we ask Paystack directly and check amount + currency.
import { corsHeaders, errorResponse, HttpError, json } from '../_shared/cors.ts';
import { adminClient, paystackRequest, requireUser } from '../_shared/paystack.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  try {
    const user = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const reference = typeof body?.reference === 'string' ? body.reference.trim() : '';
    if (!/^[A-Za-z0-9_.=-]{6,100}$/.test(reference)) throw new HttpError(400, 'Invalid payment reference.');

    const admin = adminClient();
    const { data: payment, error } = await admin
      .from('payments')
      .select('id, status, payer_id')
      .eq('reference', reference)
      .maybeSingle();
    if (error || !payment) throw new HttpError(404, 'Payment not found.');
    if (payment.payer_id !== user.id) throw new HttpError(403, 'This payment belongs to another account.');
    if (payment.status === 'success') return json({ status: 'success' });

    const verified = await paystackRequest(`/transaction/verify/${encodeURIComponent(reference)}`);
    const tx = verified.data;

    if (tx?.status === 'success') {
      const { data: result, error: rpcErr } = await admin.rpc('confirm_payment', {
        p_reference: reference,
        p_amount_minor: tx.amount,
        p_currency: tx.currency,
      });
      if (rpcErr) {
        console.error(rpcErr);
        throw new HttpError(500, 'Payment received but could not be recorded. Please contact support.');
      }
      if (result === 'amount_mismatch') throw new HttpError(400, 'The amount paid does not match this milestone. Please contact support.');
      return json({ status: 'success', result });
    }

    if (tx?.status === 'failed' || tx?.status === 'abandoned') {
      await admin.from('payments').update({ status: tx.status }).eq('id', payment.id).eq('status', 'pending');
    }
    return json({ status: tx?.status ?? 'pending' });
  } catch (err) {
    return errorResponse(err);
  }
});
