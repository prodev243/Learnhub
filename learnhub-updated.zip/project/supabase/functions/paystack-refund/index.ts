import { corsHeaders, errorResponse, HttpError, json } from '../_shared/cors.ts';
import { adminClient, paystackRequest, requireUser } from '../_shared/paystack.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const user = await requireUser(req);
    const admin = adminClient();
    const { data: adminRow } = await admin.from('app_admins').select('user_id').eq('user_id', user.id).maybeSingle();
    if (!adminRow) throw new HttpError(403, 'Admin access required.');
    const body = await req.json().catch(() => ({}));
    const paymentId = typeof body?.payment_id === 'string' ? body.payment_id : '';
    const amount = body?.amount == null ? null : Number(body.amount);
    if (!paymentId) throw new HttpError(400, 'Payment id is required.');

    const { data: payment } = await admin.from('payments').select('id,reference,amount,status,refund_status').eq('id', paymentId).maybeSingle();
    if (!payment) throw new HttpError(404, 'Payment not found.');
    if (payment.status !== 'success') throw new HttpError(400, 'Only successful payments can be refunded.');
    if (payment.refund_status === 'refunded' || payment.refund_status === 'processing') throw new HttpError(409, 'This payment already has a refund in progress.');

    const refundAmount = amount == null ? Number(payment.amount) : Math.round(amount * 100) / 100;
    if (!Number.isFinite(refundAmount) || refundAmount <= 0 || refundAmount > Number(payment.amount)) throw new HttpError(400, 'Invalid refund amount.');

    await admin.from('payments').update({ refund_status: 'processing' }).eq('id', payment.id);
    try {
      const response = await paystackRequest('/refund', { method: 'POST', body: JSON.stringify({ transaction: payment.reference, amount: Math.round(refundAmount * 100) }) });
      await admin.from('refunds').insert({ payment_id: payment.id, requested_by: user.id, amount: refundAmount, status: 'refunded', paystack_response: response.data ?? response, completed_at: new Date().toISOString() });
      await admin.from('payments').update({ refund_status: 'refunded', refunded_amount: refundAmount, refunded_at: new Date().toISOString() }).eq('id', payment.id);
      return json({ ok: true, status: 'refunded', amount: refundAmount });
    } catch (e) {
      await admin.from('payments').update({ refund_status: 'failed' }).eq('id', payment.id);
      await admin.from('refunds').insert({ payment_id: payment.id, requested_by: user.id, amount: refundAmount, status: 'failed', paystack_response: { error: String(e) } });
      throw e;
    }
  } catch (err) { return errorResponse(err); }
});
