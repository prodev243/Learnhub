import { createClient } from 'npm:@supabase/supabase-js@2';
import { HttpError } from './cors.ts';

const PAYSTACK_API = 'https://api.paystack.co';

/** Currencies Paystack supports whose smallest unit is 1/100 (kobo, pesewa, cent...). */
const SUPPORTED_CURRENCIES = ['NGN', 'GHS', 'ZAR', 'KES', 'USD'];

export function paystackSecret(): string {
  const key = Deno.env.get('PAYSTACK_SECRET_KEY');
  if (!key) throw new HttpError(500, 'Payments are not configured yet (missing PAYSTACK_SECRET_KEY).');
  return key;
}

export function platformCurrency(): string {
  const c = (Deno.env.get('PAYSTACK_CURRENCY') ?? 'NGN').toUpperCase();
  if (!SUPPORTED_CURRENCIES.includes(c)) {
    throw new HttpError(500, `Unsupported PAYSTACK_CURRENCY "${c}". Use one of: ${SUPPORTED_CURRENCIES.join(', ')}.`);
  }
  return c;
}

/** Service-role client: bypasses RLS. Only ever used inside edge functions. */
export function adminClient() {
  const url = Deno.env.get('SUPABASE_URL');
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) throw new HttpError(500, 'Server is missing Supabase credentials.');
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

/** Resolve the logged-in user from the request's bearer token. */
export async function requireUser(req: Request) {
  const token = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '').trim();
  if (!token) throw new HttpError(401, 'Please log in first.');
  const { data, error } = await adminClient().auth.getUser(token);
  if (error || !data.user) throw new HttpError(401, 'Your session has expired. Please log in again.');
  return data.user;
}

export async function paystackRequest(path: string, init: RequestInit = {}) {
  const res = await fetch(`${PAYSTACK_API}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${paystackSecret()}`,
      'Content-Type': 'application/json',
      ...(init.headers ?? {}),
    },
  });
  const body = await res.json().catch(() => null);
  if (!res.ok || !body || body.status === false) {
    console.error('Paystack error', res.status, body);
    throw new HttpError(502, body?.message ?? 'Paystack could not process this request.');
  }
  return body;
}

export function toMinorUnits(amount: number): number {
  return Math.round(amount * 100);
}

export function isUuid(v: unknown): v is string {
  return typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
}

/** Hex HMAC-SHA512 of `payload` using `secret` (used to verify Paystack webhooks). */
export async function hmacSha512Hex(secret: string, payload: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-512' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(payload));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** Constant-time string comparison. */
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
