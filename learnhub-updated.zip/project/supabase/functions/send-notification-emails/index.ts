import { corsHeaders, errorResponse, HttpError, json } from '../_shared/cors.ts';
import { adminClient } from '../_shared/paystack.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const admin = adminClient();
    const secret = Deno.env.get('RESEND_API_KEY');
    const from = Deno.env.get('RESEND_FROM_EMAIL') || 'LearnHub <notifications@example.com>';
    if (!secret) throw new HttpError(503, 'Email provider is not configured.');
    const { data: jobs, error } = await admin.from('email_jobs').select('id,user_id,notification_id,attempts').eq('status','pending').lt('attempts',5).order('created_at',{ascending:true}).limit(25);
    if (error) throw error;
    let sent = 0;
    for (const job of jobs ?? []) {
      await admin.from('email_jobs').update({ status:'processing', attempts:Number(job.attempts)+1 }).eq('id',job.id).eq('status','pending');
      const [{ data:n }, { data:authUser }] = await Promise.all([
        admin.from('notifications').select('title,body,href').eq('id',job.notification_id).maybeSingle(),
        admin.auth.admin.getUserById(job.user_id),
      ]);
      const email = authUser.user?.email;
      if (!email || !n) { await admin.from('email_jobs').update({ status:'failed', last_error:'No email address or notification found.' }).eq('id',job.id); continue; }
      const origin = Deno.env.get('APP_ORIGIN') || '';
      const link = n.href && origin ? `${origin}${n.href}` : origin;
      const html = `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto"><h2>${escapeHtml(n.title)}</h2><p>${escapeHtml(n.body)}</p>${link ? `<p><a href="${escapeHtml(link)}">Open LearnHub</a></p>` : ''}</div>`;
      const response = await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${secret}`,'Content-Type':'application/json'},body:JSON.stringify({from,to:[email],subject:`LearnHub: ${n.title}`,html})});
      if (!response.ok) { const detail=await response.text(); await admin.from('email_jobs').update({status:'failed',last_error:detail.slice(0,500)}).eq('id',job.id); continue; }
      await admin.from('email_jobs').update({status:'sent',sent_at:new Date().toISOString(),last_error:null}).eq('id',job.id); sent++;
    }
    return json({ok:true,sent});
  } catch (err) { return errorResponse(err); }
});
function escapeHtml(value:string):string { return value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]??c)); }
