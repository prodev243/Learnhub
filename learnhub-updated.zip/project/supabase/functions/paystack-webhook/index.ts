// Paystack -> LearnHub. Safety net so a milestone is funded even if the student closes the
// tab right after paying. Authenticity is proven by the HMAC-SHA512 signature, not a JWT.
import { hmacSha512Hex, adminClient, paystackSecret, safeEqual } from '../_shared/paystack.ts';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });

  try {
    const raw = await req.text();
    const signature = req.headers.get('x-paystack-signature') ?? '';
    const expected = await hmacSha512Hex(paystackSecret(), raw);
    if (!signature || !safeEqual(signature.toLowerCase(), expected)) {
      return new Response('Invalid signature', { status: 401 });
    }

    const event = JSON.parse(raw);
    if (event?.event === 'charge.success' && event.data?.reference) {
      const { error } = await adminClient().rpc('confirm_payment', {
        p_reference: event.data.reference,
        p_amount_minor: event.data.amount,
        p_currency: event.data.currency,
      });
      if (error) {
        console.error('confirm_payment failed', error);
        return new Response('Error', { status: 500 }); // Paystack will retry
      }
    }
    return new Response('ok', { status: 200 });
  } catch (err) {
    console.error('Webhook error', err);
    return new Response('Error', { status: 500 });
  }
});
