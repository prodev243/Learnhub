import { corsHeaders, errorResponse, HttpError, json } from '../_shared/cors.ts';
import { adminClient, requireUser } from '../_shared/paystack.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error:'Method not allowed' },405);
  try {
    const user = await requireUser(req);
    const admin = adminClient();
    const { error: softError } = await admin.rpc('soft_delete_my_account', { });
    // SECURITY DEFINER RPC uses auth.uid(), which is not present on service-role calls.
    // Apply the same policy after validating the caller with requireUser.
    if (softError) {
      const { data: active } = await admin.from('contracts').select('id').or(`student_id.eq.${user.id},tutor_id.eq.${user.id}`).eq('status','active').limit(1);
      if (active?.length) throw new HttpError(409,'Complete or resolve your active contracts before deleting your account.');
      await admin.from('profiles').update({ full_name:'Deleted user', avatar_url:null, deleted_at:new Date().toISOString() }).eq('id',user.id);
      await admin.from('tutor_profiles').update({ is_published:false, headline:'', bio:'', location:'', categories:[], skills:[], price_from:0, guarantee:null, verification_status:'unsubmitted' }).eq('user_id',user.id);
      await admin.from('messages').update({ body:'[deleted]' }).eq('sender_id',user.id);
      await admin.from('conversations').update({ last_message:'[deleted]' }).or(`user_a.eq.${user.id},user_b.eq.${user.id}`);
    }
    // Disable future sign-ins while retaining the auth identity needed for historical accounting records.
    await admin.auth.admin.updateUserById(user.id, { ban_duration: '876000h', user_metadata: { account_deleted: true } });
    return json({ ok:true, mode:'anonymized', message:'Your personal profile has been anonymized. Financial and contract records are retained where required for accounting and dispute handling.' });
  } catch (err) { return errorResponse(err); }
});
