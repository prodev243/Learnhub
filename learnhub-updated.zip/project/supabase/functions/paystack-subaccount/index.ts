// Creates (or updates) the Paystack subaccount that receives a tutor's share of every payment.
// The bank account number is sent to Paystack and is NOT stored by LearnHub (only the last 4 digits).
import { corsHeaders, errorResponse, HttpError, json } from '../_shared/cors.ts';
import { adminClient, paystackRequest, requireUser } from '../_shared/paystack.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  try {
    const user = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const bankCode = typeof body?.bank_code === 'string' ? body.bank_code.trim() : '';
    const bankName = typeof body?.bank_name === 'string' ? body.bank_name.trim().slice(0, 80) : '';
    const accountNumber = typeof body?.account_number === 'string' ? body.account_number.replace(/\s+/g, '') : '';
    if (!/^[A-Za-z0-9-]{2,20}$/.test(bankCode)) throw new HttpError(400, 'Choose your bank.');
    if (!/^\d{8,12}$/.test(accountNumber)) throw new HttpError(400, 'Enter a valid account number.');

    const admin = adminClient();

    const { data: profile } = await admin.from('profiles').select('role, full_name').eq('id', user.id).maybeSingle();
    if (!profile || profile.role !== 'tutor') throw new HttpError(403, 'Only tutors can add payout details.');

    const { data: cfg } = await admin.from('app_config').select('value').eq('key', 'commission_percent').maybeSingle();
    const commission = Math.min(99, Math.max(0, Number(cfg?.value) || 0));

    const { data: existing } = await admin
      .from('tutor_payout_accounts')
      .select('subaccount_code')
      .eq('user_id', user.id)
      .maybeSingle();

    const payload = {
      business_name: `${profile.full_name} (LearnHub tutor)`.slice(0, 100),
      settlement_bank: bankCode,
      account_number: accountNumber,
      percentage_charge: commission,
    };

    const res = existing
      ? await paystackRequest(`/subaccount/${encodeURIComponent(existing.subaccount_code)}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        })
      : await paystackRequest('/subaccount', { method: 'POST', body: JSON.stringify(payload) });

    const code: string | undefined = res.data?.subaccount_code ?? existing?.subaccount_code;
    if (!code) throw new HttpError(502, 'Paystack did not return a payout account.');

    const { error } = await admin.from('tutor_payout_accounts').upsert({
      user_id: user.id,
      subaccount_code: code,
      bank_code: bankCode,
      bank_name: bankName,
      account_last4: accountNumber.slice(-4),
      business_name: payload.business_name,
      updated_at: new Date().toISOString(),
    });
    if (error) {
      console.error(error);
      throw new HttpError(500, 'Could not save your payout details.');
    }

    return json({ ok: true, bank_name: bankName, account_last4: accountNumber.slice(-4) });
  } catch (err) {
    return errorResponse(err);
  }
});
