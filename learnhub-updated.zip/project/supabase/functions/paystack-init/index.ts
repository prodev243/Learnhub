// Creates a Paystack transaction for ONE milestone.
// The amount is read from the database — never from the browser — so it cannot be tampered with.
import { corsHeaders, errorResponse, HttpError, json } from '../_shared/cors.ts';
import {
  adminClient, isUuid, paystackRequest, platformCurrency, requireUser, toMinorUnits,
} from '../_shared/paystack.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  let createdPaymentId: string | null = null;
  try {
    const user = await requireUser(req);
    const body = await req.json().catch(() => ({}));
    const milestoneId = body?.milestone_id;
    if (!isUuid(milestoneId)) throw new HttpError(400, 'Invalid milestone.');
    if (!user.email) throw new HttpError(400, 'Your account has no email address.');

    const admin = adminClient();

    const { data: ms, error: msErr } = await admin
      .from('milestones')
      .select('id, contract_id, position, title, amount, status')
      .eq('id', milestoneId)
      .maybeSingle();
    if (msErr || !ms) throw new HttpError(404, 'Milestone not found.');

    const { data: contract, error: cErr } = await admin
      .from('contracts')
      .select('id, student_id, tutor_id, status')
      .eq('id', ms.contract_id)
      .maybeSingle();
    if (cErr || !contract) throw new HttpError(404, 'Contract not found.');

    if (contract.student_id !== user.id) throw new HttpError(403, 'Only the student on this contract can fund it.');
    if (contract.status !== 'active') throw new HttpError(400, 'This contract is no longer active.');
    if (ms.status !== 'pending') throw new HttpError(400, 'This milestone has already been funded.');

    // Milestones are funded in order: everything before this one must be released.
    const { count: unfinishedBefore, error: prevErr } = await admin
      .from('milestones')
      .select('id', { count: 'exact', head: true })
      .eq('contract_id', ms.contract_id)
      .lt('position', ms.position)
      .neq('status', 'released');
    if (prevErr) throw new HttpError(500, 'Could not check earlier milestones.');
    if ((unfinishedBefore ?? 0) > 0) throw new HttpError(400, 'Finish and approve the earlier milestone first.');

    // Any earlier, unfinished attempt for this milestone is now stale.
    await admin
      .from('payments')
      .update({ status: 'abandoned' })
      .eq('milestone_id', ms.id)
      .eq('status', 'pending');

    // The tutor's Paystack subaccount receives their share; LearnHub keeps the commission.
    const { data: payout } = await admin
      .from('tutor_payout_accounts')
      .select('subaccount_code')
      .eq('user_id', contract.tutor_id)
      .maybeSingle();
    if (!payout) throw new HttpError(400, "This tutor hasn't added payout details yet. Please message them.");

    const { data: cfg } = await admin.from('app_config').select('value').eq('key', 'commission_percent').maybeSingle();
    const commission = Math.min(99, Math.max(0, Number(cfg?.value) || 0));

    const currency = platformCurrency();
    const amount = Number(ms.amount);
    const reference = `lh_${crypto.randomUUID().replaceAll('-', '')}`;

    const { data: payment, error: payErr } = await admin
      .from('payments')
      .insert({
        milestone_id: ms.id,
        contract_id: ms.contract_id,
        payer_id: user.id,
        amount,
        currency,
        reference,
      })
      .select('id')
      .single();
    if (payment?.id) createdPaymentId = payment.id;
    if (payErr || !payment) {
      console.error(payErr);
      throw new HttpError(500, 'Could not start the payment.');
    }

    const init = await paystackRequest('/transaction/initialize', {
      method: 'POST',
      body: JSON.stringify({
        email: user.email,
        amount: toMinorUnits(amount),
        currency,
        reference,
        subaccount: payout.subaccount_code,
        // Flat amount (in the smallest currency unit) that stays with LearnHub; the rest goes to the tutor.
        transaction_charge: Math.round(toMinorUnits(amount) * commission / 100),
        bearer: 'account',
        metadata: {
          payment_id: payment.id,
          milestone_id: ms.id,
          contract_id: ms.contract_id,
          custom_fields: [{ display_name: 'Milestone', variable_name: 'milestone', value: ms.title }],
        },
      }),
    });

    return json({
      access_code: init.data.access_code,
      reference: init.data.reference ?? reference,
      amount,
      currency,
    });
  } catch (err) {
    // If Paystack initialization fails after our local payment row was created, do not leave it pending.
    // The browser can safely retry and a new reference will be generated.
    if (createdPaymentId) { try { await adminClient().from('payments').update({ status: 'failed' }).eq('id', createdPaymentId).eq('status','pending'); } catch (_) { /* preserve original error */ } }
    return errorResponse(err);
  }
});
