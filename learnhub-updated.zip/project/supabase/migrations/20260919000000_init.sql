-- =============================================================================
-- LearnHub — database schema, security rules (RLS) and server-side functions
-- Run once in the Supabase SQL editor (or via `supabase db push`).
--
-- Design rules:
--   * Every table has Row Level Security enabled.
--   * Money / contract state is NEVER written directly by the browser. It only
--     changes through the SECURITY DEFINER functions at the bottom of this file
--     (and the Paystack edge functions, which use the service role).
--   * Browser-writable columns are restricted with column-level GRANTs so a user
--     cannot, for example, set their own tutor profile to "verified".
-- =============================================================================

-- ---------------------------------------------------------------------------
-- App configuration (read-only from the browser)
-- ---------------------------------------------------------------------------
create table public.app_config (
  key   text primary key,
  value text not null
);
insert into public.app_config (key, value) values ('commission_percent', '10');

-- ---------------------------------------------------------------------------
-- Profiles (one per auth user)
-- ---------------------------------------------------------------------------
create table public.profiles (
  id         uuid primary key references auth.users (id) on delete cascade,
  role       text not null check (role in ('student', 'tutor')),
  full_name  text not null check (char_length(full_name) between 1 and 80),
  created_at timestamptz not null default now()
);

create table public.tutor_profiles (
  user_id       uuid primary key references public.profiles (id) on delete cascade,
  headline      text not null default '' check (char_length(headline) <= 120),
  bio           text not null default '' check (char_length(bio) <= 3000),
  location      text not null default '' check (char_length(location) <= 80),
  categories    text[] not null default '{}'
                check (categories <@ array['Languages','Programming','Math','Music','Design','Exam Prep','Business']::text[]),
  skills        text[] not null default '{}' check (cardinality(skills) <= 12),
  price_from    numeric(12,2) not null default 0 check (price_from >= 0),
  guarantee     text check (guarantee is null or char_length(guarantee) <= 200),
  response_time text not null default '' check (char_length(response_time) <= 60),
  is_published  boolean not null default false,   -- computed by trigger
  verified      boolean not null default false,   -- only an admin can set this
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- Private payout details: the Paystack subaccount that receives a tutor's share.
-- Only the owner can read it; only the server (service role) can write it.
create table public.tutor_payout_accounts (
  user_id         uuid primary key references public.profiles (id) on delete cascade,
  subaccount_code text not null,
  bank_code       text not null,
  bank_name       text not null default '',
  account_last4   text not null,
  business_name   text not null default '',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- Auto-create a profile (and an empty tutor profile) when someone signs up.
-- The role can only ever be 'student' or 'tutor' — never anything privileged.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  r text;
  n text;
begin
  r := coalesce(new.raw_user_meta_data ->> 'role', 'student');
  if r not in ('student', 'tutor') then
    r := 'student';
  end if;
  n := left(coalesce(nullif(btrim(new.raw_user_meta_data ->> 'full_name'), ''), split_part(new.email, '@', 1)), 80);
  if n = '' then n := 'New user'; end if;

  insert into public.profiles (id, role, full_name) values (new.id, r, n);
  if r = 'tutor' then
    insert into public.tutor_profiles (user_id) values (new.id);
  end if;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- A tutor profile is "published" (visible in the directory, allowed to send
-- proposals) once the essentials are filled in. `verified` can only be changed
-- by an admin (requests without an end-user JWT, e.g. the Supabase dashboard).
create function public.tutor_profile_sync()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    if auth.uid() is not null then new.verified := false; end if;
  else
    if auth.uid() is not null then new.verified := old.verified; end if;
  end if;

  new.is_published := btrim(new.headline) <> ''
                      and char_length(btrim(new.bio)) >= 20
                      and cardinality(new.categories) > 0
                      and new.price_from > 0;
  new.updated_at := now();
  return new;
end;
$$;

create trigger tutor_profile_sync
  before insert or update on public.tutor_profiles
  for each row execute function public.tutor_profile_sync();

-- ---------------------------------------------------------------------------
-- Missions (learning goals)
-- ---------------------------------------------------------------------------
create table public.missions (
  id              uuid primary key default gen_random_uuid(),
  student_id      uuid not null references public.profiles (id) on delete cascade,
  title           text not null check (char_length(title) between 6 and 140),
  category        text not null check (category in ('Languages','Programming','Math','Music','Design','Exam Prep','Business')),
  level           text not null check (level in ('Beginner','Intermediate','Advanced')),
  budget          numeric(12,2) not null check (budget > 0),
  deadline        text not null default '' check (char_length(deadline) <= 60),
  availability    text not null default '' check (char_length(availability) <= 120),
  learning_style  text not null default '' check (char_length(learning_style) <= 160),
  description     text not null check (char_length(description) between 20 and 5000),
  status          text not null default 'open' check (status in ('open','in_progress','completed','cancelled')),
  proposals_count integer not null default 0,
  created_at      timestamptz not null default now()
);
create index missions_status_created_idx on public.missions (status, created_at desc);
create index missions_student_idx on public.missions (student_id);

-- ---------------------------------------------------------------------------
-- Proposals
-- ---------------------------------------------------------------------------
create table public.proposals (
  id           uuid primary key default gen_random_uuid(),
  mission_id   uuid not null references public.missions (id) on delete cascade,
  tutor_id     uuid not null references public.profiles (id) on delete cascade,
  cover_letter text not null check (char_length(cover_letter) between 20 and 3000),
  approach     text[] not null default '{}' check (cardinality(approach) <= 10),
  price        numeric(12,2) not null check (price > 0),
  timeline     text not null check (char_length(timeline) between 1 and 60),
  milestones   jsonb not null,
  status       text not null default 'pending' check (status in ('pending','accepted','rejected','withdrawn')),
  created_at   timestamptz not null default now(),
  unique (mission_id, tutor_id)
);
create index proposals_tutor_idx on public.proposals (tutor_id);

create function public.proposal_guard()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  mi    public.missions;
  el    jsonb;
  total numeric := 0;
begin
  select * into mi from public.missions where id = new.mission_id;
  if not found or mi.status <> 'open' then
    raise exception 'This goal is not accepting proposals';
  end if;
  if mi.student_id = new.tutor_id then
    raise exception 'You cannot send a proposal to your own goal';
  end if;
  if not exists (select 1 from public.tutor_profiles tp where tp.user_id = new.tutor_id and tp.is_published) then
    raise exception 'Complete your tutor profile before sending proposals';
  end if;
  if not exists (select 1 from public.tutor_payout_accounts pa where pa.user_id = new.tutor_id) then
    raise exception 'Add your bank details in Account settings before sending proposals';
  end if;
  if jsonb_typeof(new.milestones) <> 'array' or jsonb_array_length(new.milestones) not between 1 and 8 then
    raise exception 'Add between 1 and 8 milestones';
  end if;
  for el in select e from jsonb_array_elements(new.milestones) e loop
    if coalesce(btrim(el ->> 'title'), '') = '' then
      raise exception 'Every milestone needs a title';
    end if;
    if (el ->> 'amount') is null or (el ->> 'amount')::numeric <= 0 then
      raise exception 'Every milestone needs an amount greater than zero';
    end if;
    total := total + round((el ->> 'amount')::numeric, 2);
  end loop;
  if total <> new.price then
    raise exception 'Milestone amounts must add up to the proposal price';
  end if;
  return new;
end;
$$;

create trigger proposal_guard
  before insert on public.proposals
  for each row execute function public.proposal_guard();

create function public.proposals_recount()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  mid uuid;
begin
  if tg_op = 'DELETE' then mid := old.mission_id; else mid := new.mission_id; end if;
  update public.missions
     set proposals_count = (select count(*) from public.proposals where mission_id = mid and status <> 'withdrawn')
   where id = mid;
  return null;
end;
$$;

create trigger proposals_recount
  after insert or update or delete on public.proposals
  for each row execute function public.proposals_recount();

-- ---------------------------------------------------------------------------
-- Contracts, milestones, payments (written only by server-side functions)
-- ---------------------------------------------------------------------------
create table public.contracts (
  id          uuid primary key default gen_random_uuid(),
  mission_id  uuid not null unique references public.missions (id) on delete restrict,
  proposal_id uuid not null unique references public.proposals (id) on delete restrict,
  student_id  uuid not null references public.profiles (id) on delete restrict,
  tutor_id    uuid not null references public.profiles (id) on delete restrict,
  title       text not null,
  total       numeric(12,2) not null,
  status      text not null default 'active' check (status in ('active','completed','cancelled')),
  created_at  timestamptz not null default now()
);
create index contracts_student_idx on public.contracts (student_id);
create index contracts_tutor_idx on public.contracts (tutor_id);

create table public.milestones (
  id           uuid primary key default gen_random_uuid(),
  contract_id  uuid not null references public.contracts (id) on delete cascade,
  position     integer not null,
  title        text not null,
  detail       text not null default '',
  amount       numeric(12,2) not null check (amount > 0),
  status       text not null default 'pending' check (status in ('pending','funded','in_review','released')),
  platform_fee numeric(12,2),
  tutor_amount numeric(12,2),
  funded_at    timestamptz,
  submitted_at timestamptz,
  released_at  timestamptz,
  unique (contract_id, position)
);

create table public.payments (
  id           uuid primary key default gen_random_uuid(),
  milestone_id uuid not null references public.milestones (id) on delete restrict,
  contract_id  uuid not null references public.contracts (id) on delete restrict,
  payer_id     uuid not null references public.profiles (id) on delete restrict,
  amount       numeric(12,2) not null,
  currency     text not null,
  reference    text not null unique,
  status       text not null default 'pending' check (status in ('pending','success','failed','abandoned','duplicate')),
  paid_at      timestamptz,
  created_at   timestamptz not null default now()
);
create unique index payments_one_success_per_milestone on public.payments (milestone_id) where status = 'success';
create index payments_milestone_idx on public.payments (milestone_id);

-- ---------------------------------------------------------------------------
-- Reviews
-- ---------------------------------------------------------------------------
create table public.reviews (
  id            uuid primary key default gen_random_uuid(),
  contract_id   uuid not null unique references public.contracts (id) on delete cascade,
  student_id    uuid not null references public.profiles (id) on delete cascade,
  tutor_id      uuid not null references public.profiles (id) on delete cascade,
  mission_title text not null default '',
  rating        smallint not null check (rating between 1 and 5),
  clarity       smallint not null check (clarity between 1 and 5),
  improvement   smallint not null check (improvement between 1 and 5),
  reliability   smallint not null check (reliability between 1 and 5),
  patience      smallint not null check (patience between 1 and 5),
  body          text not null check (char_length(body) between 10 and 2000),
  created_at    timestamptz not null default now()
);
create index reviews_tutor_idx on public.reviews (tutor_id);

create function public.review_guard()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  c public.contracts;
begin
  select * into c from public.contracts where id = new.contract_id;
  if not found or c.student_id <> new.student_id or c.tutor_id <> new.tutor_id then
    raise exception 'You can only review a tutor you have worked with';
  end if;
  if c.status <> 'completed' then
    raise exception 'You can review a tutor once the contract is completed';
  end if;
  new.mission_title := c.title;
  return new;
end;
$$;

create trigger review_guard
  before insert on public.reviews
  for each row execute function public.review_guard();

-- ---------------------------------------------------------------------------
-- Saved items, invites
-- ---------------------------------------------------------------------------
create table public.saved_items (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  kind       text not null check (kind in ('mission', 'tutor')),
  target_id  uuid not null,
  created_at timestamptz not null default now(),
  primary key (user_id, kind, target_id)
);

create table public.mission_invites (
  mission_id uuid not null references public.missions (id) on delete cascade,
  tutor_id   uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (mission_id, tutor_id)
);
create index mission_invites_tutor_idx on public.mission_invites (tutor_id);

-- ---------------------------------------------------------------------------
-- Messaging
-- ---------------------------------------------------------------------------
create table public.conversations (
  id              uuid primary key default gen_random_uuid(),
  user_a          uuid not null references public.profiles (id) on delete cascade,
  user_b          uuid not null references public.profiles (id) on delete cascade,
  last_message    text not null default '',
  last_message_at timestamptz not null default now(),
  created_at      timestamptz not null default now(),
  check (user_a < user_b),
  unique (user_a, user_b)
);

create table public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  sender_id       uuid not null references public.profiles (id) on delete cascade,
  body            text not null check (char_length(btrim(body)) between 1 and 4000),
  created_at      timestamptz not null default now()
);
create index messages_conversation_idx on public.messages (conversation_id, created_at);

create function public.messages_after_insert()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.conversations
     set last_message = left(new.body, 140), last_message_at = new.created_at
   where id = new.conversation_id;
  return null;
end;
$$;

create trigger messages_after_insert
  after insert on public.messages
  for each row execute function public.messages_after_insert();

-- ---------------------------------------------------------------------------
-- Contests (created by an admin in the Supabase dashboard)
-- ---------------------------------------------------------------------------
create table public.contests (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  sponsor     text not null default 'LearnHub',
  category    text not null check (category in ('Languages','Programming','Math','Music','Design','Exam Prep','Business')),
  prize       numeric(12,2) not null default 0,
  description text not null,
  deadline    timestamptz not null,
  status      text not null default 'open' check (status in ('open','voting','completed')),
  created_at  timestamptz not null default now()
);

create table public.contest_entries (
  id          uuid primary key default gen_random_uuid(),
  contest_id  uuid not null references public.contests (id) on delete cascade,
  tutor_id    uuid not null references public.profiles (id) on delete cascade,
  title       text not null check (char_length(title) between 3 and 120),
  description text not null check (char_length(description) between 10 and 3000),
  votes       integer not null default 0,
  created_at  timestamptz not null default now(),
  unique (contest_id, tutor_id)
);

create table public.contest_votes (
  entry_id   uuid not null references public.contest_entries (id) on delete cascade,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (entry_id, user_id)
);

create function public.contest_entry_guard()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  c public.contests;
begin
  select * into c from public.contests where id = new.contest_id;
  if not found or c.status <> 'open' or c.deadline <= now() then
    raise exception 'This contest is no longer accepting entries';
  end if;
  if not exists (select 1 from public.profiles p where p.id = new.tutor_id and p.role = 'tutor') then
    raise exception 'Only tutors can enter contests';
  end if;
  return new;
end;
$$;

create trigger contest_entry_guard
  before insert on public.contest_entries
  for each row execute function public.contest_entry_guard();

create function public.contest_vote_guard()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  e public.contest_entries;
  c public.contests;
begin
  select * into e from public.contest_entries where id = new.entry_id;
  if not found then raise exception 'Entry not found'; end if;
  select * into c from public.contests where id = e.contest_id;
  if c.status not in ('open', 'voting') then
    raise exception 'Voting is closed for this contest';
  end if;
  if e.tutor_id = new.user_id then
    raise exception 'You cannot vote for your own entry';
  end if;
  return new;
end;
$$;

create trigger contest_vote_guard
  before insert on public.contest_votes
  for each row execute function public.contest_vote_guard();

create function public.contest_vote_count()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  eid uuid;
begin
  if tg_op = 'DELETE' then eid := old.entry_id; else eid := new.entry_id; end if;
  update public.contest_entries
     set votes = (select count(*) from public.contest_votes where entry_id = eid)
   where id = eid;
  return null;
end;
$$;

create trigger contest_vote_count
  after insert or delete on public.contest_votes
  for each row execute function public.contest_vote_count();

-- ---------------------------------------------------------------------------
-- Public tutor directory (aggregates ratings from reviews + finished contracts)
-- Runs with the view owner's rights on purpose: it only exposes published tutor
-- data and aggregate numbers, never private rows.
-- ---------------------------------------------------------------------------
create view public.tutor_directory as
select
  p.id,
  p.full_name,
  tp.headline,
  tp.bio,
  tp.location,
  tp.categories,
  tp.skills,
  tp.price_from,
  tp.guarantee,
  tp.response_time,
  tp.verified,
  coalesce(r.review_count, 0)::int as review_count,
  r.avg_rating,
  r.avg_clarity,
  r.avg_improvement,
  r.avg_reliability,
  r.avg_patience,
  coalesce(c.completed_count, 0)::int as completed_count
from public.profiles p
join public.tutor_profiles tp on tp.user_id = p.id
left join (
  select tutor_id,
         count(*)::int as review_count,
         avg(rating)::float8 as avg_rating,
         avg(clarity)::float8 as avg_clarity,
         avg(improvement)::float8 as avg_improvement,
         avg(reliability)::float8 as avg_reliability,
         avg(patience)::float8 as avg_patience
  from public.reviews
  group by tutor_id
) r on r.tutor_id = p.id
left join (
  select tutor_id, count(*)::int as completed_count
  from public.contracts
  where status = 'completed'
  group by tutor_id
) c on c.tutor_id = p.id
where tp.is_published;

-- =============================================================================
-- Row Level Security
-- =============================================================================
alter table public.app_config       enable row level security;
alter table public.profiles         enable row level security;
alter table public.tutor_profiles   enable row level security;
alter table public.tutor_payout_accounts enable row level security;
alter table public.missions         enable row level security;
alter table public.proposals        enable row level security;
alter table public.contracts        enable row level security;
alter table public.milestones       enable row level security;
alter table public.payments         enable row level security;
alter table public.reviews          enable row level security;
alter table public.saved_items      enable row level security;
alter table public.mission_invites  enable row level security;
alter table public.conversations    enable row level security;
alter table public.messages         enable row level security;
alter table public.contests         enable row level security;
alter table public.contest_entries  enable row level security;
alter table public.contest_votes    enable row level security;

-- app_config: readable by everyone, writable by nobody (edit in the dashboard)
create policy "config is public" on public.app_config for select to anon, authenticated using (true);

-- profiles: names/roles are public (shown on goals, proposals, reviews)
create policy "profiles are public" on public.profiles for select to anon, authenticated using (true);
create policy "update own profile" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- tutor_profiles
create policy "tutor profiles are public" on public.tutor_profiles for select to anon, authenticated using (true);
create policy "update own tutor profile" on public.tutor_profiles for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- payout accounts: owner can read (never write)
create policy "read own payout account" on public.tutor_payout_accounts for select to authenticated
  using (user_id = auth.uid());

-- missions
create policy "open goals are public" on public.missions for select to anon, authenticated
  using (status <> 'cancelled' or student_id = auth.uid());
create policy "students post goals" on public.missions for insert to authenticated
  with check (
    student_id = auth.uid()
    and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'student')
  );
create policy "owner can cancel open goal" on public.missions for update to authenticated
  using (student_id = auth.uid() and status = 'open')
  with check (student_id = auth.uid() and status in ('open', 'cancelled'));

-- proposals: visible to the proposing tutor and to the goal's owner only
create policy "see own or received proposals" on public.proposals for select to authenticated
  using (
    tutor_id = auth.uid()
    or exists (select 1 from public.missions m where m.id = mission_id and m.student_id = auth.uid())
  );
create policy "tutors send proposals" on public.proposals for insert to authenticated
  with check (
    tutor_id = auth.uid()
    and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'tutor')
  );
create policy "tutor can withdraw pending proposal" on public.proposals for update to authenticated
  using (tutor_id = auth.uid() and status = 'pending')
  with check (tutor_id = auth.uid() and status in ('pending', 'withdrawn'));

-- contracts / milestones / payments: parties can read, nobody can write directly
create policy "parties read contracts" on public.contracts for select to authenticated
  using (student_id = auth.uid() or tutor_id = auth.uid());
create policy "parties read milestones" on public.milestones for select to authenticated
  using (exists (select 1 from public.contracts c
                 where c.id = contract_id and (c.student_id = auth.uid() or c.tutor_id = auth.uid())));
create policy "parties read payments" on public.payments for select to authenticated
  using (payer_id = auth.uid()
         or exists (select 1 from public.contracts c where c.id = contract_id and c.tutor_id = auth.uid()));

-- reviews
create policy "reviews are public" on public.reviews for select to anon, authenticated using (true);
create policy "student reviews completed contract" on public.reviews for insert to authenticated
  with check (student_id = auth.uid());

-- saved items
create policy "own saved items" on public.saved_items for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- invites
create policy "see own or sent invites" on public.mission_invites for select to authenticated
  using (
    tutor_id = auth.uid()
    or exists (select 1 from public.missions m where m.id = mission_id and m.student_id = auth.uid())
  );
create policy "owner invites tutors to open goal" on public.mission_invites for insert to authenticated
  with check (
    exists (select 1 from public.missions m where m.id = mission_id and m.student_id = auth.uid() and m.status = 'open')
    and exists (select 1 from public.profiles p where p.id = tutor_id and p.role = 'tutor')
  );

-- messaging
create policy "read own conversations" on public.conversations for select to authenticated
  using (auth.uid() in (user_a, user_b));
create policy "read own messages" on public.messages for select to authenticated
  using (exists (select 1 from public.conversations c
                 where c.id = conversation_id and auth.uid() in (c.user_a, c.user_b)));
create policy "send own messages" on public.messages for insert to authenticated
  with check (
    sender_id = auth.uid()
    and exists (select 1 from public.conversations c
                where c.id = conversation_id and auth.uid() in (c.user_a, c.user_b))
  );

-- contests
create policy "contests are public" on public.contests for select to anon, authenticated using (true);
create policy "entries are public" on public.contest_entries for select to anon, authenticated using (true);
create policy "tutors enter contests" on public.contest_entries for insert to authenticated
  with check (tutor_id = auth.uid());
create policy "see own votes" on public.contest_votes for select to authenticated using (user_id = auth.uid());
create policy "cast own vote" on public.contest_votes for insert to authenticated with check (user_id = auth.uid());
create policy "remove own vote" on public.contest_votes for delete to authenticated
  using (
    user_id = auth.uid()
    and exists (select 1 from public.contest_entries e join public.contests c on c.id = e.contest_id
                where e.id = entry_id and c.status <> 'completed')
  );

-- =============================================================================
-- Table privileges: explicit least privilege on top of RLS
-- (works whether or not your project auto-grants access to new tables)
-- =============================================================================
grant usage on schema public to anon, authenticated, service_role;
revoke all on all tables in schema public from anon, authenticated;

-- Public catalogue (readable by visitors who are not logged in)
grant select on
  public.app_config, public.profiles, public.tutor_profiles, public.missions,
  public.reviews, public.contests, public.contest_entries, public.tutor_directory
to anon, authenticated;

-- Private data (RLS decides which rows each user sees)
grant select on
  public.proposals, public.contracts, public.milestones, public.payments,
  public.saved_items, public.mission_invites, public.conversations,
  public.messages, public.contest_votes, public.tutor_payout_accounts
to authenticated;

-- Writes: column-limited, so users can never touch privileged columns
grant update (full_name) on public.profiles to authenticated;

grant update (headline, bio, location, categories, skills, price_from, guarantee, response_time)
  on public.tutor_profiles to authenticated;

grant insert (student_id, title, category, level, budget, deadline, availability, learning_style, description)
  on public.missions to authenticated;
grant update (status) on public.missions to authenticated;

grant insert (mission_id, tutor_id, cover_letter, approach, price, timeline, milestones)
  on public.proposals to authenticated;
grant update (status) on public.proposals to authenticated;

grant insert (contract_id, student_id, tutor_id, rating, clarity, improvement, reliability, patience, body)
  on public.reviews to authenticated;

grant insert, delete on public.saved_items to authenticated;
grant insert (mission_id, tutor_id) on public.mission_invites to authenticated;
grant insert (conversation_id, sender_id, body) on public.messages to authenticated;
grant insert (contest_id, tutor_id, title, description) on public.contest_entries to authenticated;
grant insert (entry_id, user_id) on public.contest_votes to authenticated;
grant delete on public.contest_votes to authenticated;

-- The service role (edge functions, dashboard) bypasses RLS but still needs privileges
grant all on all tables in schema public to service_role;

-- =============================================================================
-- Server-side functions (the ONLY way contract / milestone state changes)
-- =============================================================================

-- Student accepts a proposal: creates the contract + milestones atomically.
create function public.accept_proposal(p_proposal_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  pr  public.proposals;
  mi  public.missions;
  cid uuid;
  el  jsonb;
  i   integer := 0;
begin
  if auth.uid() is null then raise exception 'Please log in first'; end if;

  select * into pr from public.proposals where id = p_proposal_id for update;
  if not found then raise exception 'Proposal not found'; end if;

  select * into mi from public.missions where id = pr.mission_id for update;
  if mi.student_id <> auth.uid() then raise exception 'Only the goal owner can accept a proposal'; end if;
  if mi.status <> 'open' then raise exception 'This goal is no longer open'; end if;
  if pr.status <> 'pending' then raise exception 'This proposal is no longer available'; end if;

  insert into public.contracts (mission_id, proposal_id, student_id, tutor_id, title, total)
  values (mi.id, pr.id, mi.student_id, pr.tutor_id, mi.title, pr.price)
  returning id into cid;

  for el in select e from jsonb_array_elements(pr.milestones) e loop
    i := i + 1;
    insert into public.milestones (contract_id, position, title, detail, amount)
    values (cid, i, el ->> 'title', coalesce(el ->> 'detail', ''), round((el ->> 'amount')::numeric, 2));
  end loop;

  update public.proposals
     set status = case when id = pr.id then 'accepted' else 'rejected' end
   where mission_id = mi.id and status = 'pending';

  update public.missions set status = 'in_progress' where id = mi.id;
  return cid;
end;
$$;

-- Tutor marks a funded milestone as delivered.
create function public.submit_milestone(p_milestone_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  ms public.milestones;
  c  public.contracts;
begin
  if auth.uid() is null then raise exception 'Please log in first'; end if;
  select * into ms from public.milestones where id = p_milestone_id for update;
  if not found then raise exception 'Milestone not found'; end if;
  select * into c from public.contracts where id = ms.contract_id;
  if c.tutor_id <> auth.uid() then raise exception 'Only the tutor on this contract can do that'; end if;
  if c.status <> 'active' then raise exception 'This contract is not active'; end if;
  if ms.status <> 'funded' then raise exception 'The student must fund this milestone before you deliver it'; end if;
  update public.milestones set status = 'in_review', submitted_at = now() where id = ms.id;
end;
$$;

-- Student asks for changes: milestone goes back to the tutor.
create function public.request_milestone_changes(p_milestone_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  ms public.milestones;
  c  public.contracts;
begin
  if auth.uid() is null then raise exception 'Please log in first'; end if;
  select * into ms from public.milestones where id = p_milestone_id for update;
  if not found then raise exception 'Milestone not found'; end if;
  select * into c from public.contracts where id = ms.contract_id;
  if c.student_id <> auth.uid() then raise exception 'Only the student on this contract can do that'; end if;
  if ms.status <> 'in_review' then raise exception 'This milestone is not waiting for review'; end if;
  update public.milestones set status = 'funded', submitted_at = null where id = ms.id;
end;
$$;

-- Student approves delivered work. (The tutor was already paid by Paystack's split
-- when the milestone was funded; approval closes the milestone and unlocks the next.)
create function public.release_milestone(p_milestone_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  ms public.milestones;
  c  public.contracts;
begin
  if auth.uid() is null then raise exception 'Please log in first'; end if;
  select * into ms from public.milestones where id = p_milestone_id for update;
  if not found then raise exception 'Milestone not found'; end if;
  select * into c from public.contracts where id = ms.contract_id for update;
  if c.student_id <> auth.uid() then raise exception 'Only the student on this contract can do that'; end if;
  if ms.status <> 'in_review' then raise exception 'This milestone is not waiting for approval'; end if;

  update public.milestones set status = 'released', released_at = now() where id = ms.id;

  if not exists (select 1 from public.milestones where contract_id = c.id and status <> 'released') then
    update public.contracts set status = 'completed' where id = c.id;
    update public.missions set status = 'completed' where id = c.mission_id;
  end if;
end;
$$;

-- Start (or find) a 1:1 conversation with another user.
create function public.get_or_create_conversation(p_other uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  me  uuid := auth.uid();
  a   uuid;
  b   uuid;
  cid uuid;
begin
  if me is null then raise exception 'Please log in first'; end if;
  if p_other is null or p_other = me then raise exception 'Choose someone else to message'; end if;
  if not exists (select 1 from public.profiles where id = p_other) then raise exception 'User not found'; end if;

  if me < p_other then a := me; b := p_other; else a := p_other; b := me; end if;

  select id into cid from public.conversations where user_a = a and user_b = b;
  if cid is null then
    insert into public.conversations (user_a, user_b) values (a, b)
    on conflict (user_a, user_b) do nothing;
    select id into cid from public.conversations where user_a = a and user_b = b;
  end if;
  return cid;
end;
$$;

-- Called ONLY by the Paystack edge functions (service role) after Paystack has
-- confirmed the transaction. Checks amount + currency, funds the milestone and records the split.
create function public.confirm_payment(p_reference text, p_amount_minor bigint, p_currency text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  pay public.payments;
  ms  public.milestones;
begin
  select * into pay from public.payments where reference = p_reference for update;
  if not found then return 'not_found'; end if;
  if pay.status = 'success' then return 'already_confirmed'; end if;

  if round(pay.amount * 100)::bigint <> p_amount_minor or upper(pay.currency) <> upper(p_currency) then
    update public.payments set status = 'failed' where id = pay.id;
    return 'amount_mismatch';
  end if;

  select * into ms from public.milestones where id = pay.milestone_id for update;
  if ms.status <> 'pending' then
    -- Milestone already funded by another payment: keep the record, flag for refund.
    update public.payments set status = 'duplicate', paid_at = now() where id = pay.id;
    return 'duplicate';
  end if;

  update public.payments set status = 'success', paid_at = now() where id = pay.id;
  update public.milestones
     set status = 'funded', funded_at = now(),
         platform_fee = round(ms.amount * coalesce((select value::numeric from public.app_config where key = 'commission_percent'), 0) / 100, 2),
         tutor_amount = ms.amount - round(ms.amount * coalesce((select value::numeric from public.app_config where key = 'commission_percent'), 0) / 100, 2)
   where id = ms.id;
  return 'ok';
end;
$$;

-- Function permissions: nothing is callable by default.
revoke all on function public.accept_proposal(uuid)              from public, anon, authenticated;
revoke all on function public.submit_milestone(uuid)             from public, anon, authenticated;
revoke all on function public.request_milestone_changes(uuid)    from public, anon, authenticated;
revoke all on function public.release_milestone(uuid)            from public, anon, authenticated;
revoke all on function public.get_or_create_conversation(uuid)   from public, anon, authenticated;
revoke all on function public.confirm_payment(text, bigint, text) from public, anon, authenticated;

grant execute on function public.accept_proposal(uuid)            to authenticated;
grant execute on function public.submit_milestone(uuid)           to authenticated;
grant execute on function public.request_milestone_changes(uuid)  to authenticated;
grant execute on function public.release_milestone(uuid)          to authenticated;
grant execute on function public.get_or_create_conversation(uuid) to authenticated;
grant execute on function public.confirm_payment(text, bigint, text) to service_role;

-- Realtime for chat
do $$
begin
  alter publication supabase_realtime add table public.messages;
exception when others then
  null; -- publication not available (e.g. plain Postgres) — chat falls back to polling
end;
$$;
