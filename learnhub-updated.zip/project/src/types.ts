export const CATEGORIES = ['Languages', 'Programming', 'Math', 'Music', 'Design', 'Exam Prep', 'Business'] as const;
export type Category = (typeof CATEGORIES)[number];

export const LEVELS = ['Beginner', 'Intermediate', 'Advanced'] as const;
export type Level = (typeof LEVELS)[number];

export const CATEGORY_BLURBS: Record<Category, string> = {
  Languages: 'IELTS, Spanish, French, and more',
  Programming: 'Python, web, data science, mobile',
  Math: 'Algebra, calculus, statistics',
  Music: 'Piano, guitar, theory, production',
  Design: 'Photoshop, Figma, illustration',
  'Exam Prep': 'SAT, GCSE, university entrance',
  Business: 'English, marketing, leadership',
};

export type Role = 'student' | 'tutor';

export interface Profile {
  id: string;
  role: Role;
  fullName: string;
  avatarUrl?: string | null;
  points?: number;
}

export interface TutorScore {
  label: string;
  value: number; // 0-100
}

export interface Tutor {
  id: string;
  name: string;
  headline: string;
  bio: string;
  location: string;
  categories: Category[];
  skills: string[];
  priceFrom: number;
  guarantee: string | null;
  responseTime: string;
  verified: boolean;
  avatarUrl?: string | null;
  verificationStatus?: 'unsubmitted' | 'pending' | 'approved' | 'rejected';
  rating: number | null;
  reviewCount: number;
  completedProjects: number;
  scores: TutorScore[];
}

export interface TutorProfileForm {
  headline: string;
  bio: string;
  location: string;
  categories: Category[];
  skills: string[];
  priceFrom: number;
  guarantee: string;
  responseTime: string;
  isPublished: boolean;
  verified: boolean;
}

export interface Review {
  id: string;
  student: string;
  mission: string;
  rating: number;
  createdAt: string;
  text: string;
  subScores: { label: string; value: number }[]; // 0-100
}

export type MissionStatus = 'open' | 'in_progress' | 'completed' | 'cancelled';

export interface Mission {
  id: string;
  studentId: string;
  student: string;
  title: string;
  category: Category;
  level: Level;
  budget: number;
  deadline: string;
  availability: string;
  learningStyle: string;
  description: string;
  status: MissionStatus;
  proposalsCount: number;
  createdAt: string;
}

export interface ProposalMilestone {
  title: string;
  detail: string;
  amount: number;
}

export type ProposalStatus = 'pending' | 'accepted' | 'rejected' | 'withdrawn';

export interface Proposal {
  id: string;
  missionId: string;
  tutorId: string;
  tutorName: string;
  coverLetter: string;
  approach: string[];
  price: number;
  timeline: string;
  milestones: ProposalMilestone[];
  status: ProposalStatus;
  createdAt: string;
  tutor?: Tutor;
}

export type MilestoneStatus = 'pending' | 'funded' | 'in_review' | 'released';

export interface Milestone {
  id: string;
  contractId: string;
  position: number;
  title: string;
  detail: string;
  amount: number;
  status: MilestoneStatus;
  platformFee: number | null;
  tutorAmount: number | null;
}

export interface Contract {
  id: string;
  missionId: string;
  title: string;
  studentId: string;
  studentName: string;
  tutorId: string;
  tutorName: string;
  total: number;
  status: 'active' | 'completed' | 'cancelled';
  createdAt: string;
  milestones: Milestone[];
  reviewed: boolean;
}

export type ContestStatus = 'open' | 'voting' | 'completed';

export interface Contest {
  id: string;
  title: string;
  sponsor: string;
  category: Category;
  prize: number;
  description: string;
  deadline: string;
  status: ContestStatus;
  entriesCount: number;
}

export interface ContestEntry {
  id: string;
  contestId: string;
  tutorId: string;
  tutorName: string;
  title: string;
  description: string;
  votes: number;
  createdAt: string;
}

export interface Conversation {
  id: string;
  otherId: string;
  otherName: string;
  lastMessage: string;
  lastMessageAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  body: string;
  createdAt: string;
}
