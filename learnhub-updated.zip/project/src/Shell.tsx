import { useEffect, useRef, useState } from 'react';
import {
  Bookmark, ChevronDown, Compass, GraduationCap, Inbox, LayoutDashboard, LogOut, PenSquare,
  Settings, Sparkles, Trophy, Users, Info, ShieldCheck, Bell,
} from 'lucide-react';
import { Link, useNav, type Page } from './nav';
import { useAuth } from './context/AuthContext';
import { useToast } from './context/ToastContext';
import { Avatar } from './components/ui';
import { isCurrentUserAdmin, listNotifications, markAllNotificationsRead, markNotificationRead } from './lib/api';
import { useAsync } from './hooks';
import { IS_PAYMENT_TEST_MODE, SUPPORT_EMAIL } from './lib/config';

type NavLink = { label: string; page: Page; icon: typeof Compass; authOnly?: boolean };

const links: NavLink[] = [
  { label: 'Missions', page: { name: 'missions' }, icon: Compass },
  { label: 'Tutors', page: { name: 'tutors' }, icon: Users },
  { label: 'Contests', page: { name: 'contests' }, icon: Trophy },
  { label: 'Tutor Match', page: { name: 'match' }, icon: Sparkles },
  { label: 'Dashboard', page: { name: 'dashboard' }, icon: LayoutDashboard, authOnly: true },
  { label: 'Messages', page: { name: 'messages' }, icon: Inbox, authOnly: true },
  { label: 'Saved', page: { name: 'saved' }, icon: Bookmark, authOnly: true },
];

export function TestModeBanner() {
  if (!IS_PAYMENT_TEST_MODE) return null;
  return (
    <div className="flex items-center justify-center gap-2 bg-amber-100 px-4 py-1.5 text-center text-xs font-medium text-amber-900">
      <Info className="h-3.5 w-3.5 shrink-0" />
      Payments are in test mode — no real money is charged. Use Paystack test card 4084 0840 8408 4081, any future expiry, CVV 408.
    </div>
  );
}


function NotificationBell(){
  const {user}=useAuth(); const {navigateToPath}=useNav(); const [open,setOpen]=useState(false); const [items,setItems]=useState<Awaited<ReturnType<typeof listNotifications>>>([]);
  useEffect(()=>{if(!user)return; listNotifications(user.id).then(setItems).catch(()=>{});},[user?.id,open]);
  if(!user)return null; const unread=items.filter(n=>!n.readAt).length;
  return <div className="relative"><button onClick={()=>setOpen(v=>!v)} aria-label={`Notifications${unread?` (${unread} unread)`:''}`} className="relative grid h-9 w-9 place-items-center rounded-xl hover:bg-ink-100"><Bell className="h-4 w-4 text-ink-600"/>{unread>0&&<span className="absolute right-1 top-1 grid min-h-4 min-w-4 place-items-center rounded-full bg-brand-600 px-1 text-[9px] font-bold text-white">{unread>9?'9+':unread}</span>}</button>{open&&<div className="card absolute right-0 z-50 mt-2 w-80 p-2 animate-pop-in"><div className="flex items-center justify-between px-3 py-2"><p className="font-semibold text-ink-900">Notifications</p>{unread>0&&<button onClick={async()=>{await markAllNotificationsRead(user.id);setItems(items.map(n=>({...n,readAt:new Date().toISOString()})));}} className="text-xs text-brand-600">Mark all read</button>}</div><div className="max-h-80 overflow-y-auto">{items.length===0?<p className="px-3 py-8 text-center text-sm text-ink-400">You're all caught up.</p>:items.slice(0,20).map(n=><button key={n.id} onClick={async()=>{if(!n.readAt){await markNotificationRead(n.id);setItems(items.map(x=>x.id===n.id?{...x,readAt:new Date().toISOString()}:x));}if(n.href){setOpen(false);navigateToPath(n.href);}}} className={`block w-full rounded-lg px-3 py-2 text-left hover:bg-ink-50 ${n.readAt?'':'bg-brand-50/50'}`}><p className="text-sm font-medium text-ink-900">{n.title}</p><p className="mt-0.5 text-xs text-ink-500">{n.body}</p></button>)}</div></div>}</div>;
}

function UserMenu() {
  const { profile, signOut } = useAuth();
  const { navigate } = useNav();
  const toast = useToast();
  const isAdmin = useAsync(() => profile ? isCurrentUserAdmin(profile.id) : Promise.resolve(false), [profile?.id]);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDown); document.removeEventListener('keydown', onKey); };
  }, [open]);

  if (!profile) return null;

  const go = (p: Page) => { setOpen(false); navigate(p); };
  const logout = async () => {
    setOpen(false);
    await signOut();
    navigate({ name: 'home' });
    toast.info('You have been logged out.');
  };

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open} className="flex items-center gap-2 rounded-xl p-1 pr-2 hover:bg-ink-100">
        <Avatar name={profile.fullName} size={32} src={profile.avatarUrl} />
        <ChevronDown className="h-4 w-4 text-ink-400" />
      </button>
      {open && (
        <div role="menu" className="card absolute right-0 z-50 mt-2 w-60 p-2 animate-pop-in">
          <div className="border-b border-ink-100 px-3 pb-2 pt-1">
            <p className="truncate text-sm font-semibold text-ink-900">{profile.fullName}</p>
            <p className="text-xs capitalize text-ink-400">{profile.role}</p>
          </div>
          <div className="mt-1 space-y-0.5 text-sm">
            <button role="menuitem" onClick={() => go({ name: 'dashboard' })} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left hover:bg-ink-50"><LayoutDashboard className="h-4 w-4 text-ink-400" /> Dashboard</button>
            <button role="menuitem" onClick={() => go({ name: 'messages' })} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left hover:bg-ink-50"><Inbox className="h-4 w-4 text-ink-400" /> Messages</button>
            <button role="menuitem" onClick={() => go({ name: 'saved' })} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left hover:bg-ink-50"><Bookmark className="h-4 w-4 text-ink-400" /> Saved</button>
            {isAdmin.data && <button role="menuitem" onClick={() => go({ name: 'admin' })} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-brand-700 hover:bg-brand-50"><ShieldCheck className="h-4 w-4" /> Admin dashboard</button>}
            <button role="menuitem" onClick={() => go({ name: 'account' })} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left hover:bg-ink-50"><Settings className="h-4 w-4 text-ink-400" /> Account settings</button>
            <button role="menuitem" onClick={logout} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-red-600 hover:bg-red-50"><LogOut className="h-4 w-4" /> Log out</button>
          </div>
        </div>
      )}
    </div>
  );
}

export function Navbar() {
  const { page } = useNav();
  const { user, profile, loading } = useAuth();
  const visible = links.filter((l) => !l.authOnly || user);
  const active = (name: string) => page.name === name || (name === 'missions' && page.name === 'mission') || (name === 'tutors' && page.name === 'tutor') || (name === 'contests' && page.name === 'contest');
  const isStudent = profile?.role === 'student';

  return (
    <header className="sticky top-0 z-50 border-b border-ink-100/80 bg-white/80 backdrop-blur-xl">
      <div className="section flex h-16 items-center justify-between gap-4">
        <Link to={{ name: 'home' }} className="flex shrink-0 items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-sky-500 text-white shadow-glow"><GraduationCap className="h-5 w-5" /></span>
          <span className="font-display text-lg font-extrabold tracking-tight text-ink-900">Learn<span className="gradient-text">Hub</span></span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {visible.map((l) => (
            <Link key={l.label} to={l.page} className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition ${active(l.page.name) ? 'bg-brand-50 text-brand-700' : 'text-ink-600 hover:bg-ink-100 hover:text-ink-900'}`}>
              <l.icon className="h-4 w-4" /> {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {loading ? null : user ? (
            <>
              {isStudent && <Link to={{ name: 'post' }} className="btn-gradient hidden sm:inline-flex"><PenSquare className="h-4 w-4" /> Post a Goal</Link>}
              <NotificationBell />
              <UserMenu />
            </>
          ) : (
            <>
              <Link to={{ name: 'login' }} className="btn-ghost">Log in</Link>
              <Link to={{ name: 'signup' }} className="btn-gradient">Sign up</Link>
            </>
          )}
        </div>
      </div>

      <nav className="border-t border-ink-100 bg-white/90 backdrop-blur lg:hidden" aria-label="Main (mobile)">
        <div className="section no-scrollbar flex items-center gap-1 overflow-x-auto py-2">
          {visible.map((l) => (
            <Link key={l.label} to={l.page} className={`flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition ${active(l.page.name) ? 'bg-brand-50 text-brand-700' : 'text-ink-600 hover:bg-ink-100'}`}>
              <l.icon className="h-3.5 w-3.5" /> {l.label}
            </Link>
          ))}
          {isStudent && (
            <Link to={{ name: 'post' }} className="flex shrink-0 items-center gap-1.5 rounded-lg bg-gradient-to-r from-brand-500 to-sky-500 px-3 py-1.5 text-xs font-semibold text-white">
              <PenSquare className="h-3.5 w-3.5" /> Post
            </Link>
          )}
        </div>
      </nav>
    </header>
  );
}

export function Footer() {
  const { user, profile } = useAuth();
  return (
    <footer className="border-t border-ink-100 bg-white">
      <div className="section py-12">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand-500 to-sky-500 text-white"><GraduationCap className="h-4 w-4" /></span>
              <span className="font-display text-lg font-extrabold text-ink-900">Learn<span className="gradient-text">Hub</span></span>
            </div>
            <p className="mt-3 max-w-sm text-sm text-ink-500">
              The project-based learning marketplace. Post your learning goal, compare proposals from tutors, and pay one milestone at a time.
            </p>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-ink-900">For students</h4>
            <ul className="mt-3 space-y-2 text-sm text-ink-500">
              <li><Link to={user && profile?.role === 'student' ? { name: 'post' } : { name: 'signup', role: 'student' }} className="hover:text-brand-600">Post a goal</Link></li>
              <li><Link to={{ name: 'tutors' }} className="hover:text-brand-600">Find tutors</Link></li>
              <li><Link to={{ name: 'match' }} className="hover:text-brand-600">Tutor Match</Link></li>
              <li><Link to={{ name: 'contests' }} className="hover:text-brand-600">Learning contests</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-ink-900">For tutors</h4>
            <ul className="mt-3 space-y-2 text-sm text-ink-500">
              <li><Link to={user && profile?.role === 'tutor' ? { name: 'account' } : { name: 'signup', role: 'tutor' }} className="hover:text-brand-600">Become a tutor</Link></li>
              <li><Link to={{ name: 'missions' }} className="hover:text-brand-600">Browse open goals</Link></li>
              <li><Link to={{ name: 'contests' }} className="hover:text-brand-600">Enter a contest</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-ink-100 pt-6 text-xs text-ink-400 sm:flex-row">
          <p>© {new Date().getFullYear()} LearnHub. All rights reserved.</p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link to={{ name: 'terms' }} className="hover:text-brand-600">Terms</Link>
            <Link to={{ name: 'privacy' }} className="hover:text-brand-600">Privacy</Link>
            {SUPPORT_EMAIL && <a href={`mailto:${SUPPORT_EMAIL}`} className="hover:text-brand-600">{SUPPORT_EMAIL}</a>}
          </div>
        </div>
      </div>
    </footer>
  );
}
