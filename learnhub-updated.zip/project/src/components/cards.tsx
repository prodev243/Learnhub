import { Building2, Clock, MapPin, ShieldCheck, Trophy, Users } from 'lucide-react';
import { Link } from '@/nav';
import { Avatar, SaveButton, Stars, VerifiedBadge } from './ui';
import { money, timeAgo, timeLeft } from '@/lib/format';
import type { Contest, Mission, Tutor } from '@/types';

export function TutorCard({ tutor }: { tutor: Tutor }) {
  return (
    <div className="relative">
      <Link
        to={{ name: 'tutor', id: tutor.id }}
        className="card group flex h-full flex-col p-5 text-left transition-all duration-300 hover:-translate-y-1 hover:shadow-card-lg hover:ring-brand-200"
      >
        <div className="flex items-start gap-3 pr-10">
          <Avatar name={tutor.name} size={56} ring src={tutor.avatarUrl} />
          <div className="min-w-0">
            <h3 className="font-display font-bold leading-tight text-ink-900">{tutor.name}</h3>
            <p className="truncate text-sm text-ink-500">{tutor.headline}</p>
            {tutor.location && (
              <div className="mt-1 flex items-center gap-1.5 text-xs text-ink-400"><MapPin className="h-3 w-3" /> {tutor.location}</div>
            )}
          </div>
        </div>

        <div className="mt-4 flex items-center gap-3">
          {tutor.rating != null ? (
            <>
              <Stars rating={tutor.rating} />
              <span className="text-sm font-semibold text-ink-900">{tutor.rating}</span>
              <span className="text-xs text-ink-400">({tutor.reviewCount} {tutor.reviewCount === 1 ? 'review' : 'reviews'})</span>
            </>
          ) : (
            <span className="chip bg-ink-100 text-ink-600">New tutor</span>
          )}
          {tutor.verified && <span className="ml-auto"><VerifiedBadge /></span>}
        </div>

        {tutor.skills.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-1.5">
            {tutor.skills.slice(0, 3).map((s) => <span key={s} className="chip bg-ink-100 text-ink-700">{s}</span>)}
          </div>
        )}

        <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl bg-ink-50 p-3 text-center">
          <div>
            <p className="text-base font-bold text-ink-900">{tutor.completedProjects}</p>
            <p className="text-[10px] uppercase tracking-wide text-ink-400">Completed</p>
          </div>
          <div>
            <p className="text-base font-bold text-ink-900">{money(tutor.priceFrom)}</p>
            <p className="text-[10px] uppercase tracking-wide text-ink-400">From</p>
          </div>
        </div>

        {tutor.guarantee && (
          <div className="mt-3 flex items-start gap-2 rounded-lg bg-brand-50 p-2.5 text-xs text-brand-800">
            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-600" />
            <span className="leading-snug">{tutor.guarantee}</span>
          </div>
        )}
      </Link>
      <SaveButton kind="tutor" id={tutor.id} className="absolute right-4 top-4" />
    </div>
  );
}

const statusStyles: Record<Mission['status'], string> = {
  open: 'bg-brand-100 text-brand-700',
  in_progress: 'bg-sky-100 text-sky-700',
  completed: 'bg-ink-200 text-ink-600',
  cancelled: 'bg-red-50 text-red-600',
};
export const statusLabel: Record<Mission['status'], string> = {
  open: 'Open', in_progress: 'In progress', completed: 'Completed', cancelled: 'Cancelled',
};

export function MissionCard({ mission }: { mission: Mission }) {
  return (
    <div className="relative">
      <Link
        to={{ name: 'mission', id: mission.id }}
        className="card group flex h-full flex-col p-5 text-left transition-all duration-300 hover:-translate-y-1 hover:shadow-card-lg hover:ring-brand-200"
      >
        <div className="flex items-center justify-between gap-2 pr-10">
          <span className="chip bg-ink-100 text-ink-700">{mission.category}</span>
          <span className={`chip ${statusStyles[mission.status]}`}>{statusLabel[mission.status]}</span>
        </div>
        <h3 className="mt-3 font-display text-base font-bold leading-snug text-ink-900 group-hover:text-brand-700">{mission.title}</h3>
        <p className="mt-2 line-clamp-2 text-sm text-ink-500">{mission.description}</p>
        <div className="mt-4 flex flex-wrap gap-2 text-xs text-ink-500">
          <span className="chip bg-ink-50 text-ink-600">{mission.level}</span>
          {mission.deadline && <span className="chip bg-ink-50 text-ink-600"><Clock className="h-3 w-3" /> {mission.deadline}</span>}
        </div>
        <div className="mt-auto flex items-center justify-between border-t border-ink-100 pt-3 mt-4">
          <div className="flex items-center gap-2">
            <Avatar name={mission.student} size={28} />
            <div>
              <p className="text-xs font-medium text-ink-700">{mission.student}</p>
              <p className="text-[10px] text-ink-400">{timeAgo(mission.createdAt)}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm font-bold text-ink-900">{money(mission.budget)}</p>
            <p className="text-[10px] text-ink-400">{mission.proposalsCount} {mission.proposalsCount === 1 ? 'proposal' : 'proposals'}</p>
          </div>
        </div>
      </Link>
      <SaveButton kind="mission" id={mission.id} className="absolute right-4 top-4" />
    </div>
  );
}

const contestStatusStyles: Record<Contest['status'], string> = {
  open: 'bg-brand-100 text-brand-700',
  voting: 'bg-sky-100 text-sky-700',
  completed: 'bg-ink-200 text-ink-600',
};

export function ContestCard({ contest }: { contest: Contest }) {
  return (
    <div className="card flex flex-col p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-card-lg hover:ring-brand-200">
      <div className="flex items-center justify-between">
        <span className="chip bg-ink-100 text-ink-700">{contest.category}</span>
        <span className={`chip capitalize ${contestStatusStyles[contest.status]}`}>{contest.status}</span>
      </div>
      <div className="mt-3 flex items-center gap-2">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-sky-500 text-white"><Trophy className="h-5 w-5" /></span>
        <div className="min-w-0 flex-1">
          <h3 className="font-display text-base font-bold leading-snug text-ink-900">{contest.title}</h3>
          <p className="flex items-center gap-1 text-xs text-ink-400"><Building2 className="h-3 w-3" /> {contest.sponsor}</p>
        </div>
      </div>
      <p className="mt-3 line-clamp-2 text-sm text-ink-500">{contest.description}</p>
      <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-ink-50 p-3 text-center">
        <div>
          <p className="text-sm font-bold text-brand-600">{money(contest.prize)}</p>
          <p className="text-[10px] uppercase tracking-wide text-ink-400">Prize</p>
        </div>
        <div>
          <p className="text-base font-bold text-ink-900">{contest.entriesCount}</p>
          <p className="text-[10px] uppercase tracking-wide text-ink-400">Entries</p>
        </div>
        <div>
          <p className="text-xs font-bold text-ink-900">{timeLeft(contest.deadline)}</p>
          <p className="text-[10px] uppercase tracking-wide text-ink-400">Deadline</p>
        </div>
      </div>
      <Link to={{ name: 'contest', id: contest.id }} className="btn-secondary mt-4 w-full">
        <Users className="h-4 w-4" /> View contest
      </Link>
    </div>
  );
}
