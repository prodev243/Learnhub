import { useEffect, type ReactNode } from 'react';
import { AlertTriangle, BadgeCheck, Bookmark, Loader2, Star, X } from 'lucide-react';
import { initials } from '@/lib/format';
import { useSaved } from '@/context/SavedContext';
import type { SavedKind } from '@/lib/api';

export function Stars({ rating, size = 'sm' }: { rating: number; size?: 'sm' | 'md' }) {
  const dim = size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4';
  return (
    <div className="flex items-center gap-0.5" aria-label={`${rating} out of 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} className={`${dim} ${i <= Math.round(rating) ? 'fill-sky-400 text-sky-400' : 'fill-ink-200 text-ink-200'}`} />
      ))}
    </div>
  );
}

const palette = ['bg-brand-100 text-brand-700', 'bg-sky-100 text-sky-700', 'bg-ocean-100 text-ocean-700', 'bg-ink-200 text-ink-700'];

export function Avatar({ name, size = 40, ring, src }: { name: string; size?: number; ring?: boolean; src?: string | null }) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  if (src) return <img src={src} alt="" aria-hidden="true" className={`inline-block shrink-0 rounded-full object-cover ${ring ? 'ring-2 ring-white shadow-sm' : ''}`} style={{ width: size, height: size }} />;
  return (
    <span
      aria-hidden="true"
      className={`inline-grid shrink-0 place-items-center rounded-full font-display font-bold ${palette[h % palette.length]} ${ring ? 'ring-2 ring-white shadow-sm' : ''}`}
      style={{ width: size, height: size, fontSize: Math.max(10, size * 0.38) }}
    >
      {initials(name)}
    </span>
  );
}

export function VerifiedBadge({ label = 'Verified' }: { label?: string }) {
  return (
    <span className="chip bg-brand-50 text-brand-700 ring-1 ring-brand-100">
      <BadgeCheck className="h-3 w-3" /> {label}
    </span>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-12 text-sm text-ink-400" role="status">
      <Loader2 className="h-5 w-5 animate-spin text-brand-500" /> {label ?? 'Loading…'}
    </div>
  );
}

export function PageLoader() {
  return <div className="section min-h-[50vh] py-20"><Spinner /></div>;
}

export function ErrorNote({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="card flex flex-col items-center gap-3 p-8 text-center" role="alert">
      <AlertTriangle className="h-8 w-8 text-red-500" />
      <p className="text-sm text-ink-700">{message}</p>
      {onRetry && <button onClick={onRetry} className="btn-secondary">Try again</button>}
    </div>
  );
}

export function EmptyState({ icon, title, text, action }: { icon: ReactNode; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="card flex flex-col items-center p-12 text-center">
      <div className="text-ink-300 [&>svg]:h-10 [&>svg]:w-10">{icon}</div>
      <p className="mt-3 font-semibold text-ink-700">{title}</p>
      {text && <p className="mt-1 max-w-md text-sm text-ink-400">{text}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function LoadMore({ onClick, loading }: { onClick: () => void; loading: boolean }) {
  return (
    <div className="mt-8 flex justify-center">
      <button onClick={onClick} disabled={loading} className="btn-secondary disabled:opacity-60">
        {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Loading…</> : 'Load more'}
      </button>
    </div>
  );
}

export function ProgressBar({ percent, color = 'bg-brand-500' }: { percent: number; color?: string }) {
  const p = Math.max(0, Math.min(100, percent));
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-ink-100" role="progressbar" aria-valuenow={p} aria-valuemin={0} aria-valuemax={100}>
      <div className={`h-full rounded-full ${color} transition-all duration-700`} style={{ width: `${p}%` }} />
    </div>
  );
}

export function SectionHeader({ eyebrow, title, subtitle, center }: { eyebrow?: string; title: string; subtitle?: string; center?: boolean }) {
  return (
    <div className={`max-w-2xl ${center ? 'mx-auto text-center' : ''}`}>
      {eyebrow && <p className="text-sm font-semibold uppercase tracking-wide text-brand-600">{eyebrow}</p>}
      <h2 className="mt-1 font-display text-3xl font-extrabold tracking-tight text-ink-900 sm:text-4xl text-balance">{title}</h2>
      {subtitle && <p className="mt-3 text-base text-ink-500 text-balance">{subtitle}</p>}
    </div>
  );
}

export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[60] flex items-end justify-center bg-ink-950/50 p-0 sm:items-center sm:p-4"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div role="dialog" aria-modal="true" aria-label={title} className="card max-h-[90vh] w-full overflow-y-auto rounded-b-none p-6 animate-pop-in sm:max-w-lg sm:rounded-b-2xl">
        <div className="flex items-start justify-between gap-4">
          <h2 className="font-display text-xl font-bold text-ink-900">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-lg p-1 text-ink-400 hover:bg-ink-100 hover:text-ink-700"><X className="h-5 w-5" /></button>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open, title, message, confirmLabel, danger, busy, onConfirm, onCancel,
}: {
  open: boolean; title: string; message: string; confirmLabel: string; danger?: boolean; busy?: boolean;
  onConfirm: () => void; onCancel: () => void;
}) {
  return (
    <Modal open={open} onClose={busy ? () => {} : onCancel} title={title}>
      <p className="text-sm text-ink-600">{message}</p>
      <div className="mt-6 flex justify-end gap-3">
        <button onClick={onCancel} disabled={busy} className="btn-secondary">Cancel</button>
        <button onClick={onConfirm} disabled={busy} className={`btn ${danger ? 'bg-red-600 text-white hover:bg-red-700' : 'btn-primary'} disabled:opacity-60`}>
          {busy && <Loader2 className="h-4 w-4 animate-spin" />} {confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

export function SaveButton({ kind, id, className = '' }: { kind: SavedKind; id: string; className?: string }) {
  const { has, toggle } = useSaved();
  const saved = has(kind, id);
  return (
    <button
      type="button"
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); void toggle(kind, id); }}
      aria-pressed={saved}
      aria-label={saved ? 'Remove from saved' : 'Save for later'}
      title={saved ? 'Remove from saved' : 'Save for later'}
      className={`grid h-9 w-9 place-items-center rounded-full bg-white text-ink-400 shadow-card transition hover:text-brand-600 ${saved ? 'text-brand-600' : ''} ${className}`}
    >
      <Bookmark className={`h-4 w-4 ${saved ? 'fill-current' : ''}`} />
    </button>
  );
}
