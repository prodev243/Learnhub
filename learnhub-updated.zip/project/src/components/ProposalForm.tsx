import { useState, type FormEvent } from 'react';
import { Loader2, Plus, Send, Trash2 } from 'lucide-react';
import { createProposal, fetchCommissionPercent } from '@/lib/api';
import { useAsync } from '@/hooks';
import { errorMessage, money } from '@/lib/format';
import { MIN_BUDGET } from '@/lib/config';
import type { Mission } from '@/types';

interface Row { title: string; detail: string; amount: string }

export function ProposalForm({ mission, tutorId, onSent }: { mission: Mission; tutorId: string; onSent: () => void }) {
  const commission = useAsync(() => fetchCommissionPercent(), []);
  const [cover, setCover] = useState('');
  const [approach, setApproach] = useState('');
  const [timeline, setTimeline] = useState(mission.deadline);
  const [rows, setRows] = useState<Row[]>([{ title: '', detail: '', amount: '' }]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const setRow = (i: number, patch: Partial<Row>) => setRows((r) => r.map((x, idx) => (idx === i ? { ...x, ...patch } : x)));
  const amounts = rows.map((r) => Number(r.amount));
  const total = amounts.reduce((s, a) => s + (Number.isFinite(a) ? a : 0), 0);
  const rowsOk = rows.every((r, i) => r.title.trim() && Number.isFinite(amounts[i]) && amounts[i] >= MIN_BUDGET / 5);
  const canSubmit = cover.trim().length >= 20 && timeline.trim().length > 0 && rowsOk && !busy;
  const pct = commission.data ?? 0;
  const net = total * (1 - pct / 100);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setBusy(true);
    setError(null);
    try {
      await createProposal({
        missionId: mission.id, tutorId, coverLetter: cover, timeline,
        approach: approach.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 10),
        milestones: rows.map((r, i) => ({ title: r.title, detail: r.detail, amount: amounts[i] })),
      });
      onSent();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="card space-y-5 p-6" noValidate>
      <div>
        <h3 className="font-display text-lg font-bold text-ink-900">Send a proposal</h3>
        <p className="text-sm text-ink-500">The student's budget is {money(mission.budget)}. Break your plan into milestones — the student funds them one at a time.</p>
      </div>

      <div>
        <label htmlFor="cover" className="label">Cover letter</label>
        <textarea id="cover" rows={4} maxLength={3000} className="input mt-2 resize-none" placeholder="Introduce yourself and explain how you'll help this student reach their goal…" value={cover} onChange={(e) => setCover(e.target.value)} />
      </div>

      <div>
        <label htmlFor="approach" className="label">Teaching approach</label>
        <p className="hint">Optional. One point per line.</p>
        <textarea id="approach" rows={3} className="input mt-2 resize-none" placeholder={'Weekly 1:1 sessions\nPersonalised practice plan'} value={approach} onChange={(e) => setApproach(e.target.value)} />
      </div>

      <div>
        <label htmlFor="timeline" className="label">Timeline</label>
        <input id="timeline" className="input mt-2" maxLength={60} placeholder="e.g. 12 weeks" value={timeline} onChange={(e) => setTimeline(e.target.value)} />
      </div>

      <div>
        <p className="label">Milestones</p>
        <div className="mt-2 space-y-3">
          {rows.map((r, i) => (
            <div key={i} className="rounded-xl border border-ink-100 p-3">
              <div className="flex items-center gap-2">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand-100 text-xs font-bold text-brand-700">{i + 1}</span>
                <input aria-label={`Milestone ${i + 1} title`} className="input py-2" placeholder="Milestone title" maxLength={100} value={r.title} onChange={(e) => setRow(i, { title: e.target.value })} />
                {rows.length > 1 && <button type="button" onClick={() => setRows((x) => x.filter((_, idx) => idx !== i))} aria-label="Remove milestone" className="rounded-lg p-2 text-ink-400 hover:bg-red-50 hover:text-red-600"><Trash2 className="h-4 w-4" /></button>}
              </div>
              <div className="mt-2 grid gap-2 sm:grid-cols-3">
                <input aria-label={`Milestone ${i + 1} details`} className="input py-2 sm:col-span-2" placeholder="What will be delivered?" maxLength={200} value={r.detail} onChange={(e) => setRow(i, { detail: e.target.value })} />
                <input aria-label={`Milestone ${i + 1} amount`} type="number" inputMode="decimal" min={0} className="input py-2" placeholder="Amount" value={r.amount} onChange={(e) => setRow(i, { amount: e.target.value })} />
              </div>
            </div>
          ))}
        </div>
        {rows.length < 8 && <button type="button" onClick={() => setRows((x) => [...x, { title: '', detail: '', amount: '' }])} className="btn-ghost mt-2"><Plus className="h-4 w-4" /> Add milestone</button>}
      </div>

      <div className="rounded-xl bg-ink-50 p-4 text-sm">
        <div className="flex justify-between"><span className="text-ink-500">Proposal total</span><span className="font-bold text-ink-900">{money(total)}</span></div>
        {pct > 0 && (
          <>
            <div className="mt-1 flex justify-between"><span className="text-ink-500">LearnHub fee ({pct}%)</span><span className="text-ink-700">− {money(total - net)}</span></div>
            <div className="mt-1 flex justify-between border-t border-ink-200 pt-1"><span className="font-medium text-ink-700">You receive</span><span className="font-bold text-brand-600">{money(net)}</span></div>
          </>
        )}
      </div>

      {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{error}</p>}

      <button type="submit" disabled={!canSubmit} className="btn-primary w-full disabled:cursor-not-allowed disabled:opacity-40">
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Send proposal
      </button>
    </form>
  );
}
