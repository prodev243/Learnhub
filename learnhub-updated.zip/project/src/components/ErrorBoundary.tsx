import { Component, type ErrorInfo, type ReactNode } from 'react';

export class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Unhandled UI error', error, info.componentStack);
  }

  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="section flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
        <h1 className="font-display text-2xl font-extrabold text-ink-900">Something went wrong</h1>
        <p className="mt-2 max-w-sm text-sm text-ink-500">An unexpected error occurred. Reloading the page usually fixes it.</p>
        <button onClick={() => window.location.assign('/')} className="btn-primary mt-6">Reload LearnHub</button>
      </div>
    );
  }
}
