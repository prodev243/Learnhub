import { useState } from 'react';
import { CheckCircle2, Clock, CreditCard, Loader2, MessageSquare, Milestone as MilestoneIcon, RotateCcw, ShieldCheck, Star } from 'lucide-react';
import { Link } from '@/nav';
import { useToast } from '@/context/ToastContext';
import { useStartChat } from '@/chat';
import { createReview, releaseMilestone, requestMilestoneChanges, submitMilestone, trackEvent, openDispute } from '@/lib/api';
import { payMilestone } from '@/lib/paystack';
import { errorMessage, money } from '@/lib/format';
import { IS_PAYMENT_TEST_MODE } from '@/lib/config';
import { Avatar, ConfirmDialog, Modal, ProgressBar } from './ui';
import type { Contract, Milestone, MilestoneStatus } from '@/types';

const STYLES: Record<MilestoneStatus, { ring: string; bg: string; badge: string }> = {
  released: { ring: 'ring-brand-200', bg: 'bg-brand-50', badge: 'bg-brand-500 text-white' },
  in_review: { ring: 'ring-sky-200', bg: 'bg-sky-50', badge: 'bg-sky-500 text-white' },
  funded: { ring: 'ring-brand-100', bg: 'bg-white', badge: 'bg-brand-100 text-brand-700' },
  pending: { ring: 'ring-ink-100', bg: 'bg-ink-50', badge: 'bg-ink-200 text-ink-600' },
};

function label(status: MilestoneStatus, role: 'student' | 'tutor'): string {
  if (status === 'released') return 'Approved';
  if (status === 'in_review') return role === 'student' ? 'Awaiting your approval' : 'Delivered — awaiting approval';
  if (status === 'funded') return role === 'student' ? 'Paid — in progress' : 'Funded — start work';
  return role === 'student' ? 'Not funded yet' : 'Waiting for funding';
}

function StarPicker({ label: text, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm text-ink-700">{text}</span>
      <div className="flex gap-0.5" role="radiogroup" aria-label={text}>
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} type="button" role="radio" aria-checked={value === n} aria-label={`${n} star${n > 1 ? 's' : ''}`} onClick={() => onChange(n)} className="p-0.5">
            <Star className={`h-6 w-6 ${n <= value ? 'fill-sky-400 text-sky-400' : 'fill-ink-100 text-ink-200'}`} />
          </button>
        ))}
      </div>
    </div>
  );
}

function ReviewModal({ contract, studentId, onClose, onDone }: { contract: Contract; studentId: string; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [v, setV] = useState({ rating: 0, clarity: 0, improvement: 0, reliability: 0, patience: 0 });
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const ok = Object.values(v).every((n) => n > 0) && body.trim().length >= 10;

  const submit = async () => {
    setBusy(true);
    try {
      await createReview({ contractId: contract.id, studentId, tutorId: contract.tutorId, ...v, body });
      toast.success('Thanks for your review!');
      onDone();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open onClose={busy ? () => {} : onClose} title={`Review ${contract.tutorName}`}>
      <div className="space-y-3">
        <StarPicker label="Overall" value={v.rating} onChange={(n) => setV({ ...v, rating: n })} />
        <div className="space-y-2 rounded-xl bg-ink-50 p-3">
          <StarPicker label="Teaching clarity" value={v.clarity} onChange={(n) => setV({ ...v, clarity: n })} />
          <StarPicker label="Student improvement" value={v.improvement} onChange={(n) => setV({ ...v, improvement: n })} />
          <StarPicker label="Reliability" value={v.reliability} onChange={(n) => setV({ ...v, reliability: n })} />
          <StarPicker label="Patience" value={v.patience} onChange={(n) => setV({ ...v, patience: n })} />
        </div>
        <textarea rows={4} maxLength={2000} className="input resize-none" placeholder="What was it like working with this tutor? (at least 10 characters)" value={body} onChange={(e) => setBody(e.target.value)} />
        <div className="flex justify-end gap-3 pt-1">
          <button onClick={onClose} disabled={busy} className="btn-secondary">Not now</button>
          <button onClick={submit} disabled={!ok || busy} className="btn-primary disabled:opacity-50">{busy && <Loader2 className="h-4 w-4 animate-spin" />} Submit review</button>
        </div>
      </div>
    </Modal>
  );
}

export function ContractCard({ contract: c, role, userId, onChanged }: { contract: Contract; role: 'student' | 'tutor'; userId: string; onChanged: () => void }) {
  const toast = useToast();
  const chat = useStartChat();
  const [busyId, setBusyId] = useState<string | null>(null);
  const [funding, setFunding] = useState<Milestone | null>(null);
  const [approving, setApproving] = useState<Milestone | null>(null);
  const [reviewing, setReviewing] = useState(false);
  const [disputing, setDisputing] = useState<Milestone | null>(null);
  const [reason, setReason] = useState('');

  const released = c.milestones.filter((m) => m.status === 'released').length;
  const progress = c.milestones.length ? Math.round((released / c.milestones.length) * 100) : 0;
  const current = c.milestones.find((m) => m.status !== 'released');
  const other = role === 'student' ? { name: c.tutorName, id: c.tutorId } : { name: c.studentName, id: c.studentId };

  const act = async (m: Milestone, fn: () => Promise<void>, ok: string) => {
    setBusyId(m.id);
    try {
      await fn();
      toast.success(ok);
      onChanged();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  };

  const pay = async (m: Milestone) => {
    setBusyId(m.id);
    try {
      const result = await payMilestone(m.id);
      void trackEvent(userId,'payment_attempt',{milestone_id:m.id,result});
      if (result === 'paid') toast.success('Payment received — your tutor can start this milestone.');
      else if (result === 'pending') toast.info("We're still confirming your payment. Refresh in a moment if it doesn't update.");
      else toast.info('Payment cancelled.');
      setFunding(null);
      onChanged();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="card p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <Avatar name={other.name} size={44} ring />
          <div className="min-w-0">
            <Link to={{ name: 'mission', id: c.missionId }} className="block truncate font-display font-bold text-ink-900 hover:text-brand-600">{c.title}</Link>
            <p className="text-xs text-ink-400">{role === 'student' ? 'with' : 'student:'} {other.name}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-sm font-bold text-ink-900">{money(c.total)}</p>
          <p className="text-xs text-ink-400">{c.status === 'completed' ? 'Completed' : `${progress}% complete`}</p>
        </div>
      </div>

      <div className="mt-4"><ProgressBar percent={progress} /></div>

      <div className="mt-4 space-y-2">
        {c.milestones.map((m, i) => {
          const st = STYLES[m.status];
          const busy = busyId === m.id;
          const isCurrent = current?.id === m.id;
          return (
            <div key={m.id} className={`rounded-xl ${st.bg} p-3 ring-1 ${st.ring}`}>
              <div className="flex items-center gap-3">
                <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-xs font-bold ${st.badge}`}>
                  {m.status === 'released' ? <ShieldCheck className="h-4 w-4" /> : i + 1}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-ink-900">{m.title}</p>
                  {m.detail && <p className="text-xs text-ink-500">{m.detail}</p>}
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-ink-900">{money(m.amount)}</p>
                  <span className={`chip text-[10px] ${st.badge}`}>{label(m.status, role)}</span>
                </div>
              </div>

              {c.status === 'active' && isCurrent && (
                <div className="mt-3 flex flex-wrap items-center gap-2 pl-10">
                  {role === 'student' && m.status === 'pending' && (
                    <button onClick={() => setFunding(m)} disabled={busy} className="btn-primary py-2"><CreditCard className="h-4 w-4" /> Fund this milestone</button>
                  )}
                  {role === 'student' && m.status === 'in_review' && (
                    <>
                      <button onClick={() => setApproving(m)} disabled={busy} className="btn-primary py-2"><CheckCircle2 className="h-4 w-4" /> Approve work</button>
                      <button onClick={() => act(m, () => requestMilestoneChanges(m.id), 'Sent back to your tutor for changes.')} disabled={busy} className="btn-secondary py-2">
                        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />} Request changes
                      </button>
                    </>
                  )}
                  {role === 'student' && m.status === 'funded' && <p className="flex items-center gap-1.5 text-xs text-ink-500"><Clock className="h-3.5 w-3.5" /> Your tutor is working on this milestone.</p>}
                  {role === 'tutor' && m.status === 'funded' && (
                    <button onClick={() => act(m, () => submitMilestone(m.id), 'Marked as delivered. The student will review it.')} disabled={busy} className="btn-primary py-2">
                      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />} Mark as delivered
                    </button>
                  )}
                  {role === 'tutor' && m.status === 'pending' && <p className="flex items-center gap-1.5 text-xs text-ink-500"><Clock className="h-3.5 w-3.5" /> Waiting for the student to fund this milestone.</p>}
                  {role === 'tutor' && m.status === 'in_review' && <p className="flex items-center gap-1.5 text-xs text-ink-500"><Clock className="h-3.5 w-3.5" /> The student is reviewing your work.</p>}
                </div>
              )}

              {role === 'tutor' && m.tutorAmount != null && m.status !== 'pending' && (
                <p className="mt-2 pl-10 text-xs text-ink-500">You receive {money(m.tutorAmount)} (after {money(m.platformFee ?? 0)} fee), paid to your bank by Paystack.</p>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-ink-100 pt-4">
        <button onClick={() => chat.start(other.id)} disabled={chat.busy} className="btn-secondary py-2"><MessageSquare className="h-4 w-4" /> Message {other.name.split(' ')[0]}</button>
        {role === 'student' && current && (current.status === 'funded' || current.status === 'in_review') && <button onClick={() => setDisputing(current)} className="btn-secondary py-2 text-red-600"><ShieldCheck className="h-4 w-4" /> Open dispute</button>}
        {role === 'student' && c.status === 'completed' && !c.reviewed && (
          <button onClick={() => setReviewing(true)} className="btn-primary py-2"><Star className="h-4 w-4" /> Leave a review</button>
        )}
        {role === 'student' && c.status === 'completed' && c.reviewed && <span className="chip bg-brand-50 text-brand-700"><CheckCircle2 className="h-3.5 w-3.5" /> Reviewed</span>}
      </div>

      <Modal open={disputing !== null} onClose={busyId ? () => {} : () => setDisputing(null)} title="Open a dispute">
        {disputing && <div><p className="text-sm text-ink-600">Tell LearnHub what is wrong with this milestone. Do not include passwords or bank details.</p><textarea rows={5} maxLength={3000} className="input mt-3 resize-none" placeholder="Explain the issue (at least 10 characters)" value={reason} onChange={e=>setReason(e.target.value)}/><div className="mt-4 flex justify-end gap-3"><button onClick={()=>setDisputing(null)} className="btn-secondary">Cancel</button><button disabled={reason.trim().length<10||busyId!==null} onClick={async()=>{setBusyId(disputing.id);try{await openDispute(c.id,disputing.id,reason);toast.success('Dispute opened. LearnHub support will review it.');setDisputing(null);setReason('');onChanged();}catch(e){toast.error(errorMessage(e));}finally{setBusyId(null);}}} className="btn-primary">Open dispute</button></div></div>}
      </Modal>

      {/* Fund modal */}
      <Modal open={funding !== null} onClose={busyId ? () => {} : () => setFunding(null)} title="Fund this milestone">
        {funding && (
          <div>
            <div className="rounded-xl bg-ink-50 p-4">
              <p className="flex items-center gap-2 text-sm font-semibold text-ink-900"><MilestoneIcon className="h-4 w-4 text-brand-600" /> {funding.title}</p>
              <p className="mt-3 text-3xl font-extrabold text-ink-900">{money(funding.amount)}</p>
              <p className="mt-1 text-xs text-ink-500">Paid securely through Paystack. Your tutor is paid directly to their bank account.</p>
            </div>
            {IS_PAYMENT_TEST_MODE && (
              <p className="mt-3 rounded-lg bg-amber-50 p-3 text-xs text-amber-900">
                <span className="font-semibold">Test mode:</span> use card 4084 0840 8408 4081, any future expiry and CVV 408. No real money is charged.
              </p>
            )}
            <div className="mt-5 flex justify-end gap-3">
              <button onClick={() => setFunding(null)} disabled={busyId !== null} className="btn-secondary">Cancel</button>
              <button onClick={() => pay(funding)} disabled={busyId !== null} className="btn-primary">
                {busyId ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />} Pay {money(funding.amount)}
              </button>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={approving !== null} busy={busyId !== null} confirmLabel="Approve" title="Approve this milestone?"
        message="Confirm the work was delivered as agreed. This unlocks the next milestone."
        onCancel={() => setApproving(null)}
        onConfirm={() => approving && act(approving, async () => { await releaseMilestone(approving.id); setApproving(null); }, 'Milestone approved.')}
      />

      {reviewing && <ReviewModal contract={c} studentId={userId} onClose={() => setReviewing(false)} onDone={() => { setReviewing(false); onChanged(); }} />}
    </div>
  );
}
