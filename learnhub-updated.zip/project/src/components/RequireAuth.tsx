import type { ReactNode } from 'react';
import { Lock } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useNav } from '@/nav';
import { PageLoader } from './ui';
import type { Role } from '@/types';

/** Renders children only for signed-in users (optionally of a specific role). */
export function RequireAuth({ children, role, roleMessage }: { children: ReactNode; role?: Role; roleMessage?: string }) {
  const { user, profile, loading } = useAuth();
  const { navigate } = useNav();

  if (loading) return <PageLoader />;

  if (!user) {
    return (
      <div className="section flex min-h-[50vh] flex-col items-center justify-center py-20 text-center">
        <span className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-50 text-brand-600"><Lock className="h-7 w-7" /></span>
        <h1 className="mt-5 font-display text-2xl font-extrabold text-ink-900">Please log in to continue</h1>
        <p className="mt-2 max-w-sm text-sm text-ink-500">You need a free LearnHub account to use this page.</p>
        <div className="mt-6 flex gap-3">
          <button onClick={() => navigate({ name: 'login', next: window.location.pathname })} className="btn-primary">Log in</button>
          <button onClick={() => navigate({ name: 'signup', next: window.location.pathname })} className="btn-secondary">Create account</button>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="section py-20 text-center">
        <p className="font-semibold text-ink-800">We couldn't load your profile.</p>
        <p className="mt-1 text-sm text-ink-500">Please refresh the page. If this keeps happening, contact support.</p>
      </div>
    );
  }

  if (role && profile.role !== role) {
    return (
      <div className="section py-20 text-center">
        <p className="font-semibold text-ink-800">{roleMessage ?? `This page is only for ${role}s.`}</p>
        <button onClick={() => navigate({ name: 'dashboard' })} className="btn-primary mt-5">Go to dashboard</button>
      </div>
    );
  }

  return <>{children}</>;
}
