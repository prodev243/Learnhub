import { supabase } from './supabase';

/** Call a Supabase edge function and turn any failure into a readable Error. */
export async function callFunction<T>(name: string, body?: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.functions.invoke(name, { body: body ?? {} });
  if (error) {
    let message = 'The request failed. Please try again.';
    const ctx = (error as { context?: unknown }).context;
    if (ctx instanceof Response) {
      const parsed = await ctx.json().catch(() => null);
      if (parsed && typeof parsed.error === 'string') message = parsed.error;
    } else if (error.message) {
      message = /Failed to send|fetch/i.test(error.message)
        ? 'Could not reach the server. Check your connection and try again.'
        : error.message;
    }
    throw new Error(message);
  }
  if (data && typeof data === 'object' && 'error' in data && typeof (data as { error: unknown }).error === 'string') {
    throw new Error((data as { error: string }).error);
  }
  return data as T;
}

export interface Bank {
  name: string;
  code: string;
}

export const listBanks = () => callFunction<{ banks: Bank[] }>('paystack-banks').then((r) => r.banks);

export const savePayoutAccount = (bank: Bank, accountNumber: string) =>
  callFunction<{ ok: boolean; bank_name: string; account_last4: string }>('paystack-subaccount', {
    bank_code: bank.code,
    bank_name: bank.name,
    account_number: accountNumber,
  });
