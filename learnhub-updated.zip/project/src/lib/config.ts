const env = import.meta.env;

export const APP_NAME = 'LearnHub';

export const SUPABASE_URL: string = (env.VITE_SUPABASE_URL ?? '').trim();
export const SUPABASE_ANON_KEY: string = (env.VITE_SUPABASE_ANON_KEY ?? '').trim();

/** True once real Supabase credentials have been provided. */
export const isSupabaseConfigured =
  /^https?:\/\//.test(SUPABASE_URL) &&
  SUPABASE_ANON_KEY.length > 20 &&
  !SUPABASE_URL.includes('your-project-ref') &&
  !SUPABASE_ANON_KEY.includes('your-supabase');

/** Paystack public key — only used to decide whether to show the "test mode" notice. */
export const PAYSTACK_PUBLIC_KEY: string = (env.VITE_PAYSTACK_PUBLIC_KEY ?? '').trim();
export const IS_PAYMENT_TEST_MODE = PAYSTACK_PUBLIC_KEY.startsWith('pk_test_');

export const CURRENCY: string = (env.VITE_CURRENCY ?? 'NGN').trim().toUpperCase() || 'NGN';
export const SUPPORT_EMAIL: string = (env.VITE_SUPPORT_EMAIL ?? '').trim();

const MIN_BUDGET_BY_CURRENCY: Record<string, number> = { NGN: 5000, GHS: 50, ZAR: 100, KES: 500, USD: 10 };
/** Smallest sensible goal budget / milestone amount for the configured currency. */
export const MIN_BUDGET = MIN_BUDGET_BY_CURRENCY[CURRENCY] ?? 10;
export const DEFAULT_BUDGET = MIN_BUDGET * 5;

export const LAUNCH_CATEGORY: string = (env.VITE_LAUNCH_CATEGORY ?? '').trim();
