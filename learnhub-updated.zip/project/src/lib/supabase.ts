import { createClient } from '@supabase/supabase-js';
import { SUPABASE_ANON_KEY, SUPABASE_URL, isSupabaseConfigured } from './config';

// When credentials are missing the app renders a setup screen and never calls this client,
// so a harmless placeholder keeps createClient() from throwing at import time.
export const supabase = createClient(
  isSupabaseConfigured ? SUPABASE_URL : 'http://localhost:54321',
  isSupabaseConfigured ? SUPABASE_ANON_KEY : 'not-configured',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      // Implicit flow: email-confirmation and password-reset links work even when the
      // person opens them in a different browser than the one they signed up in.
      flowType: 'implicit',
    },
  },
);
