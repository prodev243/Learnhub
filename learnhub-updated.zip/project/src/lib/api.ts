/* eslint-disable @typescript-eslint/no-explicit-any */
// Data-access layer: every Supabase call in the app lives here.
import { supabase } from './supabase';
import { callFunction } from './functions';
import { errorMessage, sanitizeSearch } from './format';
import { LAUNCH_CATEGORY } from './config';
import type {
  Category, Contest, ContestEntry, Contract, Conversation, Level, Message, Milestone, Mission,
  Profile, Proposal, ProposalMilestone, Review, Role, Tutor, TutorProfileForm,
} from '@/types';

export const PAGE_SIZE = 12;

function check<T extends { error: { message: string } | null }>(res: T): T {
  if (res.error) throw new Error(friendlyDbError(res.error.message));
  return res;
}

function friendlyDbError(message: string): string {
  if (/permission denied|row-level security/i.test(message)) return 'You are not allowed to do that.';
  if (/proposals_mission_id_tutor_id_key/i.test(message)) return 'You have already sent (or withdrawn) a proposal for this goal.';
  if (/duplicate key/i.test(message)) return 'That already exists.';
  if (/Failed to fetch|NetworkError|network/i.test(message)) return 'Network problem. Please check your connection and try again.';
  return message;
}

// ---------------------------------------------------------------------------
// Mappers
// ---------------------------------------------------------------------------
const pct = (v: number | null | undefined) => (v == null ? null : Math.round((Number(v) / 5) * 100));

function mapTutor(r: any): Tutor {
  const hasReviews = Number(r.review_count) > 0;
  const scores = hasReviews
    ? [
        { label: 'Teaching clarity', value: pct(r.avg_clarity) },
        { label: 'Student improvement', value: pct(r.avg_improvement) },
        { label: 'Reliability', value: pct(r.avg_reliability) },
        { label: 'Patience', value: pct(r.avg_patience) },
      ].filter((s): s is { label: string; value: number } => s.value != null)
    : [];
  return {
    id: r.id,
    name: r.full_name,
    avatarUrl: r.avatar_url ?? null,
    headline: r.headline ?? '',
    bio: r.bio ?? '',
    location: r.location ?? '',
    categories: (r.categories ?? []) as Category[],
    skills: r.skills ?? [],
    priceFrom: Number(r.price_from) || 0,
    guarantee: r.guarantee ? String(r.guarantee) : null,
    responseTime: r.response_time ?? '',
    verified: Boolean(r.verified),
    rating: r.avg_rating == null ? null : Math.round(Number(r.avg_rating) * 10) / 10,
    reviewCount: Number(r.review_count) || 0,
    completedProjects: Number(r.completed_count) || 0,
    scores,
  };
}

function mapMission(r: any): Mission {
  return {
    id: r.id,
    studentId: r.student_id,
    student: r.student?.full_name ?? 'Student',
    title: r.title,
    category: r.category,
    level: r.level,
    budget: Number(r.budget),
    deadline: r.deadline ?? '',
    availability: r.availability ?? '',
    learningStyle: r.learning_style ?? '',
    description: r.description,
    status: r.status,
    proposalsCount: Number(r.proposals_count) || 0,
    createdAt: r.created_at,
  };
}

function mapProposal(r: any): Proposal {
  return {
    id: r.id,
    missionId: r.mission_id,
    tutorId: r.tutor_id,
    tutorName: r.tutor?.full_name ?? 'Tutor',
    coverLetter: r.cover_letter,
    approach: r.approach ?? [],
    price: Number(r.price),
    timeline: r.timeline,
    milestones: ((r.milestones ?? []) as any[]).map((m) => ({
      title: String(m.title ?? ''),
      detail: String(m.detail ?? ''),
      amount: Number(m.amount) || 0,
    })),
    status: r.status,
    createdAt: r.created_at,
  };
}

function mapMilestone(r: any): Milestone {
  return {
    id: r.id,
    contractId: r.contract_id,
    position: r.position,
    title: r.title,
    detail: r.detail ?? '',
    amount: Number(r.amount),
    status: r.status,
    platformFee: r.platform_fee == null ? null : Number(r.platform_fee),
    tutorAmount: r.tutor_amount == null ? null : Number(r.tutor_amount),
  };
}

const MISSION_SELECT = '*, student:profiles!student_id(full_name)';

// ---------------------------------------------------------------------------
// Profiles
// ---------------------------------------------------------------------------
export async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data } = check(await supabase.from('profiles').select('id, role, full_name, avatar_url, points').eq('id', userId).maybeSingle());
  if (!data) return null;
  return { id: data.id, role: data.role as Role, fullName: data.full_name, avatarUrl: data.avatar_url ?? null, points: Number(data.points) || 0 };
}

export async function updateFullName(userId: string, fullName: string): Promise<void> {
  check(await supabase.from('profiles').update({ full_name: fullName.trim() }).eq('id', userId));
}

export async function fetchTutorProfile(userId: string): Promise<TutorProfileForm | null> {
  const { data } = check(await supabase.from('tutor_profiles').select('*').eq('user_id', userId).maybeSingle());
  if (!data) return null;
  return {
    headline: data.headline ?? '',
    bio: data.bio ?? '',
    location: data.location ?? '',
    categories: (data.categories ?? []) as Category[],
    skills: data.skills ?? [],
    priceFrom: Number(data.price_from) || 0,
    guarantee: data.guarantee ?? '',
    responseTime: data.response_time ?? '',
    isPublished: Boolean(data.is_published),
    verified: Boolean(data.verified),
    verificationStatus: data.verification_status ?? 'unsubmitted',
  };
}

export async function saveTutorProfile(userId: string, f: Omit<TutorProfileForm, 'isPublished' | 'verified'>): Promise<void> {
  check(
    await supabase
      .from('tutor_profiles')
      .update({
        headline: f.headline.trim(),
        bio: f.bio.trim(),
        location: f.location.trim(),
        categories: f.categories,
        skills: f.skills,
        price_from: f.priceFrom,
        guarantee: f.guarantee.trim() === '' ? null : f.guarantee.trim(),
        response_time: f.responseTime.trim(),
      })
      .eq('user_id', userId),
  );
}

export async function fetchCommissionPercent(): Promise<number> {
  const { data } = await supabase.from('app_config').select('value').eq('key', 'commission_percent').maybeSingle();
  const n = Number(data?.value);
  return Number.isFinite(n) && n >= 0 && n < 100 ? n : 0;
}

// ---------------------------------------------------------------------------
// Tutors
// ---------------------------------------------------------------------------
export interface TutorFilters {
  q: string;
  category: Category | 'all';
  minRating: number;
  guaranteeOnly: boolean;
  sort: 'rating' | 'projects' | 'price-low' | 'price-high';
}

export async function listTutors(f: TutorFilters, page: number): Promise<{ items: Tutor[]; total: number }> {
  let query = supabase.from('tutor_directory').select('*', { count: 'exact' });
  if (LAUNCH_CATEGORY) query = query.contains('categories', [LAUNCH_CATEGORY]);
  else if (f.category !== 'all') query = query.contains('categories', [f.category]);
  if (f.minRating > 0) query = query.gte('avg_rating', f.minRating);
  if (f.guaranteeOnly) query = query.not('guarantee', 'is', null);
  const q = sanitizeSearch(f.q);
  if (q) query = query.or(`full_name.ilike.%${q}%,headline.ilike.%${q}%,bio.ilike.%${q}%`);

  if (f.sort === 'rating') query = query.order('avg_rating', { ascending: false, nullsFirst: false }).order('review_count', { ascending: false });
  if (f.sort === 'projects') query = query.order('completed_count', { ascending: false });
  if (f.sort === 'price-low') query = query.order('price_from', { ascending: true });
  if (f.sort === 'price-high') query = query.order('price_from', { ascending: false });
  query = query.order('full_name', { ascending: true });

  const from = page * PAGE_SIZE;
  const { data, count } = check(await query.range(from, from + PAGE_SIZE - 1));
  return { items: ((data ?? []) as any[]).map(mapTutor), total: count ?? 0 };
}

export async function listTopTutors(limit: number): Promise<Tutor[]> {
  const { data } = check(
    await supabase
      .from('tutor_directory')
      .select('*')
      .order('avg_rating', { ascending: false, nullsFirst: false })
      .order('review_count', { ascending: false })
      .limit(limit),
  );
  return ((data ?? []) as any[]).map(mapTutor);
}

/** Every published tutor (used by the matching quiz). Capped for safety. */
export async function listAllTutors(): Promise<Tutor[]> {
  const { data } = check(await supabase.from('tutor_directory').select('*').limit(300));
  return ((data ?? []) as any[]).map(mapTutor);
}

export async function listTutorsByIds(ids: string[]): Promise<Tutor[]> {
  if (ids.length === 0) return [];
  const { data } = check(await supabase.from('tutor_directory').select('*').in('id', ids));
  return ((data ?? []) as any[]).map(mapTutor);
}

export async function getTutor(id: string): Promise<Tutor | null> {
  const { data } = check(await supabase.from('tutor_directory').select('*').eq('id', id).maybeSingle());
  return data ? mapTutor(data) : null;
}

export async function listReviews(tutorId: string): Promise<Review[]> {
  const { data } = check(
    await supabase
      .from('reviews')
      .select('*, student:profiles!student_id(full_name)')
      .eq('tutor_id', tutorId)
      .order('created_at', { ascending: false })
      .limit(50),
  );
  return ((data ?? []) as any[]).map((r) => ({
    id: r.id,
    student: r.student?.full_name ?? 'Student',
    mission: r.mission_title ?? '',
    rating: r.rating,
    createdAt: r.created_at,
    text: r.body,
    subScores: [
      { label: 'Clarity', value: pct(r.clarity) ?? 0 },
      { label: 'Improvement', value: pct(r.improvement) ?? 0 },
      { label: 'Reliability', value: pct(r.reliability) ?? 0 },
      { label: 'Patience', value: pct(r.patience) ?? 0 },
    ],
  }));
}

export interface ReviewInput {
  contractId: string;
  studentId: string;
  tutorId: string;
  rating: number;
  clarity: number;
  improvement: number;
  reliability: number;
  patience: number;
  body: string;
}

export async function createReview(i: ReviewInput): Promise<void> {
  check(
    await supabase.from('reviews').insert({
      contract_id: i.contractId,
      student_id: i.studentId,
      tutor_id: i.tutorId,
      rating: i.rating,
      clarity: i.clarity,
      improvement: i.improvement,
      reliability: i.reliability,
      patience: i.patience,
      body: i.body.trim(),
    }),
  );
}

// ---------------------------------------------------------------------------
// Missions
// ---------------------------------------------------------------------------
export interface MissionFilters {
  q: string;
  category: Category | 'all';
  level: Level | 'all';
  sort: 'recent' | 'budget-high' | 'budget-low' | 'proposals';
}

export async function listMissions(f: MissionFilters, page: number): Promise<{ items: Mission[]; total: number }> {
  let query = supabase.from('missions').select(MISSION_SELECT, { count: 'exact' }).eq('status', 'open');
  if (LAUNCH_CATEGORY) query = query.eq('category', LAUNCH_CATEGORY);
  else if (f.category !== 'all') query = query.eq('category', f.category);
  if (f.level !== 'all') query = query.eq('level', f.level);
  const q = sanitizeSearch(f.q);
  if (q) query = query.or(`title.ilike.%${q}%,description.ilike.%${q}%`);

  if (f.sort === 'recent') query = query.order('created_at', { ascending: false });
  if (f.sort === 'budget-high') query = query.order('budget', { ascending: false });
  if (f.sort === 'budget-low') query = query.order('budget', { ascending: true });
  if (f.sort === 'proposals') query = query.order('proposals_count', { ascending: false }).order('created_at', { ascending: false });

  const from = page * PAGE_SIZE;
  const { data, count } = check(await query.range(from, from + PAGE_SIZE - 1));
  return { items: ((data ?? []) as any[]).map(mapMission), total: count ?? 0 };
}

export async function listLatestMissions(limit: number): Promise<Mission[]> {
  const { data } = check(
    await supabase.from('missions').select(MISSION_SELECT).eq('status', 'open').order('created_at', { ascending: false }).limit(limit),
  );
  return ((data ?? []) as any[]).map(mapMission);
}

export async function listMissionsByIds(ids: string[]): Promise<Mission[]> {
  if (ids.length === 0) return [];
  const { data } = check(await supabase.from('missions').select(MISSION_SELECT).in('id', ids));
  return ((data ?? []) as any[]).map(mapMission);
}

export async function listMyMissions(studentId: string): Promise<Mission[]> {
  const { data } = check(
    await supabase.from('missions').select(MISSION_SELECT).eq('student_id', studentId).order('created_at', { ascending: false }),
  );
  return ((data ?? []) as any[]).map(mapMission);
}

export async function getMission(id: string): Promise<Mission | null> {
  const { data } = check(await supabase.from('missions').select(MISSION_SELECT).eq('id', id).maybeSingle());
  return data ? mapMission(data) : null;
}

export interface MissionInput {
  studentId: string;
  title: string;
  category: Category;
  level: Level;
  budget: number;
  deadline: string;
  availability: string;
  learningStyle: string;
  description: string;
}

export async function createMission(i: MissionInput): Promise<string> {
  const { data } = check(
    await supabase
      .from('missions')
      .insert({
        student_id: i.studentId,
        title: i.title.trim(),
        category: i.category,
        level: i.level,
        budget: i.budget,
        deadline: i.deadline.trim(),
        availability: i.availability.trim(),
        learning_style: i.learningStyle.trim(),
        description: i.description.trim(),
      })
      .select('id')
      .single(),
  );
  const id = data!.id as string;
  void trackEvent(i.studentId,'mission_created',{category:i.category,level:i.level});
  return id;
}

export async function cancelMission(id: string): Promise<void> {
  check(await supabase.from('missions').update({ status: 'cancelled' }).eq('id', id));
}

// ---------------------------------------------------------------------------
// Proposals
// ---------------------------------------------------------------------------
const PROPOSAL_SELECT = '*, tutor:profiles!tutor_id(full_name)';

export async function listProposalsForMission(missionId: string): Promise<Proposal[]> {
  const { data } = check(
    await supabase.from('proposals').select(PROPOSAL_SELECT).eq('mission_id', missionId).neq('status', 'withdrawn').order('created_at', { ascending: true }),
  );
  const proposals: Proposal[] = ((data ?? []) as any[]).map(mapProposal);
  const tutors = await listTutorsByIds([...new Set(proposals.map((p) => p.tutorId))]);
  const byId = new Map(tutors.map((t) => [t.id, t]));
  return proposals.map((p) => ({ ...p, tutor: byId.get(p.tutorId) }));
}

export async function listMyProposals(tutorId: string): Promise<(Proposal & { missionTitle: string })[]> {
  const { data } = check(
    await supabase
      .from('proposals')
      .select(`${PROPOSAL_SELECT}, mission:missions!mission_id(title)`)
      .eq('tutor_id', tutorId)
      .order('created_at', { ascending: false }),
  );
  return ((data ?? []) as any[]).map((r) => ({ ...mapProposal(r), missionTitle: r.mission?.title ?? 'Learning goal' }));
}

export interface ProposalInput {
  missionId: string;
  tutorId: string;
  coverLetter: string;
  approach: string[];
  timeline: string;
  milestones: ProposalMilestone[];
}

export async function createProposal(i: ProposalInput): Promise<void> {
  const milestones = i.milestones.map((m) => ({ title: m.title.trim(), detail: m.detail.trim(), amount: Math.round(m.amount * 100) / 100 }));
  const price = Math.round(milestones.reduce((s, m) => s + m.amount, 0) * 100) / 100;
  check(
    await supabase.from('proposals').insert({
      mission_id: i.missionId,
      tutor_id: i.tutorId,
      cover_letter: i.coverLetter.trim(),
      approach: i.approach,
      price,
      timeline: i.timeline.trim(),
      milestones,
    }),
  );
  void trackEvent(i.tutorId,'proposal_created',{mission_id:i.missionId,price});
}

export async function withdrawProposal(id: string): Promise<void> {
  check(await supabase.from('proposals').update({ status: 'withdrawn' }).eq('id', id));
}

export async function acceptProposal(id: string): Promise<string> {
  const { data } = check(await supabase.rpc('accept_proposal', { p_proposal_id: id }));
  return data as string;
}

// ---------------------------------------------------------------------------
// Contracts & milestones
// ---------------------------------------------------------------------------
export async function listMyContracts(userId: string): Promise<Contract[]> {
  const { data } = check(
    await supabase
      .from('contracts')
      .select('*, milestones(*), student:profiles!student_id(full_name), tutor:profiles!tutor_id(full_name)')
      .or(`student_id.eq.${userId},tutor_id.eq.${userId}`)
      .order('created_at', { ascending: false })
      .order('position', { referencedTable: 'milestones', ascending: true }),
  );
  const rows = (data ?? []) as any[];
  let reviewed = new Set<string>();
  if (rows.length > 0) {
    const { data: rev } = check(await supabase.from('reviews').select('contract_id').in('contract_id', rows.map((r) => r.id)));
    reviewed = new Set(((rev ?? []) as any[]).map((r) => r.contract_id as string));
  }
  return rows.map((r) => ({
    id: r.id,
    missionId: r.mission_id,
    title: r.title,
    studentId: r.student_id,
    studentName: r.student?.full_name ?? 'Student',
    tutorId: r.tutor_id,
    tutorName: r.tutor?.full_name ?? 'Tutor',
    total: Number(r.total),
    status: r.status,
    createdAt: r.created_at,
    milestones: ((r.milestones ?? []) as any[]).map(mapMilestone).sort((a, b) => a.position - b.position),
    reviewed: reviewed.has(r.id),
  }));
}

export async function submitMilestone(id: string): Promise<void> {
  check(await supabase.rpc('submit_milestone', { p_milestone_id: id }));
}
export async function requestMilestoneChanges(id: string): Promise<void> {
  check(await supabase.rpc('request_milestone_changes', { p_milestone_id: id }));
}
export async function releaseMilestone(id: string): Promise<void> {
  check(await supabase.rpc('release_milestone', { p_milestone_id: id }));
}

// ---------------------------------------------------------------------------
// Saved items & invites
// ---------------------------------------------------------------------------
export type SavedKind = 'mission' | 'tutor';

export async function listSavedIds(userId: string, kind: SavedKind): Promise<string[]> {
  const { data } = check(await supabase.from('saved_items').select('target_id').eq('user_id', userId).eq('kind', kind).order('created_at', { ascending: false }));
  return ((data ?? []) as any[]).map((r) => r.target_id as string);
}

export async function setSaved(userId: string, kind: SavedKind, targetId: string, saved: boolean): Promise<void> {
  if (saved) {
    check(await supabase.from('saved_items').upsert({ user_id: userId, kind, target_id: targetId }, { onConflict: 'user_id,kind,target_id', ignoreDuplicates: true }));
  } else {
    check(await supabase.from('saved_items').delete().eq('user_id', userId).eq('kind', kind).eq('target_id', targetId));
  }
}

export async function inviteTutor(missionId: string, tutorId: string): Promise<void> {
  check(await supabase.from('mission_invites').upsert({ mission_id: missionId, tutor_id: tutorId }, { onConflict: 'mission_id,tutor_id', ignoreDuplicates: true }));
}

export async function listMyInvites(tutorId: string): Promise<Mission[]> {
  const { data } = check(await supabase.from('mission_invites').select('mission_id').eq('tutor_id', tutorId).order('created_at', { ascending: false }));
  const ids: string[] = ((data ?? []) as any[]).map((r) => r.mission_id as string);
  const missions = await listMissionsByIds(ids);
  const order = new Map<string, number>(ids.map((id, i): [string, number] => [id, i]));
  return missions.filter((m) => m.status === 'open').sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));
}

// ---------------------------------------------------------------------------
// Contests
// ---------------------------------------------------------------------------
function mapContest(r: any): Contest {
  return {
    id: r.id,
    title: r.title,
    sponsor: r.sponsor,
    category: r.category,
    prize: Number(r.prize) || 0,
    description: r.description,
    deadline: r.deadline,
    status: r.status,
    entriesCount: Number(r.entries?.[0]?.count) || 0,
  };
}

export async function listContests(): Promise<Contest[]> {
  const { data } = check(await supabase.from('contests').select('*, entries:contest_entries(count)').order('created_at', { ascending: false }));
  return ((data ?? []) as any[]).map(mapContest);
}

export async function getContest(id: string): Promise<Contest | null> {
  const { data } = check(await supabase.from('contests').select('*, entries:contest_entries(count)').eq('id', id).maybeSingle());
  return data ? mapContest(data) : null;
}

export async function listContestEntries(contestId: string): Promise<ContestEntry[]> {
  const { data } = check(
    await supabase
      .from('contest_entries')
      .select('*, tutor:profiles!tutor_id(full_name)')
      .eq('contest_id', contestId)
      .order('votes', { ascending: false })
      .order('created_at', { ascending: true }),
  );
  return ((data ?? []) as any[]).map((r) => ({
    id: r.id,
    contestId: r.contest_id,
    tutorId: r.tutor_id,
    tutorName: r.tutor?.full_name ?? 'Tutor',
    title: r.title,
    description: r.description,
    votes: r.votes,
    createdAt: r.created_at,
  }));
}

export async function listMyVotes(userId: string, entryIds: string[]): Promise<Set<string>> {
  if (entryIds.length === 0) return new Set();
  const { data } = check(await supabase.from('contest_votes').select('entry_id').eq('user_id', userId).in('entry_id', entryIds));
  return new Set(((data ?? []) as any[]).map((r) => r.entry_id as string));
}

export async function setVote(userId: string, entryId: string, voted: boolean): Promise<void> {
  if (voted) check(await supabase.from('contest_votes').insert({ entry_id: entryId, user_id: userId }));
  else check(await supabase.from('contest_votes').delete().eq('entry_id', entryId).eq('user_id', userId));
}

export async function createContestEntry(contestId: string, tutorId: string, title: string, description: string): Promise<void> {
  check(await supabase.from('contest_entries').insert({ contest_id: contestId, tutor_id: tutorId, title: title.trim(), description: description.trim() }));
}

// ---------------------------------------------------------------------------
// Messaging
// ---------------------------------------------------------------------------
export async function startConversation(otherUserId: string): Promise<string> {
  const { data } = check(await supabase.rpc('get_or_create_conversation', { p_other: otherUserId }));
  return data as string;
}

export async function listConversations(userId: string): Promise<Conversation[]> {
  const { data } = check(await supabase.from('conversations').select('*').order('last_message_at', { ascending: false }).limit(100));
  const rows = (data ?? []) as any[];
  const otherIds = rows.map((r) => (r.user_a === userId ? r.user_b : r.user_a) as string);
  const names = new Map<string, string>();
  if (otherIds.length > 0) {
    const { data: profs } = check(await supabase.from('profiles').select('id, full_name').in('id', otherIds));
    ((profs ?? []) as any[]).forEach((p) => names.set(p.id, p.full_name));
  }
  return rows.map((r, i) => ({
    id: r.id,
    otherId: otherIds[i],
    otherName: names.get(otherIds[i]) ?? 'User',
    lastMessage: r.last_message ?? '',
    lastMessageAt: r.last_message_at,
  }));
}

function mapMessage(r: any): Message {
  return { id: r.id, conversationId: r.conversation_id, senderId: r.sender_id, body: r.body, createdAt: r.created_at };
}

export async function listMessages(conversationId: string): Promise<Message[]> {
  const { data } = check(await supabase.from('messages').select('*').eq('conversation_id', conversationId).order('created_at', { ascending: true }).limit(300));
  return ((data ?? []) as any[]).map(mapMessage);
}

export async function sendMessage(conversationId: string, senderId: string, body: string): Promise<Message> {
  const { data } = check(
    await supabase.from('messages').insert({ conversation_id: conversationId, sender_id: senderId, body: body.trim() }).select('*').single(),
  );
  return mapMessage(data);
}

export function subscribeToMessages(conversationId: string, onMessage: (m: Message) => void): () => void {
  const channel = supabase
    .channel(`messages:${conversationId}`)
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` },
      (payload: any) => onMessage(mapMessage(payload.new)),
    )
    .subscribe();
  return () => {
    void supabase.removeChannel(channel);
  };
}

// Re-export so pages can present errors consistently.
export { errorMessage };

// ---------------------------------------------------------------------------
// Payout account (tutor bank details -> Paystack subaccount)
// ---------------------------------------------------------------------------
export interface PayoutAccount {
  bankName: string;
  accountLast4: string;
}

export async function fetchPayoutAccount(userId: string): Promise<PayoutAccount | null> {
  const { data } = check(await supabase.from('tutor_payout_accounts').select('bank_name, account_last4').eq('user_id', userId).maybeSingle());
  return data ? { bankName: data.bank_name ?? '', accountLast4: data.account_last4 } : null;
}


// ---------------------------------------------------------------------------
// Notifications, analytics, profile photos and account controls
// ---------------------------------------------------------------------------
export interface AppNotification { id: string; type: string; title: string; body: string; href: string | null; readAt: string | null; createdAt: string; }
export async function listNotifications(userId: string): Promise<AppNotification[]> {
  const { data } = check(await supabase.from('notifications').select('*').eq('user_id', userId).order('created_at',{ascending:false}).limit(50));
  return ((data ?? []) as any[]).map(n => ({id:n.id,type:n.type,title:n.title,body:n.body,href:n.href ?? null,readAt:n.read_at ?? null,createdAt:n.created_at}));
}
export async function markNotificationRead(id: string): Promise<void> { check(await supabase.from('notifications').update({read_at:new Date().toISOString()}).eq('id',id)); }
export async function markAllNotificationsRead(userId: string): Promise<void> { check(await supabase.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',userId).is('read_at',null)); }
export async function trackEvent(userId: string | null, eventName: string, properties: Record<string, unknown> = {}): Promise<void> {
  if (!userId) return;
  const { error } = await supabase.from('analytics_events').insert({user_id:userId,event_name:eventName,properties,path:window.location.pathname});
  if (error) console.warn('analytics event failed', error.message);
}
export async function uploadAvatar(userId: string, file: File): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('Please choose an image file.');
  if (file.size > 5 * 1024 * 1024) throw new Error('Profile photos must be 5 MB or smaller.');
  const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
  const path = `${userId}/avatar.${ext}`;
  const { error } = await supabase.storage.from('avatars').upload(path,file,{upsert:true,contentType:file.type,cacheControl:'3600'});
  if (error) throw new Error(error.message);
  const { data } = supabase.storage.from('avatars').getPublicUrl(path);
  const url = `${data.publicUrl}?v=${Date.now()}`;
  check(await supabase.from('profiles').update({avatar_url:url}).eq('id',userId));
  return url;
}
export async function requestTutorVerification(): Promise<void> { check(await supabase.rpc('request_tutor_verification')); }
export async function openDispute(contractId: string, milestoneId: string | null, reason: string): Promise<string> {
  const { data } = check(await supabase.rpc('create_dispute',{p_contract_id:contractId,p_milestone_id:milestoneId,p_reason:reason}));
  return data as string;
}
export async function deleteAccount(): Promise<void> { await callFunction('delete-account',{}); }

export interface AdminMetrics { users:number; published_tutors:number; open_missions:number; active_contracts:number; successful_payments:number; gross_paid:number; open_disputes:number; pending_verifications:number; events_24h:number; }
export async function getAdminMetrics(): Promise<AdminMetrics> { const { data } = check(await supabase.rpc('admin_metrics')); return data as AdminMetrics; }
export async function listPendingVerifications(): Promise<any[]> {
  const { data } = check(await supabase.from('tutor_profiles').select('user_id,headline,bio,categories,verification_status,verification_notes,verified_at,profiles!user_id(full_name,avatar_url)').eq('verification_status','pending').order('updated_at',{ascending:false}).limit(50));
  return (data ?? []) as any[];
}
export async function setTutorVerification(userId:string,status:'approved'|'rejected',notes:string):Promise<void>{
  check(await supabase.from('tutor_profiles').update({verification_status:status,verified:status==='approved',verification_notes:notes.trim(),verified_at:status==='approved'?new Date().toISOString():null}).eq('user_id',userId));
}
export async function listOpenDisputes():Promise<any[]> { const {data}=check(await supabase.from('disputes').select('*, opened:profiles!opened_by(full_name), contracts(title,student_id,tutor_id), milestones(title,amount)').in('status',['open','under_review']).order('created_at',{ascending:true}).limit(50)); return (data??[]) as any[]; }
export async function resolveDispute(id:string,status:'resolved_refund'|'resolved_no_refund'|'closed',adminNote:string):Promise<void>{ check(await supabase.from('disputes').update({status,admin_note:adminNote.trim(),resolved_at:new Date().toISOString()}).eq('id',id)); }
export async function listSuccessfulPayments():Promise<any[]> { const {data}=check(await supabase.from('payments').select('id,reference,amount,currency,status,refund_status,refunded_amount,created_at,payer_id,milestone_id').eq('status','success').order('created_at',{ascending:false}).limit(50)); return (data??[]) as any[]; }
export async function issueRefund(paymentId:string,amount?:number):Promise<void>{ await callFunction('paystack-refund',{payment_id:paymentId,amount}); }

export async function isCurrentUserAdmin(userId:string):Promise<boolean>{ const {data}=check(await supabase.from('app_admins').select('user_id').eq('user_id',userId).maybeSingle()); return Boolean(data); }
