import { callFunction } from './functions';

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  interface Window {
    PaystackPop?: any;
  }
}

const SCRIPT_SRC = 'https://js.paystack.co/v2/inline.js';
let loading: Promise<any> | null = null;

function loadPaystack(): Promise<any> {
  if (window.PaystackPop) return Promise.resolve(window.PaystackPop);
  if (loading) return loading;
  loading = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = SCRIPT_SRC;
    script.async = true;
    script.onload = () => (window.PaystackPop ? resolve(window.PaystackPop) : reject(new Error('Paystack failed to load.')));
    script.onerror = () => {
      loading = null;
      script.remove();
      reject(new Error('Could not load Paystack. Check your connection and try again.'));
    };
    document.head.appendChild(script);
  });
  return loading;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Ask the server to confirm the payment with Paystack (retries briefly if still processing). */
async function confirmPayment(reference: string): Promise<boolean> {
  for (let attempt = 0; attempt < 4; attempt++) {
    const res = await callFunction<{ status: string }>('paystack-verify', { reference });
    if (res.status === 'success') return true;
    if (res.status === 'failed' || res.status === 'abandoned') return false;
    await sleep(1500);
  }
  return false;
}

export type PayResult = 'paid' | 'cancelled' | 'pending';

/**
 * Fund one milestone. The server decides the amount and the tutor split; the browser only
 * opens the checkout it was given and then asks the server to confirm the result.
 */
export async function payMilestone(milestoneId: string): Promise<PayResult> {
  const init = await callFunction<{ access_code: string; reference: string }>('paystack-init', { milestone_id: milestoneId });
  const PaystackPop = await loadPaystack();

  return new Promise<PayResult>((resolve, reject) => {
    const popup = new PaystackPop();
    popup.resumeTransaction(init.access_code, {
      onSuccess: () => {
        confirmPayment(init.reference)
          .then((ok) => resolve(ok ? 'paid' : 'pending'))
          .catch(reject);
      },
      onCancel: () => resolve('cancelled'),
      onError: (e: { message?: string }) => reject(new Error(e?.message || 'The payment could not be completed.')),
    });
  });
}
