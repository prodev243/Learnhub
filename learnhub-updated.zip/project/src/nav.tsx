import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export type Page =
  | { name: 'home' }
  | { name: 'missions' }
  | { name: 'mission'; id: string }
  | { name: 'tutors'; category?: string }
  | { name: 'tutor'; id: string }
  | { name: 'match' }
  | { name: 'dashboard' }
  | { name: 'post' }
  | { name: 'contests' }
  | { name: 'contest'; id: string }
  | { name: 'saved' }
  | { name: 'messages'; id?: string }
  | { name: 'account' }
  | { name: 'admin' }
  | { name: 'login'; next?: string }
  | { name: 'signup'; role?: 'student' | 'tutor'; next?: string }
  | { name: 'forgot' }
  | { name: 'reset' }
  | { name: 'terms' }
  | { name: 'privacy' }
  | { name: 'notfound' };

export function pageToPath(p: Page): string {
  switch (p.name) {
    case 'home': return '/';
    case 'missions': return '/missions';
    case 'mission': return `/missions/${p.id}`;
    case 'tutors': return p.category ? `/tutors?category=${encodeURIComponent(p.category)}` : '/tutors';
    case 'tutor': return `/tutors/${p.id}`;
    case 'match': return '/match';
    case 'dashboard': return '/dashboard';
    case 'post': return '/post';
    case 'contests': return '/contests';
    case 'contest': return `/contests/${p.id}`;
    case 'saved': return '/saved';
    case 'messages': return p.id ? `/messages/${p.id}` : '/messages';
    case 'account': return '/account';
    case 'admin': return '/admin';
    case 'login': return p.next ? `/login?next=${encodeURIComponent(p.next)}` : '/login';
    case 'signup': {
      const q = new URLSearchParams();
      if (p.role) q.set('role', p.role);
      if (p.next) q.set('next', p.next);
      const s = q.toString();
      return s ? `/signup?${s}` : '/signup';
    }
    case 'forgot': return '/forgot-password';
    case 'reset': return '/reset-password';
    case 'terms': return '/terms';
    case 'privacy': return '/privacy';
    default: return '/404';
  }
}

export function pathToPage(pathname: string, search = ''): Page {
  const parts = pathname.split('/').filter(Boolean);
  const params = new URLSearchParams(search);
  const [a, b] = parts;
  if (parts.length > 2) return { name: 'notfound' };
  switch (a) {
    case undefined: return { name: 'home' };
    case 'missions': return b ? { name: 'mission', id: b } : { name: 'missions' };
    case 'tutors': return b ? { name: 'tutor', id: b } : { name: 'tutors', category: params.get('category') ?? undefined };
    case 'match': return { name: 'match' };
    case 'dashboard': return { name: 'dashboard' };
    case 'post': return { name: 'post' };
    case 'contests': return b ? { name: 'contest', id: b } : { name: 'contests' };
    case 'saved': return { name: 'saved' };
    case 'messages': return { name: 'messages', id: b };
    case 'account': return { name: 'account' };
    case 'admin': return { name: 'admin' };
    case 'login': return { name: 'login', next: safeNext(params.get('next')) };
    case 'signup': {
      const role = params.get('role');
      return { name: 'signup', role: role === 'tutor' || role === 'student' ? role : undefined, next: safeNext(params.get('next')) };
    }
    case 'forgot-password': return { name: 'forgot' };
    case 'reset-password': return { name: 'reset' };
    case 'terms': return { name: 'terms' };
    case 'privacy': return { name: 'privacy' };
    default: return { name: 'notfound' };
  }
}

/** Only allow same-site relative redirects after login. */
export function safeNext(next: string | null | undefined): string | undefined {
  if (!next) return undefined;
  return next.startsWith('/') && !next.startsWith('//') ? next : undefined;
}

interface NavValue {
  page: Page;
  navigate: (p: Page) => void;
  navigateToPath: (path: string) => void;
}

const NavContext = createContext<NavValue | null>(null);

function current(): Page {
  return pathToPage(window.location.pathname, window.location.search);
}

export function NavProvider({ children }: { children: ReactNode }) {
  const [page, setPage] = useState<Page>(current);

  useEffect(() => {
    const onPop = () => setPage(current());
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const navigateToPath = useCallback((path: string) => {
    const url = new URL(path, window.location.origin);
    window.history.pushState({}, '', url.pathname + url.search);
    setPage(pathToPage(url.pathname, url.search));
    window.scrollTo({ top: 0 });
  }, []);

  const navigate = useCallback((p: Page) => navigateToPath(pageToPath(p)), [navigateToPath]);

  const value = useMemo(() => ({ page, navigate, navigateToPath }), [page, navigate, navigateToPath]);
  return <NavContext.Provider value={value}>{children}</NavContext.Provider>;
}

export function useNav(): NavValue {
  const ctx = useContext(NavContext);
  if (!ctx) throw new Error('useNav must be used inside <NavProvider>');
  return ctx;
}

/** A real <a href> that navigates without a full page reload (supports open-in-new-tab). */
export function Link({
  to, className, children, title, onClick,
}: {
  to: Page;
  className?: string;
  children: ReactNode;
  title?: string;
  onClick?: () => void;
}) {
  const { navigate } = useNav();
  return (
    <a
      href={pageToPath(to)}
      title={title}
      className={className}
      onClick={(e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
        e.preventDefault();
        onClick?.();
        navigate(to);
      }}
    >
      {children}
    </a>
  );
}
