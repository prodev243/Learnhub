import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';
import { useNav } from '@/nav';
import { listSavedIds, setSaved, type SavedKind } from '@/lib/api';
import { errorMessage } from '@/lib/format';

interface SavedValue {
  has: (kind: SavedKind, id: string) => boolean;
  toggle: (kind: SavedKind, id: string) => Promise<void>;
  version: number;
}

const SavedContext = createContext<SavedValue | null>(null);
const key = (kind: SavedKind, id: string) => `${kind}:${id}`;

export function SavedProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const toast = useToast();
  const { navigate } = useNav();
  const [set, setSet] = useState<Set<string>>(new Set());
  const [version, setVersion] = useState(0);
  const userId = user?.id ?? null;

  useEffect(() => {
    if (!userId) { setSet(new Set()); return; }
    let cancelled = false;
    Promise.all([listSavedIds(userId, 'mission'), listSavedIds(userId, 'tutor')])
      .then(([m, t]) => {
        if (cancelled) return;
        setSet(new Set([...m.map((id) => key('mission', id)), ...t.map((id) => key('tutor', id))]));
      })
      .catch(() => { /* saved state is a convenience; ignore load errors */ });
    return () => { cancelled = true; };
  }, [userId]);

  const has = useCallback((kind: SavedKind, id: string) => set.has(key(kind, id)), [set]);

  const toggle = useCallback(async (kind: SavedKind, id: string) => {
    if (!userId) {
      navigate({ name: 'login', next: window.location.pathname });
      return;
    }
    const k = key(kind, id);
    const willSave = !set.has(k);
    setSet((prev) => { const n = new Set(prev); if (willSave) n.add(k); else n.delete(k); return n; });
    try {
      await setSaved(userId, kind, id, willSave);
      setVersion((v) => v + 1);
      toast.success(willSave ? 'Saved' : 'Removed from saved');
    } catch (e) {
      setSet((prev) => { const n = new Set(prev); if (willSave) n.delete(k); else n.add(k); return n; });
      toast.error(errorMessage(e));
    }
  }, [userId, set, navigate, toast]);

  const value = useMemo(() => ({ has, toggle, version }), [has, toggle, version]);
  return <SavedContext.Provider value={value}>{children}</SavedContext.Provider>;
}

export function useSaved(): SavedValue {
  const ctx = useContext(SavedContext);
  if (!ctx) throw new Error('useSaved must be used inside <SavedProvider>');
  return ctx;
}
