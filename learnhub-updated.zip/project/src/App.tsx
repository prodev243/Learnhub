import { useEffect } from 'react';
import { NavProvider, useNav } from './nav';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider, useToast } from './context/ToastContext';
import { SavedProvider } from './context/SavedContext';
import { Footer, Navbar, TestModeBanner } from './Shell';
import { ErrorBoundary } from './components/ErrorBoundary';
import { RequireAuth } from './components/RequireAuth';
import { usePageTitle } from './hooks';
import { isSupabaseConfigured } from './lib/config';
import { SetupScreen } from './pages/SetupScreen';
import { HomePage } from './pages/HomePage';
import { MissionsPage } from './pages/MissionsPage';
import { MissionDetailPage } from './pages/MissionDetailPage';
import { TutorsPage } from './pages/TutorsPage';
import { TutorDetailPage } from './pages/TutorDetailPage';
import { MatchPage } from './pages/MatchPage';
import { PostPage } from './pages/PostPage';
import { DashboardPage } from './pages/DashboardPage';
import { MessagesPage } from './pages/MessagesPage';
import { ContestsPage } from './pages/ContestsPage';
import { ContestDetailPage } from './pages/ContestDetailPage';
import { SavedPage } from './pages/SavedPage';
import { AccountPage } from './pages/AccountPage';
import { AuthPage } from './pages/AuthPage';
import { ForgotPasswordPage, ResetPasswordPage } from './pages/PasswordPages';
import { LegalPage } from './pages/LegalPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { AdminPage } from './pages/AdminPage';
import type { Page } from './nav';

const TITLES: Partial<Record<Page['name'], string>> = {
  missions: 'Learning missions', tutors: 'Find tutors', match: 'Tutor Match', dashboard: 'Dashboard',
  post: 'Post a learning goal', admin: 'Admin dashboard', contests: 'Contests', saved: 'Saved', messages: 'Messages', account: 'Account settings',
  login: 'Log in', signup: 'Create your account', forgot: 'Forgot password', reset: 'Choose a new password',
  terms: 'Terms of Service', privacy: 'Privacy Policy', notfound: 'Page not found',
};

function Router() {
  const { page } = useNav();
  const { recovering } = useAuth();
  usePageTitle(recovering ? 'Choose a new password' : TITLES[page.name] ?? '');

  if (recovering) return <ResetPasswordPage />;

  switch (page.name) {
    case 'home': return <HomePage />;
    case 'missions': return <MissionsPage />;
    case 'mission': return <MissionDetailPage key={page.id} id={page.id} />;
    case 'tutors': return <TutorsPage />;
    case 'tutor': return <TutorDetailPage key={page.id} id={page.id} />;
    case 'match': return <MatchPage />;
    case 'post': return <RequireAuth role="student" roleMessage="Only student accounts can post learning goals."><PostPage /></RequireAuth>;
    case 'dashboard': return <RequireAuth><DashboardPage /></RequireAuth>;
    case 'messages': return <RequireAuth><MessagesPage conversationId={page.id} /></RequireAuth>;
    case 'contests': return <ContestsPage />;
    case 'contest': return <ContestDetailPage key={page.id} id={page.id} />;
    case 'saved': return <RequireAuth><SavedPage /></RequireAuth>;
    case 'account': return <RequireAuth><AccountPage /></RequireAuth>;
    case 'admin': return <RequireAuth><AdminPage /></RequireAuth>;
    case 'login': return <AuthPage mode="login" next={page.next} />;
    case 'signup': return <AuthPage mode="signup" next={page.next} initialRole={page.role} />;
    case 'forgot': return <ForgotPasswordPage />;
    case 'reset': return <ResetPasswordPage />;
    case 'terms': return <LegalPage kind="terms" />;
    case 'privacy': return <LegalPage kind="privacy" />;
    default: return <NotFoundPage />;
  }
}

/** Surface errors from expired / invalid email links (they arrive in the URL hash). */
function AuthLinkWatcher() {
  const toast = useToast();
  useEffect(() => {
    const hash = window.location.hash;
    if (!hash.includes('error_description')) return;
    const params = new URLSearchParams(hash.replace(/^#/, ''));
    const desc = params.get('error_description');
    if (desc) toast.error(desc.replace(/\+/g, ' ').concat(desc.endsWith('.') ? '' : '.') + ' Please request a new link.');
    window.history.replaceState({}, '', window.location.pathname + window.location.search);
  }, [toast]);
  return null;
}

function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <TestModeBanner />
      <Navbar />
      <main className="flex-1"><Router /></main>
      <Footer />
    </div>
  );
}

export default function App() {
  if (!isSupabaseConfigured) return <SetupScreen />;
  return (
    <ErrorBoundary>
      <ToastProvider>
        <NavProvider>
          <AuthProvider>
            <SavedProvider>
              <AuthLinkWatcher />
              <Layout />
            </SavedProvider>
          </AuthProvider>
        </NavProvider>
      </ToastProvider>
    </ErrorBoundary>
  );
}
