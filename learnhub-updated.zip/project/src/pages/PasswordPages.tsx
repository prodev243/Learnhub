import { useState, type FormEvent } from 'react';
import { KeyRound, Loader2, MailCheck } from 'lucide-react';
import { Link, useNav } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { errorMessage } from '@/lib/format';

export function ForgotPasswordPage() {
  const { requestPasswordReset } = useAuth();
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await requestPasswordReset(email);
      setSent(true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  if (sent) {
    return (
      <div className="section flex min-h-[60vh] flex-col items-center justify-center py-16 text-center">
        <span className="grid h-16 w-16 place-items-center rounded-2xl bg-brand-500 text-white shadow-glow"><MailCheck className="h-8 w-8" /></span>
        <h1 className="mt-6 font-display text-3xl font-extrabold text-ink-900">Check your email</h1>
        <p className="mx-auto mt-3 max-w-md text-ink-500">If an account exists for {email}, we've sent a link to reset your password.</p>
        <Link to={{ name: 'login' }} className="btn-primary mt-8">Back to log in</Link>
      </div>
    );
  }

  return (
    <div className="section py-12">
      <div className="mx-auto max-w-md">
        <h1 className="text-center font-display text-3xl font-extrabold text-ink-900">Reset your password</h1>
        <p className="mt-2 text-center text-sm text-ink-500">Enter your email and we'll send you a reset link.</p>
        <form onSubmit={submit} className="card mt-8 space-y-5 p-6 sm:p-8">
          <div>
            <label htmlFor="email" className="label">Email</label>
            <input id="email" type="email" required className="input mt-2" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{error}</p>}
          <button type="submit" disabled={busy || !email} className="btn-primary w-full disabled:opacity-60">
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} Send reset link
          </button>
        </form>
        <p className="mt-6 text-center text-sm"><Link to={{ name: 'login' }} className="font-medium text-brand-600 hover:underline">Back to log in</Link></p>
      </div>
    </div>
  );
}

/** Shown after the person clicks the link in the reset email. */
export function ResetPasswordPage() {
  const { user, updatePassword, finishRecovery } = useAuth();
  const { navigate } = useNav();
  const toast = useToast();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="section flex min-h-[50vh] flex-col items-center justify-center py-16 text-center">
        <h1 className="font-display text-2xl font-extrabold text-ink-900">This reset link has expired</h1>
        <p className="mt-2 text-sm text-ink-500">Request a new one and try again.</p>
        <Link to={{ name: 'forgot' }} className="btn-primary mt-6">Send a new link</Link>
      </div>
    );
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password.length < 8) return setError('Password must be at least 8 characters.');
    if (password !== confirm) return setError('The two passwords do not match.');
    setBusy(true);
    try {
      await updatePassword(password);
      finishRecovery();
      toast.success('Password updated.');
      navigate({ name: 'dashboard' });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="section py-12">
      <div className="mx-auto max-w-md">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-brand-50 text-brand-600"><KeyRound className="h-6 w-6" /></span>
        <h1 className="mt-4 text-center font-display text-3xl font-extrabold text-ink-900">Choose a new password</h1>
        <form onSubmit={submit} className="card mt-8 space-y-5 p-6 sm:p-8">
          <div>
            <label htmlFor="pw" className="label">New password</label>
            <input id="pw" type="password" className="input mt-2" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 8 characters" />
          </div>
          <div>
            <label htmlFor="pw2" className="label">Confirm new password</label>
            <input id="pw2" type="password" className="input mt-2" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </div>
          {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{error}</p>}
          <button type="submit" disabled={busy} className="btn-primary w-full disabled:opacity-60">
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} Update password
          </button>
        </form>
      </div>
    </div>
  );
}
