import { useState } from 'react';
import {
  ArrowLeft, Award, CheckCircle2, Clock, Loader2, MapPin, MessageSquare, PenSquare, ShieldCheck, Star, UserPlus,
} from 'lucide-react';
import { Link, useNav } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks';
import { useStartChat } from '@/chat';
import { getTutor, inviteTutor, listMyMissions, listReviews } from '@/lib/api';
import { errorMessage, formatDate, money } from '@/lib/format';
import { Avatar, EmptyState, ErrorNote, Modal, PageLoader, ProgressBar, SaveButton, Spinner, Stars, VerifiedBadge } from '@/components/ui';
import type { Tutor } from '@/types';

function InviteModal({ tutor, open, onClose }: { tutor: Tutor; open: boolean; onClose: () => void }) {
  const { user } = useAuth();
  const toast = useToast();
  const { navigate } = useNav();
  const goals = useAsync(async () => (user ? (await listMyMissions(user.id)).filter((m) => m.status === 'open') : []), [user?.id, open]);
  const [sending, setSending] = useState<string | null>(null);

  const invite = async (missionId: string) => {
    setSending(missionId);
    try {
      await inviteTutor(missionId, tutor.id);
      toast.success(`Invitation sent to ${tutor.name}.`);
      onClose();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setSending(null);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={`Invite ${tutor.name}`}>
      {goals.loading ? <Spinner /> : goals.data && goals.data.length > 0 ? (
        <div className="space-y-2">
          <p className="text-sm text-ink-500">Choose one of your open goals. The tutor will see it in their dashboard.</p>
          {goals.data.map((g) => (
            <button key={g.id} onClick={() => invite(g.id)} disabled={sending !== null} className="flex w-full items-center justify-between gap-3 rounded-xl border border-ink-100 p-3 text-left hover:border-brand-300 hover:bg-brand-50 disabled:opacity-60">
              <span className="min-w-0"><span className="block truncate text-sm font-semibold text-ink-900">{g.title}</span><span className="text-xs text-ink-400">{g.category} · {money(g.budget)}</span></span>
              {sending === g.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4 text-brand-600" />}
            </button>
          ))}
        </div>
      ) : (
        <div className="text-center">
          <p className="text-sm text-ink-500">You have no open goals yet. Post one first, then invite tutors to it.</p>
          <button onClick={() => { onClose(); navigate({ name: 'post' }); }} className="btn-primary mt-4">Post a goal</button>
        </div>
      )}
    </Modal>
  );
}

export function TutorDetailPage({ id }: { id: string }) {
  const { user, profile } = useAuth();
  const { navigate } = useNav();
  const chat = useStartChat();
  const [inviting, setInviting] = useState(false);

  const tutor = useAsync(() => getTutor(id), [id]);
  const reviews = useAsync(() => listReviews(id), [id]);

  if (tutor.loading) return <PageLoader />;
  if (tutor.error) return <div className="section py-16"><ErrorNote message={tutor.error} onRetry={tutor.reload} /></div>;
  const t = tutor.data;
  if (!t) {
    return (
      <div className="section py-20 text-center">
        <p className="text-lg font-semibold text-ink-700">Tutor not found</p>
        <Link to={{ name: 'tutors' }} className="btn-primary mt-4">Back to tutors</Link>
      </div>
    );
  }

  const isMe = user?.id === t.id;
  const isStudent = profile?.role === 'student';

  const onInvite = () => {
    if (!user) return navigate({ name: 'login', next: `/tutors/${t.id}` });
    setInviting(true);
  };

  return (
    <div className="section py-8">
      <Link to={{ name: 'tutors' }} className="btn-ghost -ml-3 mb-6"><ArrowLeft className="h-4 w-4" /> Back to tutors</Link>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <div className="card animate-fade-up p-6">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
              <Avatar name={t.name} size={88} ring src={t.avatarUrl} />
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="font-display text-2xl font-extrabold tracking-tight text-ink-900">{t.name}</h1>
                  {t.verified && <VerifiedBadge label="Verified by LearnHub" />}
                </div>
                <p className="text-sm text-ink-500">{t.headline}</p>
                <div className="mt-2 flex flex-wrap items-center gap-4 text-xs text-ink-400">
                  {t.location && <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {t.location}</span>}
                  {t.responseTime && <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> Responds {t.responseTime}</span>}
                  {t.rating != null && <span className="flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-sky-400 text-sky-400" /> {t.rating} ({t.reviewCount})</span>}
                </div>
              </div>
            </div>

            <p className="mt-5 whitespace-pre-line text-sm leading-relaxed text-ink-600">{t.bio}</p>

            {(t.categories.length > 0 || t.skills.length > 0) && (
              <div className="mt-5 flex flex-wrap gap-1.5">
                {t.categories.map((c) => <span key={c} className="chip bg-brand-50 text-brand-700">{c}</span>)}
                {t.skills.map((s) => <span key={s} className="chip bg-ink-100 text-ink-700">{s}</span>)}
              </div>
            )}

            <div className="mt-6 flex flex-wrap items-center gap-3">
              {isMe ? (
                <Link to={{ name: 'account' }} className="btn-secondary"><PenSquare className="h-4 w-4" /> Edit my profile</Link>
              ) : (
                <>
                  {(!user || isStudent) && <button onClick={onInvite} className="btn-primary"><PenSquare className="h-4 w-4" /> Invite to a goal</button>}
                  <button onClick={() => chat.start(t.id)} disabled={chat.busy} className="btn-secondary disabled:opacity-60">
                    {chat.busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquare className="h-4 w-4" />} Message
                  </button>
                  <SaveButton kind="tutor" id={t.id} className="ring-1 ring-ink-200" />
                </>
              )}
            </div>
          </div>

          {t.scores.length > 0 && (
            <div className="card animate-fade-up animate-delay-100 p-6">
              <h2 className="font-display text-xl font-bold text-ink-900">Teaching reputation</h2>
              <p className="mt-1 text-sm text-ink-500">Average scores from student reviews.</p>
              <div className="mt-5 grid gap-5 sm:grid-cols-2">
                {t.scores.map((s) => (
                  <div key={s.label}>
                    <div className="flex items-center justify-between text-sm"><span className="font-medium text-ink-700">{s.label}</span><span className="font-bold text-ink-900">{s.value}%</span></div>
                    <div className="mt-1.5"><ProgressBar percent={s.value} /></div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="grid animate-fade-up animate-delay-200 grid-cols-3 gap-4">
            {[
              { icon: Award, label: 'Completed', value: `${t.completedProjects}` },
              { icon: Star, label: 'Reviews', value: `${t.reviewCount}` },
              { icon: Clock, label: 'Response', value: t.responseTime || '—' },
            ].map((s) => (
              <div key={s.label} className="card p-4 text-center">
                <s.icon className="mx-auto h-5 w-5 text-brand-600" />
                <p className="mt-2 font-display text-base font-bold text-ink-900 sm:text-lg">{s.value}</p>
                <p className="text-[10px] uppercase tracking-wide text-ink-400">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="animate-fade-up animate-delay-300">
            <h2 className="font-display text-xl font-bold text-ink-900">Student reviews <span className="text-ink-400">({t.reviewCount})</span></h2>
            <div className="mt-4 space-y-4">
              {reviews.loading ? <Spinner /> : reviews.error ? <ErrorNote message={reviews.error} onRetry={reviews.reload} /> : reviews.data && reviews.data.length > 0 ? (
                reviews.data.map((r) => (
                  <div key={r.id} className="card p-5">
                    <div className="flex items-start gap-3">
                      <Avatar name={r.student} size={40} />
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="font-semibold text-ink-900">{r.student}</p>
                          <Stars rating={r.rating} />
                          <span className="text-xs text-ink-400">{formatDate(r.createdAt)}</span>
                        </div>
                        {r.mission && <p className="text-xs text-brand-600">{r.mission}</p>}
                      </div>
                    </div>
                    <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-ink-600">{r.text}</p>
                    <div className="mt-3 flex flex-wrap gap-4">
                      {r.subScores.map((s) => (
                        <div key={s.label} className="flex items-center gap-1.5 text-xs text-ink-500"><CheckCircle2 className="h-3.5 w-3.5 text-brand-500" /> {s.label}: <span className="font-semibold text-ink-900">{s.value}%</span></div>
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                <EmptyState icon={<Star />} title="No reviews yet" text="Reviews appear here after students complete a contract with this tutor." />
              )}
            </div>
          </div>
        </div>

        <div>
          <div className="card p-6 lg:sticky lg:top-32">
            <div className="flex items-baseline justify-between">
              <p className="text-sm text-ink-400">Starting from</p>
              <p className="font-display text-3xl font-extrabold text-ink-900">{money(t.priceFrom)}</p>
            </div>
            <p className="text-xs text-ink-400">per learning package</p>

            {t.guarantee && (
              <div className="mt-4 rounded-xl bg-brand-50 p-4 text-sm text-brand-800">
                <ShieldCheck className="h-5 w-5 text-brand-600" />
                <p className="mt-1.5 font-semibold">Learning guarantee</p>
                <p className="mt-0.5 text-xs leading-relaxed">{t.guarantee}</p>
              </div>
            )}

            <div className="mt-5 space-y-2.5 text-sm">
              {['Fund one milestone at a time', 'Personalised learning plan', 'Message the tutor before you commit'].map((x) => (
                <div key={x} className="flex items-center gap-2 text-ink-600"><CheckCircle2 className="h-4 w-4 text-brand-500" /> {x}</div>
              ))}
            </div>

            {!isMe && (!user || isStudent) && (
              <button onClick={onInvite} className="btn-primary mt-5 w-full"><PenSquare className="h-4 w-4" /> Invite to a goal</button>
            )}
          </div>
        </div>
      </div>

      {inviting && <InviteModal tutor={t} open={inviting} onClose={() => setInviting(false)} />}
    </div>
  );
}
