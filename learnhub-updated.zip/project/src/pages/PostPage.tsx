import { useState, type FormEvent } from 'react';
import { ArrowRight, BookOpen, CheckCircle2, Clock, Loader2, Rocket, Target, Wallet } from 'lucide-react';
import { Link, useNav } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { createMission } from '@/lib/api';
import { DEFAULT_BUDGET, MIN_BUDGET } from '@/lib/config';
import { errorMessage, money } from '@/lib/format';
import { CATEGORIES, LEVELS, type Category, type Level } from '@/types';

export function PostPage() {
  const { user } = useAuth();
  const { navigate } = useNav();
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    title: '', category: 'Languages' as Category, level: 'Beginner' as Level, budget: DEFAULT_BUDGET,
    deadline: '', availability: '', style: '', description: '',
  });
  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) => setForm((f) => ({ ...f, [key]: value }));

  const titleOk = form.title.trim().length >= 6;
  const descOk = form.description.trim().length >= 20;
  const budgetOk = Number.isFinite(form.budget) && form.budget >= MIN_BUDGET;
  const canSubmit = titleOk && descOk && budgetOk && form.deadline.trim().length > 0 && !busy;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !canSubmit) return;
    setBusy(true);
    setError(null);
    try {
      const id = await createMission({
        studentId: user.id, title: form.title, category: form.category, level: form.level, budget: form.budget,
        deadline: form.deadline, availability: form.availability, learningStyle: form.style, description: form.description,
      });
      setCreatedId(id);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  if (createdId) {
    return (
      <div className="section flex min-h-[60vh] flex-col items-center justify-center py-20 text-center">
        <div className="grid h-20 w-20 animate-pop-in place-items-center rounded-3xl bg-brand-500 text-white shadow-glow"><CheckCircle2 className="h-10 w-10" /></div>
        <h1 className="mt-6 font-display text-3xl font-extrabold tracking-tight text-ink-900">Your goal is live!</h1>
        <p className="mx-auto mt-3 max-w-md text-ink-500 text-balance">Tutors can now find it and send you proposals. You'll see them on your goal page and in your dashboard.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to={{ name: 'mission', id: createdId }} className="btn-primary"><Rocket className="h-4 w-4" /> View my goal</Link>
          <Link to={{ name: 'tutors' }} className="btn-secondary">Find tutors to invite <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </div>
    );
  }

  return (
    <div className="section py-10">
      <div className="mx-auto max-w-2xl">
        <div className="text-center">
          <span className="chip mx-auto bg-brand-50 text-brand-700 ring-1 ring-brand-200"><Target className="h-3.5 w-3.5" /> Post a learning goal</span>
          <h1 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-ink-900 text-balance">What do you want to achieve?</h1>
          <p className="mt-3 text-ink-500 text-balance">Tell tutors your goal, not just the subject. The clearer your goal, the better the proposals.</p>
        </div>

        <form className="card mt-8 space-y-6 p-6 sm:p-8" onSubmit={submit} noValidate>
          <div>
            <label htmlFor="title" className="label">Your learning goal</label>
            <p className="hint">Describe what success looks like.</p>
            <input id="title" className="input mt-2" maxLength={140} placeholder="e.g. Pass IELTS with band 7.0 in 3 months" value={form.title} onChange={(e) => set('title', e.target.value)} />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="category" className="label">Category</label>
              <select id="category" className="input mt-2" value={form.category} onChange={(e) => set('category', e.target.value as Category)}>
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <p className="label">Current level</p>
              <div className="mt-2 flex gap-2">
                {LEVELS.map((l) => (
                  <button key={l} type="button" onClick={() => set('level', l)} aria-pressed={form.level === l} className={`chip flex-1 justify-center py-2 ${form.level === l ? 'bg-brand-500 text-white' : 'bg-ink-100 text-ink-700 hover:bg-ink-200'}`}>{l}</button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <label htmlFor="budget" className="label">Budget</label>
            <p className="hint">Total you're willing to spend. Minimum {money(MIN_BUDGET)}.</p>
            <input id="budget" type="number" inputMode="numeric" min={MIN_BUDGET} step={MIN_BUDGET >= 1000 ? 500 : 1} className="input mt-2" value={Number.isFinite(form.budget) ? form.budget : ''} onChange={(e) => set('budget', e.target.value === '' ? NaN : Number(e.target.value))} />
            {!budgetOk && <p className="field-error">Enter at least {money(MIN_BUDGET)}.</p>}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="deadline" className="label flex items-center gap-1.5"><Clock className="h-4 w-4 text-ink-400" /> Timeline</label>
              <input id="deadline" className="input mt-2" maxLength={60} placeholder="e.g. 3 months" value={form.deadline} onChange={(e) => set('deadline', e.target.value)} />
            </div>
            <div>
              <label htmlFor="availability" className="label flex items-center gap-1.5"><BookOpen className="h-4 w-4 text-ink-400" /> Availability</label>
              <input id="availability" className="input mt-2" maxLength={120} placeholder="e.g. Weekday evenings" value={form.availability} onChange={(e) => set('availability', e.target.value)} />
            </div>
          </div>

          <div>
            <label htmlFor="style" className="label">Preferred learning style</label>
            <p className="hint">Optional — helps tutors tailor their approach.</p>
            <input id="style" className="input mt-2" maxLength={160} placeholder="e.g. Structured, accountability-driven, project-based" value={form.style} onChange={(e) => set('style', e.target.value)} />
          </div>

          <div>
            <label htmlFor="description" className="label">Describe your goal in detail</label>
            <p className="hint">Where you are now, where you want to be, and anything tutors should know (at least 20 characters).</p>
            <textarea id="description" rows={5} maxLength={5000} className="input mt-2 resize-none" placeholder="I am currently at band 5.5 and need to reach 7.0 for university admission…" value={form.description} onChange={(e) => set('description', e.target.value)} />
          </div>

          <div className="flex items-start gap-3 rounded-xl bg-brand-50 p-4 text-sm text-brand-800">
            <Target className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
            <p className="leading-relaxed"><span className="font-semibold">Tip:</span> a clear "from → to" and a timeline help tutors write better proposals.</p>
          </div>

          {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{error}</p>}

          <div className="flex flex-col-reverse items-stretch justify-between gap-4 border-t border-ink-100 pt-4 sm:flex-row sm:items-center">
            <p className="flex items-center gap-1.5 text-xs text-ink-400"><Wallet className="h-3.5 w-3.5" /> You only pay when you accept a proposal, one milestone at a time.</p>
            <div className="flex gap-3">
              <button type="button" onClick={() => navigate({ name: 'dashboard' })} className="btn-ghost">Cancel</button>
              <button type="submit" disabled={!canSubmit} className="btn-primary disabled:cursor-not-allowed disabled:opacity-40">
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Rocket className="h-4 w-4" />} Post goal
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
