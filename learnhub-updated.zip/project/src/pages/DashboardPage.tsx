import { AlertTriangle, ArrowRight, Briefcase, CheckCircle2, FileText, Inbox, Plus, Sparkles, TrendingUp, Wallet } from 'lucide-react';
import { Link } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useAsync } from '@/hooks';
import { fetchPayoutAccount, fetchTutorProfile, listMyContracts, listMyInvites, listMyMissions, listMyProposals } from '@/lib/api';
import { money, timeAgo } from '@/lib/format';
import { ContractCard } from '@/components/ContractCard';
import { statusLabel } from '@/components/cards';
import { EmptyState, ErrorNote, PageLoader, Spinner } from '@/components/ui';
import type { Contract } from '@/types';

function Stat({ icon: Icon, label, value }: { icon: typeof Wallet; label: string; value: string }) {
  return (
    <div className="card p-5">
      <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-brand-600"><Icon className="h-5 w-5" /></span>
      <p className="mt-3 font-display text-2xl font-extrabold text-ink-900">{value}</p>
      <p className="text-xs text-ink-400">{label}</p>
    </div>
  );
}

function ContractsSection({ contracts, role, userId, reload }: { contracts: Contract[]; role: 'student' | 'tutor'; userId: string; reload: () => void }) {
  const active = contracts.filter((c) => c.status === 'active');
  const done = contracts.filter((c) => c.status !== 'active');
  return (
    <div>
      <h2 className="font-display text-xl font-bold text-ink-900">Active learning contracts</h2>
      <div className="mt-4 space-y-4">
        {active.length === 0 ? (
          <EmptyState icon={<Briefcase />} title="No active contracts" text={role === 'student' ? 'Accept a tutor\'s proposal on one of your goals to start a contract.' : 'When a student accepts your proposal, the contract appears here.'} />
        ) : active.map((c) => <ContractCard key={c.id} contract={c} role={role} userId={userId} onChanged={reload} />)}
      </div>
      {done.length > 0 && (
        <>
          <h2 className="mt-8 font-display text-xl font-bold text-ink-900">Completed contracts</h2>
          <div className="mt-4 space-y-4">{done.map((c) => <ContractCard key={c.id} contract={c} role={role} userId={userId} onChanged={reload} />)}</div>
        </>
      )}
    </div>
  );
}

function StudentDashboard({ userId }: { userId: string }) {
  const missions = useAsync(() => listMyMissions(userId), [userId]);
  const contracts = useAsync(() => listMyContracts(userId), [userId]);

  if (missions.loading || contracts.loading) return <Spinner />;
  const err = missions.error ?? contracts.error;
  if (err) return <ErrorNote message={err} onRetry={() => { missions.reload(); contracts.reload(); }} />;

  const ms = missions.data ?? [];
  const cs = contracts.data ?? [];
  const paid = cs.flatMap((c) => c.milestones).filter((m) => m.status !== 'pending').reduce((s, m) => s + m.amount, 0);

  return (
    <>
      <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat icon={FileText} label="Goals posted" value={`${ms.length}`} />
        <Stat icon={Briefcase} label="Active contracts" value={`${cs.filter((c) => c.status === 'active').length}`} />
        <Stat icon={CheckCircle2} label="Completed" value={`${cs.filter((c) => c.status === 'completed').length}`} />
        <Stat icon={Wallet} label="Total paid" value={money(paid)} />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2"><ContractsSection contracts={cs} role="student" userId={userId} reload={contracts.reload} /></div>
        <div>
          <h2 className="font-display text-xl font-bold text-ink-900">My goals</h2>
          <div className="mt-4 space-y-3">
            {ms.length === 0 ? (
              <EmptyState icon={<FileText />} title="No goals yet" text="Post your first learning goal to start getting proposals." action={<Link to={{ name: 'post' }} className="btn-primary"><Plus className="h-4 w-4" /> Post a goal</Link>} />
            ) : ms.map((m) => (
              <Link key={m.id} to={{ name: 'mission', id: m.id }} className="card block p-4 transition hover:ring-brand-200">
                <div className="flex items-center justify-between gap-2">
                  <span className="chip bg-ink-100 text-ink-700">{m.category}</span>
                  <span className="text-xs font-medium text-ink-500">{statusLabel[m.status]}</span>
                </div>
                <p className="mt-2 text-sm font-semibold text-ink-900">{m.title}</p>
                <p className="mt-1 text-xs text-ink-400">{money(m.budget)} · {m.proposalsCount} {m.proposalsCount === 1 ? 'proposal' : 'proposals'} · {timeAgo(m.createdAt)}</p>
              </Link>
            ))}
          </div>
          <Link to={{ name: 'match' }} className="btn-ghost mt-4 w-full">Find your next tutor <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </div>
    </>
  );
}

function TutorDashboard({ userId }: { userId: string }) {
  const setup = useAsync(async () => {
    const [profile, payout] = await Promise.all([fetchTutorProfile(userId), fetchPayoutAccount(userId)]);
    return { published: Boolean(profile?.isPublished), payout: Boolean(payout) };
  }, [userId]);
  const proposals = useAsync(() => listMyProposals(userId), [userId]);
  const invites = useAsync(() => listMyInvites(userId), [userId]);
  const contracts = useAsync(() => listMyContracts(userId), [userId]);

  if (proposals.loading || contracts.loading || invites.loading || setup.loading) return <Spinner />;
  const err = proposals.error ?? contracts.error ?? invites.error ?? setup.error;
  if (err) return <ErrorNote message={err} onRetry={() => { proposals.reload(); contracts.reload(); invites.reload(); setup.reload(); }} />;

  const ps = (proposals.data ?? []).filter((p) => p.status !== 'withdrawn');
  const cs = contracts.data ?? [];
  const earned = cs.flatMap((c) => c.milestones).reduce((s, m) => s + (m.status !== 'pending' ? m.tutorAmount ?? 0 : 0), 0);

  return (
    <>
      {setup.data && (!setup.data.published || !setup.data.payout) && (
        <div className="mt-6 flex flex-col gap-3 rounded-2xl bg-amber-50 p-5 text-sm text-amber-900 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
            <p>
              <span className="font-semibold">Finish setting up to start getting hired.</span>{' '}
              {!setup.data.published && 'Complete your public profile. '}
              {!setup.data.payout && 'Add your bank details so payments can reach you.'}
            </p>
          </div>
          <Link to={{ name: 'account' }} className="btn-primary shrink-0">Open account settings</Link>
        </div>
      )}

      <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat icon={FileText} label="Proposals sent" value={`${ps.length}`} />
        <Stat icon={Briefcase} label="Active contracts" value={`${cs.filter((c) => c.status === 'active').length}`} />
        <Stat icon={CheckCircle2} label="Completed" value={`${cs.filter((c) => c.status === 'completed').length}`} />
        <Stat icon={TrendingUp} label="Your earnings (after fees)" value={money(earned)} />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2"><ContractsSection contracts={cs} role="tutor" userId={userId} reload={contracts.reload} /></div>
        <div className="space-y-6">
          <div>
            <h2 className="font-display text-xl font-bold text-ink-900">Invitations</h2>
            <div className="mt-4 space-y-3">
              {(invites.data ?? []).length === 0 ? (
                <EmptyState icon={<Inbox />} title="No invitations" text="Students can invite you to their goals from your profile." />
              ) : (invites.data ?? []).map((m) => (
                <Link key={m.id} to={{ name: 'mission', id: m.id }} className="card block p-4 transition hover:ring-brand-200">
                  <p className="text-sm font-semibold text-ink-900">{m.title}</p>
                  <p className="mt-1 text-xs text-ink-400">{m.student} · {money(m.budget)}</p>
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-ink-900">My proposals</h2>
            <div className="mt-4 space-y-3">
              {ps.length === 0 ? (
                <EmptyState icon={<FileText />} title="No proposals yet" action={<Link to={{ name: 'missions' }} className="btn-primary">Browse open goals</Link>} />
              ) : ps.map((p) => (
                <Link key={p.id} to={{ name: 'mission', id: p.missionId }} className="card block p-4 transition hover:ring-brand-200">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-sm font-semibold text-ink-900">{p.missionTitle}</p>
                    <span className={`chip capitalize ${p.status === 'accepted' ? 'bg-brand-100 text-brand-700' : p.status === 'rejected' ? 'bg-ink-100 text-ink-500' : 'bg-sky-100 text-sky-700'}`}>{p.status}</span>
                  </div>
                  <p className="mt-1 text-xs text-ink-400">{money(p.price)} · {timeAgo(p.createdAt)}</p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export function DashboardPage() {
  const { user, profile } = useAuth();
  if (!user || !profile) return <PageLoader />;
  const isStudent = profile.role === 'student';

  return (
    <div className="section py-10">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink-900">Hi {profile.fullName.split(' ')[0]} 👋</h1>
          <p className="mt-1 text-sm text-ink-500">{isStudent ? 'Track your goals, contracts and payments.' : 'Track your proposals, contracts and earnings.'}</p>
        </div>
        {isStudent
          ? <Link to={{ name: 'post' }} className="btn-primary"><Sparkles className="h-4 w-4" /> New learning goal</Link>
          : <Link to={{ name: 'missions' }} className="btn-primary"><Sparkles className="h-4 w-4" /> Find open goals</Link>}
      </div>
      {isStudent ? <StudentDashboard userId={user.id} /> : <TutorDashboard userId={user.id} />}
    </div>
  );
}
