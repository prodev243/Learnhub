import { useState } from 'react';
import {
  ArrowLeft, BadgeCheck, BookOpen, Calendar, CheckCircle2, Clock, Gavel, Loader2, MessageSquare, Milestone as MilestoneIcon,
  ShieldCheck, Star, TrendingDown, Users, Wallet, XCircle,
} from 'lucide-react';
import { Link, useNav } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks';
import { useStartChat } from '@/chat';
import { acceptProposal, cancelMission, fetchPayoutAccount, fetchTutorProfile, getMission, listProposalsForMission, withdrawProposal } from '@/lib/api';
import { errorMessage, money, timeAgo } from '@/lib/format';
import { Avatar, ConfirmDialog, ErrorNote, PageLoader, SaveButton, Spinner, Stars } from '@/components/ui';
import { statusLabel } from '@/components/cards';
import { ProposalForm } from '@/components/ProposalForm';
import type { Proposal } from '@/types';

export function MissionDetailPage({ id }: { id: string }) {
  const { user, profile } = useAuth();
  const { navigate } = useNav();
  const toast = useToast();
  const chat = useStartChat();

  const mission = useAsync(() => getMission(id), [id]);
  const proposals = useAsync(() => (user ? listProposalsForMission(id) : Promise.resolve([] as Proposal[])), [id, user?.id]);
  const isTutor = profile?.role === 'tutor';
  const tutorReady = useAsync(async () => {
    if (!user || !isTutor) return { published: false, payout: false };
    const [tp, payout] = await Promise.all([fetchTutorProfile(user.id), fetchPayoutAccount(user.id)]);
    return { published: Boolean(tp?.isPublished), payout: Boolean(payout) };
  }, [user?.id, isTutor]);

  const [accepting, setAccepting] = useState<Proposal | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [withdrawing, setWithdrawing] = useState<Proposal | null>(null);
  const [busy, setBusy] = useState(false);
  const [showCompare, setShowCompare] = useState(false);

  if (mission.loading) return <PageLoader />;
  if (mission.error) return <div className="section py-16"><ErrorNote message={mission.error} onRetry={mission.reload} /></div>;
  const m = mission.data;
  if (!m) {
    return (
      <div className="section py-20 text-center">
        <p className="text-lg font-semibold text-ink-700">Mission not found</p>
        <Link to={{ name: 'missions' }} className="btn-primary mt-4">Back to missions</Link>
      </div>
    );
  }

  const isOwner = user?.id === m.studentId;
  const list = proposals.data ?? [];
  const mine = list.find((p) => p.tutorId === user?.id && p.status !== 'withdrawn');
  const active = list.filter((p) => p.status !== 'rejected' || isOwner);
  const maxBid = Math.max(...list.map((p) => p.price), 1);
  const minBid = list.length ? Math.min(...list.map((p) => p.price)) : 0;

  const run = async (fn: () => Promise<void>, ok: string) => {
    setBusy(true);
    try {
      await fn();
      toast.success(ok);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const doAccept = () => accepting && run(async () => {
    await acceptProposal(accepting.id);
    setAccepting(null);
    navigate({ name: 'dashboard' });
  }, 'Proposal accepted — your contract is ready. Fund the first milestone to begin.');

  const doCancel = () => run(async () => { await cancelMission(m.id); setCancelling(false); mission.reload(); }, 'Your goal has been closed.');
  const doWithdraw = () => withdrawing && run(async () => { await withdrawProposal(withdrawing.id); setWithdrawing(null); proposals.reload(); mission.reload(); }, 'Proposal withdrawn.');

  const back = isOwner ? { name: 'dashboard' as const } : { name: 'missions' as const };

  return (
    <div className="section py-8">
      <Link to={back} className="btn-ghost -ml-3 mb-6"><ArrowLeft className="h-4 w-4" /> {isOwner ? 'Back to dashboard' : 'Back to missions'}</Link>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <div className="card animate-fade-up p-6">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip bg-ink-100 text-ink-700">{m.category}</span>
              <span className="chip bg-ink-100 text-ink-700">{m.level}</span>
              <span className={`chip ${m.status === 'open' ? 'bg-brand-100 text-brand-700' : m.status === 'cancelled' ? 'bg-red-50 text-red-600' : 'bg-sky-100 text-sky-700'}`}>{statusLabel[m.status]}</span>
              <span className="ml-auto"><SaveButton kind="mission" id={m.id} className="ring-1 ring-ink-200" /></span>
            </div>
            <h1 className="mt-3 font-display text-2xl font-extrabold tracking-tight text-ink-900 text-balance sm:text-3xl">{m.title}</h1>
            <div className="mt-4 flex items-center gap-3">
              <Avatar name={m.student} size={40} />
              <div>
                <p className="text-sm font-medium text-ink-800">{m.student}</p>
                <p className="text-xs text-ink-400">Posted {timeAgo(m.createdAt)}</p>
              </div>
            </div>
            <p className="mt-5 whitespace-pre-line text-sm leading-relaxed text-ink-600">{m.description}</p>

            <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {[
                { icon: Wallet, label: 'Budget', value: money(m.budget) },
                { icon: Clock, label: 'Timeline', value: m.deadline || '—' },
                { icon: Calendar, label: 'Availability', value: m.availability || '—' },
                { icon: BookOpen, label: 'Learning style', value: m.learningStyle || '—' },
              ].map((item) => (
                <div key={item.label} className="rounded-xl bg-ink-50 p-3">
                  <item.icon className="h-4 w-4 text-brand-600" />
                  <p className="mt-2 text-[10px] uppercase tracking-wide text-ink-400">{item.label}</p>
                  <p className="text-sm font-semibold text-ink-900">{item.value}</p>
                </div>
              ))}
            </div>

            {isOwner && m.status === 'open' && (
              <div className="mt-5 border-t border-ink-100 pt-4">
                <button onClick={() => setCancelling(true)} className="btn-ghost text-red-600 hover:bg-red-50"><XCircle className="h-4 w-4" /> Close this goal</button>
              </div>
            )}
            {isOwner && m.status === 'in_progress' && (
              <div className="mt-5 flex items-center justify-between gap-3 rounded-xl bg-sky-50 p-4 text-sm text-sky-900">
                <span>A tutor has been hired for this goal.</span>
                <Link to={{ name: 'dashboard' }} className="btn-secondary">Open contract</Link>
              </div>
            )}
          </div>

          {/* Bid overview (owner only) */}
          {isOwner && list.length > 1 && (
            <div className="card animate-fade-up animate-delay-100 p-6">
              <div className="flex items-center justify-between">
                <h2 className="flex items-center gap-2 font-display text-xl font-bold text-ink-900"><Gavel className="h-5 w-5 text-brand-600" /> Bid breakdown</h2>
                <button onClick={() => setShowCompare(!showCompare)} className="btn-ghost text-xs">{showCompare ? 'Hide' : 'Compare'} side-by-side</button>
              </div>
              <p className="mt-1 text-sm text-ink-500">Lowest bid: <span className="font-bold text-brand-600">{money(minBid)}</span> · Your budget: <span className="font-bold text-ink-900">{money(m.budget)}</span></p>
              <div className="mt-5 space-y-3">
                {list.map((p) => (
                  <div key={p.id} className="flex items-center gap-3">
                    <Avatar name={p.tutorName} size={32} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="truncate text-sm font-medium text-ink-800">{p.tutorName}</span>
                        <span className={`text-sm font-bold ${p.price === minBid ? 'text-brand-600' : 'text-ink-700'}`}>{money(p.price)}</span>
                      </div>
                      <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-ink-100">
                        <div className={`h-full rounded-full ${p.price === minBid ? 'bg-gradient-to-r from-brand-500 to-sky-500' : 'bg-ink-300'}`} style={{ width: `${(p.price / maxBid) * 100}%` }} />
                      </div>
                      <div className="mt-0.5 flex items-center gap-2 text-[10px] text-ink-400">
                        <span>{p.timeline}</span>
                        {p.tutor?.rating != null && <span className="flex items-center gap-0.5">· <Star className="h-2.5 w-2.5 fill-sky-400 text-sky-400" /> {p.tutor.rating}</span>}
                        {p.tutor?.verified && <span className="chip bg-brand-50 px-1.5 py-0 text-brand-600">Verified</span>}
                        {p.price === minBid && <span className="chip bg-brand-100 px-1.5 py-0 text-brand-700"><TrendingDown className="h-2.5 w-2.5" /> Lowest</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {showCompare && (
                <div className="mt-6 overflow-x-auto animate-fade-in">
                  <table className="w-full text-sm">
                    <thead><tr className="border-b border-ink-100 text-left text-xs text-ink-400"><th className="pb-2 pr-4">Tutor</th><th className="pb-2 pr-4">Bid</th><th className="pb-2 pr-4">Timeline</th><th className="pb-2 pr-4">Milestones</th><th className="pb-2">Rating</th></tr></thead>
                    <tbody>
                      {list.map((p) => (
                        <tr key={p.id} className="border-b border-ink-50">
                          <td className="py-2.5 pr-4 font-medium text-ink-800">{p.tutorName}</td>
                          <td className="py-2.5 pr-4 font-bold text-brand-600">{money(p.price)}</td>
                          <td className="py-2.5 pr-4 text-ink-600">{p.timeline}</td>
                          <td className="py-2.5 pr-4 text-ink-600">{p.milestones.length}</td>
                          <td className="py-2.5 text-ink-600">{p.tutor?.rating ?? '—'}{p.tutor?.verified && <BadgeCheck className="ml-1 inline h-4 w-4 text-brand-500" />}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Proposals */}
          <div className="animate-fade-up animate-delay-200">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-ink-900">Proposals <span className="text-ink-400">({m.proposalsCount})</span></h2>
              {m.status === 'open' && <span className="chip bg-brand-50 text-brand-700"><Users className="h-3 w-3" /> Accepting proposals</span>}
            </div>

            <div className="mt-4 space-y-4">
              {/* Tutor: form or status of own proposal */}
              {isTutor && m.status === 'open' && !mine && (
                tutorReady.loading ? <Spinner /> : !tutorReady.data?.published ? (
                  <div className="card p-6 text-sm text-ink-600">
                    <p className="font-semibold text-ink-900">Complete your tutor profile to send proposals</p>
                    <p className="mt-1">Add a headline, bio, categories and your starting price so students can trust who they hire.</p>
                    <Link to={{ name: 'account' }} className="btn-primary mt-4">Complete profile</Link>
                  </div>
                ) : !tutorReady.data?.payout ? (
                  <div className="card p-6 text-sm text-ink-600">
                    <p className="font-semibold text-ink-900">Add your bank details to get paid</p>
                    <p className="mt-1">Students' payments are sent straight to your bank account, so we need your payout details before you can send proposals.</p>
                    <Link to={{ name: 'account' }} className="btn-primary mt-4">Add bank details</Link>
                  </div>
                ) : (
                  <ProposalForm mission={m} tutorId={user!.id} onSent={() => { toast.success('Proposal sent!'); proposals.reload(); mission.reload(); }} />
                )
              )}

              {!user && m.status === 'open' && (
                <div className="card p-6 text-center">
                  <p className="text-sm text-ink-600">Log in to send a proposal or to save this goal.</p>
                  <div className="mt-4 flex justify-center gap-3">
                    <button onClick={() => navigate({ name: 'login', next: `/missions/${m.id}` })} className="btn-primary">Log in</button>
                    <button onClick={() => navigate({ name: 'signup', role: 'tutor', next: `/missions/${m.id}` })} className="btn-secondary">Sign up as a tutor</button>
                  </div>
                </div>
              )}

              {user && !isOwner && !isTutor && m.status === 'open' && (
                <div className="card p-6 text-center text-sm text-ink-500">Only tutor accounts can send proposals.</div>
              )}

              {proposals.loading && user ? <Spinner /> : proposals.error ? <ErrorNote message={proposals.error} onRetry={proposals.reload} /> : null}

              {isOwner && !proposals.loading && active.length === 0 && (
                <div className="card p-8 text-center text-sm text-ink-400">No proposals yet. Invite tutors from their profile page to speed things up.</div>
              )}

              {(isOwner ? active : mine ? [mine] : []).map((p) => (
                <div key={p.id} className={`card p-5 transition ${p.status === 'accepted' ? 'shadow-glow ring-2 ring-brand-400' : ''}`}>
                  <div className="flex items-start gap-4">
                    <Avatar name={p.tutorName} size={48} ring />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <Link to={{ name: 'tutor', id: p.tutorId }} className="font-display font-bold text-ink-900 hover:text-brand-600">{p.tutorName}</Link>
                        {p.tutor?.rating != null && <><Stars rating={p.tutor.rating} /><span className="text-xs text-ink-400">({p.tutor.reviewCount})</span></>}
                        {p.tutor?.verified && <BadgeCheck className="h-4 w-4 text-brand-500" />}
                      </div>
                      {p.tutor?.headline && <p className="text-sm text-ink-500">{p.tutor.headline}</p>}
                      <p className="mt-0.5 text-xs text-ink-400">Sent {timeAgo(p.createdAt)}{!isOwner && ` · ${p.status}`}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-display text-xl font-extrabold text-brand-600">{money(p.price)}</p>
                      <p className="text-xs text-ink-400">{p.timeline}</p>
                    </div>
                  </div>

                  <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-ink-600">{p.coverLetter}</p>

                  {p.approach.length > 0 && (
                    <div className="mt-4 rounded-xl bg-ink-50 p-4">
                      <p className="text-xs font-semibold uppercase tracking-wide text-ink-500">Teaching approach</p>
                      <ul className="mt-2 space-y-1.5">
                        {p.approach.map((a, i) => <li key={i} className="flex items-start gap-2 text-sm text-ink-700"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-500" /> {a}</li>)}
                      </ul>
                    </div>
                  )}

                  <div className="mt-4">
                    <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-ink-500"><MilestoneIcon className="h-3.5 w-3.5" /> Milestones</p>
                    <div className="mt-2 space-y-2">
                      {p.milestones.map((ms, i) => (
                        <div key={i} className="flex gap-3 rounded-lg border border-ink-100 p-3">
                          <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand-100 text-xs font-bold text-brand-700">{i + 1}</span>
                          <div className="min-w-0 flex-1"><p className="text-sm font-semibold text-ink-900">{ms.title}</p>{ms.detail && <p className="text-xs text-ink-500">{ms.detail}</p>}</div>
                          <p className="text-sm font-bold text-ink-900">{money(ms.amount)}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mt-5 flex flex-wrap items-center gap-3">
                    {isOwner && p.status === 'pending' && m.status === 'open' && (
                      <>
                        <button onClick={() => setAccepting(p)} className="btn-primary">Accept &amp; start contract</button>
                        <button onClick={() => chat.start(p.tutorId)} disabled={chat.busy} className="btn-secondary"><MessageSquare className="h-4 w-4" /> Message</button>
                      </>
                    )}
                    {isOwner && p.status === 'accepted' && <span className="chip bg-brand-100 text-brand-700"><CheckCircle2 className="h-4 w-4" /> Accepted — contract created</span>}
                    {isOwner && p.status === 'rejected' && <span className="chip bg-ink-100 text-ink-500">Not selected</span>}
                    {!isOwner && p.status === 'pending' && <button onClick={() => setWithdrawing(p)} className="btn-ghost text-red-600 hover:bg-red-50">Withdraw proposal</button>}
                    {!isOwner && p.status === 'accepted' && <Link to={{ name: 'dashboard' }} className="btn-primary">Open contract</Link>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div>
          <div className="card p-6 lg:sticky lg:top-32">
            <h3 className="font-display font-bold text-ink-900">Mission summary</h3>
            <dl className="mt-4 space-y-3 text-sm">
              {([
                ['Category', m.category], ['Level', m.level], ['Budget', money(m.budget)], ['Timeline', m.deadline || '—'],
                ['Proposals', `${m.proposalsCount} received`], ['Status', statusLabel[m.status]],
              ] as [string, string][]).map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3"><dt className="text-ink-400">{k}</dt><dd className="text-right font-medium text-ink-900">{v}</dd></div>
              ))}
            </dl>
            <div className="mt-5 rounded-xl bg-brand-50 p-4 text-xs text-brand-800">
              <ShieldCheck className="h-4 w-4 text-brand-600" />
              <p className="mt-1.5 leading-relaxed">You fund one milestone at a time and approve the work before the next one starts.</p>
            </div>
            {!isOwner && user && (
              <button onClick={() => chat.start(m.studentId)} disabled={chat.busy} className="btn-secondary mt-4 w-full">
                {chat.busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquare className="h-4 w-4" />} Message {m.student.split(' ')[0]}
              </button>
            )}
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={accepting !== null} busy={busy} confirmLabel="Accept proposal" title="Accept this proposal?"
        message={accepting ? `You're hiring ${accepting.tutorName} for ${money(accepting.price)} across ${accepting.milestones.length} milestone${accepting.milestones.length === 1 ? '' : 's'}. Other proposals will be declined. You'll fund one milestone at a time.` : ''}
        onConfirm={doAccept} onCancel={() => setAccepting(null)}
      />
      <ConfirmDialog
        open={cancelling} busy={busy} danger confirmLabel="Close goal" title="Close this goal?"
        message="Tutors will no longer be able to send proposals. This can't be undone."
        onConfirm={doCancel} onCancel={() => setCancelling(false)}
      />
      <ConfirmDialog
        open={withdrawing !== null} busy={busy} danger confirmLabel="Withdraw" title="Withdraw your proposal?"
        message="The student will no longer see it. You can't send another proposal to this goal afterwards."
        onConfirm={doWithdraw} onCancel={() => setWithdrawing(null)}
      />
    </div>
  );
}
