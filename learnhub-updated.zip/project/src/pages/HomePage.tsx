import {
  ArrowRight, Award, CheckCircle2, Clock, Compass, Gavel, GraduationCap, Handshake, Milestone, PenSquare,
  ShieldCheck, Sparkles, Star, Target, Wallet, Zap,
} from 'lucide-react';
import { Link } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useAsync } from '@/hooks';
import { listContests, listLatestMissions, listTopTutors } from '@/lib/api';
import { ContestCard, MissionCard, TutorCard } from '@/components/cards';
import { SectionHeader, Spinner } from '@/components/ui';
import { CATEGORIES, CATEGORY_BLURBS } from '@/types';
import { DEFAULT_BUDGET } from '@/lib/config';
import { money } from '@/lib/format';

export function HomePage() {
  const { profile } = useAuth();
  const missions = useAsync(() => listLatestMissions(3), []);
  const tutors = useAsync(() => listTopTutors(3), []);
  const contests = useAsync(async () => (await listContests()).filter((c) => c.status !== 'completed').slice(0, 3), []);

  const postTarget = profile?.role === 'student' ? ({ name: 'post' } as const) : ({ name: 'signup', role: 'student' } as const);
  const tutorTarget = profile?.role === 'tutor' ? ({ name: 'account' } as const) : ({ name: 'signup', role: 'tutor' } as const);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-white">
        <div className="absolute inset-0 bg-grid opacity-60" />
        <div className="absolute -right-40 -top-40 h-96 w-96 rounded-full bg-brand-200/40 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-sky-200/30 blur-3xl" />

        <div className="section relative grid items-center gap-12 py-16 lg:grid-cols-2 lg:py-24">
          <div className="animate-fade-up">
            <span className="chip bg-brand-50 text-brand-700 ring-1 ring-brand-200"><Sparkles className="h-3.5 w-3.5" /> Guided tutor matching</span>
            <h1 className="mt-5 font-display text-4xl font-extrabold leading-[1.1] tracking-tight text-ink-900 text-balance sm:text-5xl lg:text-6xl">
              Don't book a tutor.
              <br />
              <span className="gradient-text">Post a learning goal.</span>
            </h1>
            <p className="mt-5 max-w-lg text-lg text-ink-500 text-balance">
              A project-based learning marketplace. Tell us what you want to achieve, compare proposals from tutors, and reach your goal one milestone at a time.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to={postTarget} className="btn-gradient text-base"><PenSquare className="h-5 w-5" /> Post a learning goal</Link>
              <Link to={{ name: 'match' }} className="btn-secondary text-base"><Sparkles className="h-5 w-5 text-brand-600" /> Find my tutor</Link>
            </div>
            <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-ink-500">
              <div className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-brand-500" /> Pay one milestone at a time</div>
              <div className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-brand-500" /> Compare proposals</div>
              <div className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-brand-500" /> Reviews from real students</div>
            </div>
          </div>

          {/* Illustration of the flow (example content, not real users) */}
          <div className="animate-fade-up animate-delay-200 relative" aria-hidden="true">
            <div className="card rotate-1 p-5 transition-transform hover:rotate-0">
              <div className="flex items-center justify-between">
                <span className="chip bg-brand-100 text-brand-700">Languages</span>
                <span className="chip bg-ink-100 text-ink-600">Example goal</span>
              </div>
              <h3 className="mt-3 font-display text-lg font-bold text-ink-900">Pass IELTS with band 7.0 in 3 months</h3>
              <p className="mt-2 text-sm text-ink-500">Currently at band 5.5. Weakest: speaking and writing. Need structured weekly plans and accountability.</p>
              <div className="mt-4 flex items-center justify-between text-sm">
                <span className="chip bg-ink-50 text-ink-600"><Clock className="h-3 w-3" /> 3 months</span>
                <span className="text-base font-bold text-ink-900">{money(DEFAULT_BUDGET)}</span>
              </div>
            </div>
            <div className="card -mt-6 ml-8 -rotate-2 p-4 transition-transform hover:rotate-0">
              <p className="text-sm font-bold text-ink-900">Tutors send proposals</p>
              <p className="text-xs text-ink-400">A plan, a price and clear milestones — you choose.</p>
              <div className="mt-3 flex items-center gap-1 text-sky-500">{[1, 2, 3, 4, 5].map((i) => <Star key={i} className="h-3.5 w-3.5 fill-current" />)}</div>
            </div>
            <div className="card -mt-4 ml-2 rotate-2 p-4 transition-transform hover:rotate-0">
              <div className="flex items-center gap-2 text-xs text-brand-700"><ShieldCheck className="h-4 w-4" /> Fund milestone by milestone</div>
              <p className="mt-1.5 text-sm font-medium text-ink-800">Approve the work, then fund the next step.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Value strip */}
      <section className="border-y border-ink-100 bg-gradient-to-br from-brand-900 via-brand-800 to-sky-900 text-white">
        <div className="section grid grid-cols-2 gap-6 py-10 md:grid-cols-4">
          {[
            { icon: Target, label: 'Outcome-focused goals' },
            { icon: Gavel, label: 'Tutors compete with proposals' },
            { icon: Wallet, label: 'Milestone-based payments' },
            { icon: Award, label: 'Verified student reviews' },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <s.icon className="mx-auto h-6 w-6 text-sky-300" />
              <p className="mt-2 text-sm font-semibold sm:text-base">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="section py-16">
        <SectionHeader center eyebrow="Explore" title="What do you want to learn?" subtitle="From languages to coding, music to maths — find tutors who turn goals into outcomes." />
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {CATEGORIES.map((cat) => (
            <Link key={cat} to={{ name: 'tutors', category: cat }} className="card group flex items-center gap-4 p-4 text-left transition-all hover:-translate-y-1 hover:ring-brand-200">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-50 to-sky-100 text-brand-600 transition group-hover:from-brand-500 group-hover:to-sky-500 group-hover:text-white">
                <Compass className="h-6 w-6" />
              </span>
              <div className="min-w-0">
                <p className="font-display font-bold text-ink-900">{cat}</p>
                <p className="truncate text-xs text-ink-400">{CATEGORY_BLURBS[cat]}</p>
              </div>
            </Link>
          ))}
          <Link to={{ name: 'tutors' }} className="card group flex items-center justify-center gap-2 p-4 text-brand-600 transition-all hover:-translate-y-1 hover:ring-brand-200">
            View all <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
          </Link>
        </div>
      </section>

      {/* How it works */}
      <section className="bg-white py-16">
        <div className="section">
          <SectionHeader center eyebrow="How it works" title="Hire a tutor like you hire a freelancer" subtitle="Education as a managed project — goals, proposals, milestones and honest reviews." />
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: PenSquare, title: 'Post your goal', text: 'Describe what you want to achieve, your level, budget and timeline.' },
              { icon: Gavel, title: 'Tutors send proposals', text: 'Tutors reply with a plan, a price and milestones. Compare and choose.' },
              { icon: Milestone, title: 'Learn by milestones', text: 'Fund one milestone at a time and approve the work before the next one starts.' },
              { icon: Award, title: 'Review your tutor', text: 'When the contract is complete, leave a review that helps the next student.' },
            ].map((step, i) => (
              <div key={step.title} className="card h-full p-6">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-sky-500 font-display text-lg font-bold text-white">{i + 1}</span>
                <step.icon className="mt-4 h-6 w-6 text-brand-600" />
                <h3 className="mt-3 font-display text-lg font-bold text-ink-900">{step.title}</h3>
                <p className="mt-2 text-sm text-ink-500">{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Open missions */}
      <section className="section py-16">
        <div className="flex items-end justify-between gap-4">
          <SectionHeader eyebrow="Learning missions" title="Open goals looking for tutors" subtitle="Browse learning projects posted by students and submit your proposal." />
          <Link to={{ name: 'missions' }} className="btn-ghost hidden shrink-0 sm:inline-flex">View all <ArrowRight className="h-4 w-4" /></Link>
        </div>
        {missions.loading ? <Spinner /> : missions.data && missions.data.length > 0 ? (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{missions.data.map((m) => <MissionCard key={m.id} mission={m} />)}</div>
        ) : (
          <div className="card mt-8 flex flex-col items-center p-10 text-center">
            <Handshake className="h-10 w-10 text-brand-300" />
            <p className="mt-3 font-display font-bold text-ink-900">No open goals yet</p>
            <p className="mt-1 text-sm text-ink-500">Be the first to post a learning goal and start receiving proposals.</p>
            <Link to={postTarget} className="btn-primary mt-5">Post a goal</Link>
          </div>
        )}
      </section>

      {/* Contests */}
      {contests.data && contests.data.length > 0 && (
        <section className="bg-white py-16">
          <div className="section">
            <div className="flex items-end justify-between gap-4">
              <SectionHeader eyebrow="Learning contests" title="Compete. Win prizes. Get discovered." subtitle="Tutors submit their best lesson plans. The community votes. Winners get prizes." />
              <Link to={{ name: 'contests' }} className="btn-ghost hidden shrink-0 sm:inline-flex">View all <ArrowRight className="h-4 w-4" /></Link>
            </div>
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{contests.data.map((c) => <ContestCard key={c.id} contest={c} />)}</div>
          </div>
        </section>
      )}

      {/* Top tutors */}
      <section className="section py-16">
        <div className="flex items-end justify-between gap-4">
          <SectionHeader eyebrow="Tutors" title="Meet the tutors" subtitle="Measured on teaching clarity, student improvement, reliability and patience — not just popularity." />
          <Link to={{ name: 'tutors' }} className="btn-ghost hidden shrink-0 sm:inline-flex">View all <ArrowRight className="h-4 w-4" /></Link>
        </div>
        {tutors.loading ? <Spinner /> : tutors.data && tutors.data.length > 0 ? (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{tutors.data.map((t) => <TutorCard key={t.id} tutor={t} />)}</div>
        ) : (
          <div className="card mt-8 flex flex-col items-center p-10 text-center">
            <GraduationCap className="h-10 w-10 text-brand-300" />
            <p className="mt-3 font-display font-bold text-ink-900">Tutors are joining now</p>
            <p className="mt-1 text-sm text-ink-500">Are you a tutor? Create your profile and start sending proposals.</p>
            <Link to={tutorTarget} className="btn-primary mt-5">Become a tutor</Link>
          </div>
        )}
      </section>

      {/* Reputation */}
      <section className="bg-white py-16">
        <div className="section">
          <SectionHeader center eyebrow="Beyond star ratings" title="A reputation system built for teaching" subtitle="After every completed contract, students score their tutor on what actually matters in education." />
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { t: 'Teaching clarity', d: 'Can they explain complex things simply?' },
              { t: 'Student improvement', d: 'How much do learners actually progress?' },
              { t: 'Reliability', d: 'Do they show up and deliver on time?' },
              { t: 'Patience', d: 'Do they adapt to different learning speeds?' },
            ].map((x) => (
              <div key={x.t} className="card p-5">
                <CheckCircle2 className="h-6 w-6 text-brand-500" />
                <p className="mt-3 font-display font-bold text-ink-900">{x.t}</p>
                <p className="mt-1 text-sm text-ink-500">{x.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-br from-brand-700 via-brand-600 to-sky-600 py-20">
        <div className="section text-center">
          <Zap className="mx-auto h-10 w-10 text-sky-200" />
          <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-white text-balance sm:text-4xl">Your next learning goal starts here</h2>
          <p className="mx-auto mt-3 max-w-xl text-brand-100 text-balance">Post what you want to achieve. Let tutors come to you with plans. Pay one milestone at a time.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to={postTarget} className="btn bg-white text-base text-brand-700 hover:bg-brand-50"><PenSquare className="h-5 w-5" /> Post a learning goal</Link>
            <Link to={{ name: 'match' }} className="btn bg-brand-800/40 text-base text-white ring-1 ring-white/30 hover:bg-brand-800/60"><Sparkles className="h-5 w-5" /> Try Tutor Match</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
