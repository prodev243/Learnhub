import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowLeft, Inbox, Loader2, Send } from 'lucide-react';
import { Link, useNav } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks';
import { listConversations, listMessages, sendMessage, subscribeToMessages } from '@/lib/api';
import { errorMessage, timeAgo } from '@/lib/format';
import { Avatar, EmptyState, ErrorNote, Spinner } from '@/components/ui';
import type { Message } from '@/types';

function Thread({ conversationId, otherName, onSent }: { conversationId: string; otherName: string; onSent: () => void }) {
  const { user } = useAuth();
  const toast = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);

  const merge = (incoming: Message[]) =>
    setMessages((prev) => {
      const map = new Map(prev.map((m) => [m.id, m]));
      incoming.forEach((m) => map.set(m.id, m));
      return [...map.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    });

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    setMessages([]);
    listMessages(conversationId)
      .then((m) => { if (!cancelled) merge(m); })
      .catch((e) => { if (!cancelled) setError(errorMessage(e)); })
      .finally(() => { if (!cancelled) setLoading(false); });
    const unsubscribe = subscribeToMessages(conversationId, (m) => merge([m]));
    // Fallback in case realtime is unavailable.
    const poll = window.setInterval(() => {
      listMessages(conversationId).then((m) => { if (!cancelled) merge(m); }).catch(() => {});
    }, 15000);
    return () => { cancelled = true; unsubscribe(); window.clearInterval(poll); };
  }, [conversationId]);

  useEffect(() => { bottom.current?.scrollIntoView({ block: 'end' }); }, [messages.length]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !text.trim() || sending) return;
    setSending(true);
    try {
      const m = await sendMessage(conversationId, user.id, text);
      merge([m]);
      setText('');
      onSent();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-4">
        {loading ? <Spinner /> : error ? <ErrorNote message={error} /> : messages.length === 0 ? (
          <p className="py-10 text-center text-sm text-ink-400">Say hello to {otherName.split(' ')[0]} 👋</p>
        ) : messages.map((m) => {
          const mine = m.senderId === user?.id;
          return (
            <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${mine ? 'rounded-br-md bg-brand-500 text-white' : 'rounded-bl-md bg-ink-100 text-ink-800'}`}>
                <p className="whitespace-pre-wrap break-words">{m.body}</p>
                <p className={`mt-1 text-[10px] ${mine ? 'text-brand-100' : 'text-ink-400'}`}>{timeAgo(m.createdAt)}</p>
              </div>
            </div>
          );
        })}
        <div ref={bottom} />
      </div>
      <form onSubmit={submit} className="flex items-end gap-2 border-t border-ink-100 p-3">
        <textarea
          rows={1} maxLength={4000} value={text} onChange={(e) => setText(e.target.value)} aria-label="Message"
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void submit(e as unknown as FormEvent); } }}
          placeholder="Write a message…" className="input max-h-32 resize-none py-2.5"
        />
        <button type="submit" disabled={!text.trim() || sending} aria-label="Send" className="btn-primary h-11 w-11 shrink-0 p-0 disabled:opacity-50">
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </button>
      </form>
    </div>
  );
}

export function MessagesPage({ conversationId }: { conversationId?: string }) {
  const { user } = useAuth();
  const { navigate } = useNav();
  const convs = useAsync(() => listConversations(user!.id), [user?.id]);
  const list = convs.data ?? [];
  const selected = list.find((c) => c.id === conversationId);

  return (
    <div className="section py-8">
      <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink-900">Messages</h1>
      <div className="card mt-6 grid h-[70vh] min-h-[420px] overflow-hidden md:grid-cols-3">
        <aside className={`min-h-0 overflow-y-auto border-ink-100 md:border-r ${conversationId ? 'hidden md:block' : ''}`}>
          {convs.loading ? <Spinner /> : convs.error ? <div className="p-4"><ErrorNote message={convs.error} onRetry={convs.reload} /></div> : list.length === 0 ? (
            <div className="p-6"><EmptyState icon={<Inbox />} title="No conversations yet" text="Message a tutor or student from their profile or goal page." action={<Link to={{ name: 'tutors' }} className="btn-primary">Find tutors</Link>} /></div>
          ) : list.map((c) => (
            <button key={c.id} onClick={() => navigate({ name: 'messages', id: c.id })} className={`flex w-full items-center gap-3 border-b border-ink-50 p-4 text-left hover:bg-ink-50 ${c.id === conversationId ? 'bg-brand-50' : ''}`}>
              <Avatar name={c.otherName} size={40} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2"><p className="truncate text-sm font-semibold text-ink-900">{c.otherName}</p><span className="shrink-0 text-[10px] text-ink-400">{timeAgo(c.lastMessageAt)}</span></div>
                <p className="truncate text-xs text-ink-500">{c.lastMessage || 'No messages yet'}</p>
              </div>
            </button>
          ))}
        </aside>

        <section className={`min-h-0 md:col-span-2 ${conversationId ? '' : 'hidden md:block'}`}>
          {conversationId ? (
            <div className="flex h-full min-h-0 flex-col">
              <div className="flex items-center gap-3 border-b border-ink-100 p-3">
                <button onClick={() => navigate({ name: 'messages' })} aria-label="Back to conversations" className="rounded-lg p-2 hover:bg-ink-100 md:hidden"><ArrowLeft className="h-4 w-4" /></button>
                {selected ? <><Avatar name={selected.otherName} size={36} /><p className="font-semibold text-ink-900">{selected.otherName}</p></> : convs.loading ? null : <p className="text-sm text-ink-500">Conversation not found</p>}
              </div>
              {selected ? <div className="min-h-0 flex-1"><Thread key={selected.id} conversationId={selected.id} otherName={selected.otherName} onSent={convs.reload} /></div> : null}
            </div>
          ) : (
            <div className="grid h-full place-items-center p-6 text-center text-sm text-ink-400">Select a conversation to start chatting.</div>
          )}
        </section>
      </div>
    </div>
  );
}
