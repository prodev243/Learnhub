import { useState } from 'react';
import { Compass, Search } from 'lucide-react';
import { listMissions, type MissionFilters } from '@/lib/api';
import { useDebounced, usePaged } from '@/hooks';
import { MissionCard } from '@/components/cards';
import { EmptyState, ErrorNote, LoadMore, SectionHeader, Spinner } from '@/components/ui';
import { CATEGORIES, LEVELS, type Category, type Level } from '@/types';
import { LAUNCH_CATEGORY } from '@/lib/config';

export function MissionsPage() {
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState<Category | 'all'>(LAUNCH_CATEGORY ? LAUNCH_CATEGORY as Category : 'all');
  const [level, setLevel] = useState<Level | 'all'>('all');
  const [sort, setSort] = useState<MissionFilters['sort']>('recent');
  const q = useDebounced(query);

  const list = usePaged((page) => listMissions({ q, category: cat, level, sort }, page), [q, cat, level, sort]);

  return (
    <div className="section py-10">
      <SectionHeader eyebrow="Learning missions" title="Browse open learning goals" subtitle={LAUNCH_CATEGORY ? `Focused launch: ${LAUNCH_CATEGORY}. Find a goal that matches your expertise and submit a proposal.` : 'Students have posted their goals. Find one that matches your expertise and submit a proposal.'} />

      <div className="card mt-8 p-4">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search missions…" aria-label="Search missions" className="input pl-10" />
          </div>
          <div className="flex flex-wrap gap-2">
            <select value={cat} onChange={(e) => setCat(e.target.value as Category | 'all')} aria-label="Category" className="input w-auto py-2.5">
              <option value="all">All categories</option>
              {!LAUNCH_CATEGORY && CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={level} onChange={(e) => setLevel(e.target.value as Level | 'all')} aria-label="Level" className="input w-auto py-2.5">
              <option value="all">All levels</option>
              {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value as MissionFilters['sort'])} aria-label="Sort by" className="input w-auto py-2.5">
              <option value="recent">Most recent</option>
              <option value="budget-high">Budget: high to low</option>
              <option value="budget-low">Budget: low to high</option>
              <option value="proposals">Most proposals</option>
            </select>
          </div>
        </div>
      </div>

      {list.loading ? <Spinner /> : list.error ? <div className="mt-6"><ErrorNote message={list.error} /></div> : (
        <>
          <p className="mt-6 text-sm text-ink-500">{list.total} {list.total === 1 ? 'mission' : 'missions'} found</p>
          {list.items.length > 0 ? (
            <>
              <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{list.items.map((m) => <MissionCard key={m.id} mission={m} />)}</div>
              {list.hasMore && <LoadMore onClick={list.loadMore} loading={list.loadingMore} />}
            </>
          ) : (
            <div className="mt-6"><EmptyState icon={<Compass />} title="No missions match your filters" text="Try widening your search — or check back soon, new goals are posted all the time." /></div>
          )}
        </>
      )}
    </div>
  );
}
