import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { BadgeCheck, Banknote, Camera, CheckCircle2, KeyRound, Landmark, Loader2, LogOut, ShieldCheck, Trash2, User } from 'lucide-react';
import { Link, useNav } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks';
import { deleteAccount, fetchPayoutAccount, fetchTutorProfile, requestTutorVerification, saveTutorProfile, updateFullName, uploadAvatar } from '@/lib/api';
import { listBanks, savePayoutAccount, type Bank } from '@/lib/functions';
import { CURRENCY, MIN_BUDGET } from '@/lib/config';
import { errorMessage, money } from '@/lib/format';
import { Avatar, ConfirmDialog, ErrorNote, PageLoader, Spinner } from '@/components/ui';
import { CATEGORIES, type Category } from '@/types';

const RESPONSE_TIMES = ['within 1 hour', 'within a few hours', 'within a day'];

function Card({ icon: Icon, title, subtitle, children }: { icon: typeof User; title: string; subtitle?: string; children: ReactNode }) {
  return (
    <section className="card p-6">
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600"><Icon className="h-5 w-5" /></span>
        <div>
          <h2 className="font-display text-lg font-bold text-ink-900">{title}</h2>
          {subtitle && <p className="text-sm text-ink-500">{subtitle}</p>}
        </div>
      </div>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function NameForm() {
  const { user, profile, refreshProfile } = useAuth();
  const toast = useToast();
  const [name, setName] = useState(profile?.fullName ?? '');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || name.trim().length < 2) return;
    setBusy(true);
    try {
      await updateFullName(user.id, name);
      await refreshProfile();
      toast.success('Name updated.');
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card icon={User} title="Your details">
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label htmlFor="name" className="label">Full name</label>
          <input id="name" className="input mt-2" maxLength={80} value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <p className="label">Email</p>
          <p className="mt-2 rounded-xl bg-ink-50 px-4 py-2.5 text-sm text-ink-600">{user?.email}</p>
        </div>
        <button type="submit" disabled={busy || name.trim().length < 2 || name.trim() === profile?.fullName} className="btn-primary disabled:opacity-50">
          {busy && <Loader2 className="h-4 w-4 animate-spin" />} Save name
        </button>
      </form>
    </Card>
  );
}

function TutorProfileForm({ userId, onSaved }: { userId: string; onSaved: () => void }) {
  const toast = useToast();
  const existing = useAsync(() => fetchTutorProfile(userId), [userId]);
  const [f, setF] = useState({ headline: '', bio: '', location: '', categories: [] as Category[], skills: '', priceFrom: '', guarantee: '', responseTime: RESPONSE_TIMES[1] });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const p = existing.data;
    if (!p) return;
    setF({
      headline: p.headline, bio: p.bio, location: p.location, categories: p.categories, skills: p.skills.join(', '),
      priceFrom: p.priceFrom ? String(p.priceFrom) : '', guarantee: p.guarantee, responseTime: p.responseTime || RESPONSE_TIMES[1],
    });
  }, [existing.data]);

  if (existing.loading) return <Card icon={User} title="Public tutor profile"><Spinner /></Card>;
  if (existing.error) return <Card icon={User} title="Public tutor profile"><ErrorNote message={existing.error} onRetry={existing.reload} /></Card>;

  const price = Number(f.priceFrom);
  const valid = f.headline.trim().length > 0 && f.bio.trim().length >= 20 && f.categories.length > 0 && Number.isFinite(price) && price >= MIN_BUDGET / 5;
  const toggleCat = (c: Category) => setF((s) => ({ ...s, categories: s.categories.includes(c) ? s.categories.filter((x) => x !== c) : [...s.categories, c] }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!valid) return;
    setBusy(true);
    try {
      await saveTutorProfile(userId, {
        headline: f.headline, bio: f.bio, location: f.location, categories: f.categories,
        skills: f.skills.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 12),
        priceFrom: price, guarantee: f.guarantee, responseTime: f.responseTime,
      });
      toast.success('Profile saved.');
      existing.reload();
      onSaved();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const published = existing.data?.isPublished;
  return (
    <Card icon={BadgeCheck} title="Public tutor profile" subtitle="This is what students see. Fill in the essentials to appear in the tutor directory.">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <span className={`chip ${published ? 'bg-brand-100 text-brand-700' : 'bg-amber-100 text-amber-800'}`}>{published ? 'Published' : 'Not published yet'}</span>
        {existing.data?.verified && <span className="chip bg-brand-50 text-brand-700"><BadgeCheck className="h-3 w-3" /> Verified by LearnHub</span>}
        {published && <Link to={{ name: 'tutor', id: userId }} className="text-xs font-medium text-brand-600 hover:underline">View my public page</Link>}
      </div>
      <form onSubmit={submit} className="space-y-5">
        <div>
          <label htmlFor="headline" className="label">Headline</label>
          <input id="headline" className="input mt-2" maxLength={120} placeholder="e.g. IELTS coach — helped 200+ students reach band 7+" value={f.headline} onChange={(e) => setF({ ...f, headline: e.target.value })} />
        </div>
        <div>
          <label htmlFor="bio" className="label">About you</label>
          <p className="hint">At least 20 characters. Your teaching style, experience and results.</p>
          <textarea id="bio" rows={5} maxLength={3000} className="input mt-2 resize-none" value={f.bio} onChange={(e) => setF({ ...f, bio: e.target.value })} />
        </div>
        <div>
          <p className="label">Categories you teach</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button key={c} type="button" onClick={() => toggleCat(c)} aria-pressed={f.categories.includes(c)} className={`chip py-1.5 ${f.categories.includes(c) ? 'bg-brand-500 text-white' : 'bg-ink-100 text-ink-700 hover:bg-ink-200'}`}>{c}</button>
            ))}
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="skills" className="label">Skills</label>
            <p className="hint">Comma-separated, up to 12.</p>
            <input id="skills" className="input mt-2" placeholder="Speaking, Academic writing" value={f.skills} onChange={(e) => setF({ ...f, skills: e.target.value })} />
          </div>
          <div>
            <label htmlFor="location" className="label">Location</label>
            <p className="hint">City and country.</p>
            <input id="location" className="input mt-2" maxLength={80} placeholder="Lagos, Nigeria" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} />
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="price" className="label">Starting price ({CURRENCY})</label>
            <input id="price" type="number" min={0} inputMode="numeric" className="input mt-2" value={f.priceFrom} onChange={(e) => setF({ ...f, priceFrom: e.target.value })} />
            {f.priceFrom !== '' && !(price >= MIN_BUDGET / 5) && <p className="field-error">Enter at least {money(MIN_BUDGET / 5)}.</p>}
          </div>
          <div>
            <label htmlFor="resp" className="label">Typical response time</label>
            <select id="resp" className="input mt-2" value={f.responseTime} onChange={(e) => setF({ ...f, responseTime: e.target.value })}>
              {RESPONSE_TIMES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label htmlFor="guarantee" className="label">Learning guarantee <span className="font-normal text-ink-400">(optional)</span></label>
          <input id="guarantee" className="input mt-2" maxLength={200} placeholder="e.g. Free extra sessions if you don't improve" value={f.guarantee} onChange={(e) => setF({ ...f, guarantee: e.target.value })} />
        </div>
        <button type="submit" disabled={busy || !valid} className="btn-primary disabled:opacity-50">{busy && <Loader2 className="h-4 w-4 animate-spin" />} Save profile</button>
      </form>
    </Card>
  );
}

function PayoutForm({ userId }: { userId: string }) {
  const toast = useToast();
  const payout = useAsync(() => fetchPayoutAccount(userId), [userId]);
  const banks = useAsync(() => listBanks(), []);
  const [bankCode, setBankCode] = useState('');
  const [account, setAccount] = useState('');
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);

  if (payout.loading) return <Card icon={Landmark} title="Payout details"><Spinner /></Card>;

  const showForm = !payout.data || editing;
  const bank: Bank | undefined = banks.data?.find((b) => b.code === bankCode);
  const valid = Boolean(bank) && /^\d{8,12}$/.test(account.replace(/\s+/g, ''));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!bank || !valid) return;
    setBusy(true);
    try {
      await savePayoutAccount(bank, account);
      toast.success('Bank details saved. You can now receive payments.');
      setAccount(''); setBankCode(''); setEditing(false);
      payout.reload();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card icon={Landmark} title="Payout details" subtitle="Students' payments are split automatically by Paystack: your share goes straight to this bank account.">
      {!showForm && payout.data ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-brand-50 p-4">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-6 w-6 text-brand-600" />
            <div>
              <p className="text-sm font-semibold text-ink-900">{payout.data.bankName || 'Bank account'} ····{payout.data.accountLast4}</p>
              <p className="text-xs text-ink-500">Payout account is active.</p>
            </div>
          </div>
          <button onClick={() => setEditing(true)} className="btn-secondary py-2">Change</button>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          {banks.loading ? <Spinner label="Loading banks…" /> : banks.error ? <ErrorNote message={banks.error} onRetry={banks.reload} /> : (
            <>
              <div>
                <label htmlFor="bank" className="label">Bank</label>
                <select id="bank" className="input mt-2" value={bankCode} onChange={(e) => setBankCode(e.target.value)}>
                  <option value="">Select your bank</option>
                  {(banks.data ?? []).map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="acct" className="label">Account number</label>
                <input id="acct" inputMode="numeric" autoComplete="off" className="input mt-2" maxLength={14} placeholder="10-digit account number" value={account} onChange={(e) => setAccount(e.target.value.replace(/[^\d\s]/g, ''))} />
                <p className="hint mt-1.5">Sent securely to Paystack. LearnHub only stores the last 4 digits.</p>
              </div>
              <div className="flex gap-3">
                <button type="submit" disabled={busy || !valid} className="btn-primary disabled:opacity-50">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Banknote className="h-4 w-4" />} Save bank details</button>
                {payout.data && <button type="button" onClick={() => setEditing(false)} className="btn-ghost">Cancel</button>}
              </div>
            </>
          )}
        </form>
      )}
    </Card>
  );
}


function PhotoForm(){
  const {user,profile,refreshProfile}=useAuth(); const toast=useToast(); const [busy,setBusy]=useState(false);
  const change=async(file:File)=>{if(!user)return;setBusy(true);try{await uploadAvatar(user.id,file);await refreshProfile();toast.success('Profile photo updated.');}catch(e){toast.error(errorMessage(e));}finally{setBusy(false);}};
  return <Card icon={Camera} title="Profile photo" subtitle="A clear, professional photo helps people recognize who they are working with."><div className="flex items-center gap-4"><Avatar name={profile?.fullName??'User'} size={72} src={profile?.avatarUrl}/><label className="btn-secondary cursor-pointer">{busy?<Loader2 className="h-4 w-4 animate-spin"/>:<Camera className="h-4 w-4"/>} Choose photo<input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" disabled={busy} onChange={e=>{const f=e.target.files?.[0];if(f)void change(f);e.currentTarget.value='';}}/></label></div><p className="hint mt-3">JPG, PNG or WebP · maximum 5 MB.</p></Card>;
}

function VerificationForm({userId}:{userId:string}){
  const toast=useToast(); const p=useAsync(()=>fetchTutorProfile(userId),[userId]); const [busy,setBusy]=useState(false);
  if(p.loading)return <Card icon={ShieldCheck} title="Tutor verification"><Spinner/> </Card>; if(p.error)return <Card icon={ShieldCheck} title="Tutor verification"><ErrorNote message={p.error} onRetry={p.reload}/></Card>;
  const status=p.data?.verificationStatus ?? 'unsubmitted';
  const submit=async()=>{setBusy(true);try{await requestTutorVerification();toast.success('Verification request submitted.');p.reload();}catch(e){toast.error(errorMessage(e));}finally{setBusy(false);}};
  return <Card icon={ShieldCheck} title="Tutor verification" subtitle="Verification is reviewed by LearnHub before the badge is displayed."><div className="flex flex-wrap items-center gap-2"><span className="chip bg-ink-100 text-ink-700 capitalize">{status.replace('_',' ')}</span>{p.data?.verified&&<span className="chip bg-brand-50 text-brand-700"><BadgeCheck className="h-3 w-3"/> Verified</span>}</div>{status==='unsubmitted'||status==='rejected'?<><p className="mt-3 text-sm text-ink-500">Submit your completed tutor profile for review. We recommend having your identity, qualifications and teaching experience ready for the support team to verify.</p><button onClick={submit} disabled={busy} className="btn-primary mt-4">{busy&&<Loader2 className="h-4 w-4 animate-spin"/>} Request verification</button></>:<p className="mt-3 text-sm text-ink-500">{status==='pending'?'Your request is in the review queue.':'Your tutor verification is approved.'}</p>}</Card>;
}

function DeleteAccountCard(){
  const toast=useToast(); const {signOut}=useAuth(); const {navigate}=useNav(); const [open,setOpen]=useState(false); const [busy,setBusy]=useState(false);
  const remove=async()=>{setBusy(true);try{await deleteAccount();await signOut();navigate({name:'home'});toast.success('Your account data has been anonymized.');}catch(e){toast.error(errorMessage(e));}finally{setBusy(false);setOpen(false);}};
  return <><Card icon={Trash2} title="Delete account" subtitle="Your public profile is anonymized. Financial and contract records may be retained where required for accounting, fraud prevention or disputes."><button onClick={()=>setOpen(true)} className="btn-secondary text-red-600"><Trash2 className="h-4 w-4"/> Delete my account</button></Card><ConfirmDialog open={open} busy={busy} danger confirmLabel="Delete account" title="Delete your account?" message="This will anonymize your personal profile and remove it from discovery. Active contracts must be completed or resolved first." onCancel={()=>setOpen(false)} onConfirm={remove}/></>;
}

function PasswordForm() {
  const { updatePassword } = useAuth();
  const toast = useToast();
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (pw.length < 8) return toast.error('Password must be at least 8 characters.');
    if (pw !== pw2) return toast.error('The two passwords do not match.');
    setBusy(true);
    try {
      await updatePassword(pw);
      setPw(''); setPw2('');
      toast.success('Password changed.');
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card icon={KeyRound} title="Change password">
      <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
        <input type="password" autoComplete="new-password" aria-label="New password" className="input" placeholder="New password" value={pw} onChange={(e) => setPw(e.target.value)} />
        <input type="password" autoComplete="new-password" aria-label="Confirm new password" className="input" placeholder="Confirm new password" value={pw2} onChange={(e) => setPw2(e.target.value)} />
        <div className="sm:col-span-2"><button type="submit" disabled={busy || !pw} className="btn-secondary disabled:opacity-50">{busy && <Loader2 className="h-4 w-4 animate-spin" />} Update password</button></div>
      </form>
    </Card>
  );
}

export function AccountPage() {
  const { user, profile, signOut } = useAuth();
  const { navigate } = useNav();
  if (!user || !profile) return <PageLoader />;

  return (
    <div className="section py-10">
      <div className="mx-auto max-w-2xl space-y-6">
        <div>
          <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink-900">Account settings</h1>
          <p className="mt-1 text-sm capitalize text-ink-500">{profile.role} account</p>
        </div>
        <NameForm />
        <PhotoForm />
        <Card icon={BadgeCheck} title="LearnHub progress" subtitle="Points and badges are earned from meaningful activity."><div className="rounded-xl bg-brand-50 p-4"><p className="text-2xl font-extrabold text-brand-700">{profile.points ?? 0} points</p><p className="mt-1 text-xs text-brand-700">Keep completing learning goals, contracts and verified milestones to unlock badges.</p></div></Card>
        {profile.role === 'tutor' && <TutorProfileForm userId={user.id} onSaved={() => { /* profile completeness is re-read elsewhere */ }} />}
        {profile.role === 'tutor' && <PayoutForm userId={user.id} />}
        {profile.role === 'tutor' && <VerificationForm userId={user.id} />}
        <PasswordForm />
        <DeleteAccountCard />
        <button onClick={async () => { await signOut(); navigate({ name: 'home' }); }} className="btn-secondary w-full text-red-600"><LogOut className="h-4 w-4" /> Log out</button>
      </div>
    </div>
  );
}
