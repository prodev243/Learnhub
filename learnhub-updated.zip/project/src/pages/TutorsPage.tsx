import { useState } from 'react';
import { Search, Users } from 'lucide-react';
import { useNav } from '@/nav';
import { listTutors, type TutorFilters } from '@/lib/api';
import { useDebounced, usePaged } from '@/hooks';
import { TutorCard } from '@/components/cards';
import { EmptyState, ErrorNote, LoadMore, SectionHeader, Spinner } from '@/components/ui';
import { CATEGORIES, type Category } from '@/types';
import { LAUNCH_CATEGORY } from '@/lib/config';

export function TutorsPage() {
  const { page } = useNav();
  const initial = LAUNCH_CATEGORY ? LAUNCH_CATEGORY as Category : (page.name === 'tutors' && page.category && (CATEGORIES as readonly string[]).includes(page.category) ? (page.category as Category) : 'all');

  const [query, setQuery] = useState('');
  const [cat, setCat] = useState<Category | 'all'>(initial);
  const [minRating, setMinRating] = useState(0);
  const [guaranteeOnly, setGuaranteeOnly] = useState(false);
  const [sort, setSort] = useState<TutorFilters['sort']>('rating');
  const q = useDebounced(query);

  const list = usePaged((p) => listTutors({ q, category: cat, minRating, guaranteeOnly, sort }, p), [q, cat, minRating, guaranteeOnly, sort]);
  const chip = (active: boolean) => `chip ${active ? 'bg-brand-500 text-white' : 'bg-ink-100 text-ink-700 hover:bg-ink-200'}`;

  return (
    <div className="section py-10">
      <SectionHeader eyebrow="Find tutors" title="Discover tutors with proven outcomes" subtitle={LAUNCH_CATEGORY ? `Focused launch: ${LAUNCH_CATEGORY}. Browse tutors and learning guarantees in this category.` : 'Browse tutor profiles, reputation scores and learning guarantees.'} />

      <div className="mt-8 grid gap-6 lg:grid-cols-4">
        <div className="card h-fit p-5 lg:sticky lg:top-32">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search tutors…" aria-label="Search tutors" className="input pl-10" />
          </div>

          <div className="mt-5">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-400">Category</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {!LAUNCH_CATEGORY && <button onClick={() => setCat('all')} className={chip(cat === 'all')}>All</button>}
              {(LAUNCH_CATEGORY ? [LAUNCH_CATEGORY] : CATEGORIES).map((c) => <button key={c} onClick={() => setCat(c)} className={chip(cat === c)}>{c}</button>)}
            </div>
          </div>

          <div className="mt-5">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-400">Minimum rating</p>
            <div className="mt-2 flex gap-1.5">
              {[0, 4, 4.5, 5].map((r) => <button key={r} onClick={() => setMinRating(r)} className={chip(minRating === r)}>{r === 0 ? 'Any' : `${r}+`}</button>)}
            </div>
          </div>

          <label className="mt-5 flex cursor-pointer items-center gap-2">
            <input type="checkbox" checked={guaranteeOnly} onChange={(e) => setGuaranteeOnly(e.target.checked)} className="h-4 w-4 rounded accent-brand-500" />
            <span className="text-sm text-ink-700">Learning guarantee only</span>
          </label>

          <div className="mt-5">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-400">Sort by</p>
            <select value={sort} onChange={(e) => setSort(e.target.value as TutorFilters['sort'])} aria-label="Sort by" className="input mt-2 py-2.5">
              <option value="rating">Highest rated</option>
              <option value="projects">Most completed</option>
              <option value="price-low">Price: low to high</option>
              <option value="price-high">Price: high to low</option>
            </select>
          </div>
        </div>

        <div className="lg:col-span-3">
          {list.loading ? <Spinner /> : list.error ? <ErrorNote message={list.error} /> : (
            <>
              <p className="mb-4 text-sm text-ink-500">{list.total} {list.total === 1 ? 'tutor' : 'tutors'} found</p>
              {list.items.length > 0 ? (
                <>
                  <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{list.items.map((t) => <TutorCard key={t.id} tutor={t} />)}</div>
                  {list.hasMore && <LoadMore onClick={list.loadMore} loading={list.loadingMore} />}
                </>
              ) : (
                <EmptyState icon={<Users />} title="No tutors match your filters" text="Try removing some filters." />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
