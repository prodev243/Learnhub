import { useState, type FormEvent } from 'react';
import { ArrowLeft, Building2, Clock, Loader2, Send, ThumbsUp, Trophy } from 'lucide-react';
import { Link, useNav } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks';
import { createContestEntry, getContest, listContestEntries, listMyVotes, setVote } from '@/lib/api';
import { errorMessage, formatDate, money, timeAgo, timeLeft } from '@/lib/format';
import { Avatar, EmptyState, ErrorNote, PageLoader, Spinner } from '@/components/ui';

export function ContestDetailPage({ id }: { id: string }) {
  const { user, profile } = useAuth();
  const { navigate } = useNav();
  const toast = useToast();

  const contest = useAsync(() => getContest(id), [id]);
  const data = useAsync(async () => {
    const entries = await listContestEntries(id);
    const voted = user ? await listMyVotes(user.id, entries.map((e) => e.id)) : new Set<string>();
    return { entries, voted };
  }, [id, user?.id]);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);
  const [votingId, setVotingId] = useState<string | null>(null);

  if (contest.loading) return <PageLoader />;
  if (contest.error) return <div className="section py-16"><ErrorNote message={contest.error} onRetry={contest.reload} /></div>;
  const c = contest.data;
  if (!c) {
    return (
      <div className="section py-20 text-center">
        <p className="text-lg font-semibold text-ink-700">Contest not found</p>
        <Link to={{ name: 'contests' }} className="btn-primary mt-4">Back to contests</Link>
      </div>
    );
  }

  const entries = data.data?.entries ?? [];
  const voted = data.data?.voted ?? new Set<string>();
  const expired = new Date(c.deadline).getTime() <= Date.now();
  const canEnter = c.status === 'open' && !expired;
  const canVote = c.status === 'open' || c.status === 'voting';
  const isTutor = profile?.role === 'tutor';
  const myEntry = entries.find((e) => e.tutorId === user?.id);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    try {
      await createContestEntry(c.id, user.id, title, description);
      toast.success('Your entry has been submitted!');
      setTitle(''); setDescription('');
      data.reload(); contest.reload();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const vote = async (entryId: string) => {
    if (!user) return navigate({ name: 'login', next: `/contests/${c.id}` });
    setVotingId(entryId);
    try {
      await setVote(user.id, entryId, !voted.has(entryId));
      data.reload();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setVotingId(null);
    }
  };

  return (
    <div className="section py-8">
      <Link to={{ name: 'contests' }} className="btn-ghost -ml-3 mb-6"><ArrowLeft className="h-4 w-4" /> Back to contests</Link>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <div className="card p-6">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip bg-ink-100 text-ink-700">{c.category}</span>
              <span className={`chip capitalize ${c.status === 'completed' ? 'bg-ink-200 text-ink-600' : 'bg-brand-100 text-brand-700'}`}>{c.status}</span>
            </div>
            <h1 className="mt-3 font-display text-2xl font-extrabold tracking-tight text-ink-900 sm:text-3xl">{c.title}</h1>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-ink-500"><Building2 className="h-4 w-4" /> {c.sponsor}</p>
            <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-ink-600">{c.description}</p>
            <div className="mt-6 grid grid-cols-3 gap-3">
              <div className="rounded-xl bg-ink-50 p-3 text-center"><Trophy className="mx-auto h-4 w-4 text-brand-600" /><p className="mt-1 font-bold text-brand-600">{money(c.prize)}</p><p className="text-[10px] uppercase tracking-wide text-ink-400">Prize</p></div>
              <div className="rounded-xl bg-ink-50 p-3 text-center"><Clock className="mx-auto h-4 w-4 text-brand-600" /><p className="mt-1 text-sm font-bold text-ink-900">{timeLeft(c.deadline)}</p><p className="text-[10px] uppercase tracking-wide text-ink-400">{formatDate(c.deadline)}</p></div>
              <div className="rounded-xl bg-ink-50 p-3 text-center"><ThumbsUp className="mx-auto h-4 w-4 text-brand-600" /><p className="mt-1 font-bold text-ink-900">{c.entriesCount}</p><p className="text-[10px] uppercase tracking-wide text-ink-400">Entries</p></div>
            </div>
          </div>

          <div>
            <h2 className="font-display text-xl font-bold text-ink-900">Entries</h2>
            <div className="mt-4 space-y-4">
              {data.loading ? <Spinner /> : data.error ? <ErrorNote message={data.error} onRetry={data.reload} /> : entries.length === 0 ? (
                <EmptyState icon={<Trophy />} title="No entries yet" text={canEnter ? 'Be the first tutor to enter.' : undefined} />
              ) : entries.map((e, i) => (
                <div key={e.id} className="card p-5">
                  <div className="flex items-start gap-3">
                    <Avatar name={e.tutorName} size={40} />
                    <div className="min-w-0 flex-1">
                      <p className="font-display font-bold text-ink-900">{e.title}</p>
                      <p className="text-xs text-ink-400"><Link to={{ name: 'tutor', id: e.tutorId }} className="hover:text-brand-600">{e.tutorName}</Link> · {timeAgo(e.createdAt)}{c.status === 'completed' && i === 0 && e.votes > 0 && ' · 🏆 Winner'}</p>
                    </div>
                    {canVote && e.tutorId !== user?.id ? (
                      <button onClick={() => vote(e.id)} disabled={votingId !== null} aria-pressed={voted.has(e.id)} className={`chip py-2 ${voted.has(e.id) ? 'bg-brand-500 text-white' : 'bg-brand-50 text-brand-700 hover:bg-brand-100'} disabled:opacity-60`}>
                        {votingId === e.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <ThumbsUp className="h-3 w-3" />} {e.votes}
                      </button>
                    ) : <span className="chip bg-ink-100 text-ink-600"><ThumbsUp className="h-3 w-3" /> {e.votes}</span>}
                  </div>
                  <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-ink-600">{e.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <div className="card p-6 lg:sticky lg:top-32">
            <h3 className="font-display font-bold text-ink-900">Enter this contest</h3>
            {!canEnter ? (
              <p className="mt-2 text-sm text-ink-500">This contest is no longer accepting entries.</p>
            ) : !user ? (
              <>
                <p className="mt-2 text-sm text-ink-500">Log in with a tutor account to submit an entry.</p>
                <button onClick={() => navigate({ name: 'login', next: `/contests/${c.id}` })} className="btn-primary mt-4 w-full">Log in</button>
              </>
            ) : !isTutor ? (
              <p className="mt-2 text-sm text-ink-500">Only tutors can enter. You can still vote for your favourite entry.</p>
            ) : myEntry ? (
              <p className="mt-2 text-sm text-ink-500">You've already entered: <span className="font-semibold text-ink-800">{myEntry.title}</span></p>
            ) : (
              <form onSubmit={submit} className="mt-3 space-y-3">
                <input className="input" placeholder="Entry title" maxLength={120} value={title} onChange={(e) => setTitle(e.target.value)} aria-label="Entry title" />
                <textarea className="input resize-none" rows={5} maxLength={3000} placeholder="Describe your lesson plan or material (at least 10 characters)" value={description} onChange={(e) => setDescription(e.target.value)} aria-label="Entry description" />
                <button type="submit" disabled={busy || title.trim().length < 3 || description.trim().length < 10} className="btn-primary w-full disabled:opacity-50">
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Submit entry
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
