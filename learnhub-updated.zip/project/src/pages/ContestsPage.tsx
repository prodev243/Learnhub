import { useMemo, useState } from 'react';
import { Award, Search, Trophy, Users } from 'lucide-react';
import { useAsync } from '@/hooks';
import { listContests } from '@/lib/api';
import { ContestCard } from '@/components/cards';
import { EmptyState, ErrorNote, SectionHeader, Spinner } from '@/components/ui';
import { CATEGORIES, type Category } from '@/types';

export function ContestsPage() {
  const contests = useAsync(() => listContests(), []);
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState<Category | 'all'>('all');
  const [status, setStatus] = useState<'all' | 'open' | 'voting' | 'completed'>('all');

  const filtered = useMemo(() => (contests.data ?? []).filter((c) => {
    if (cat !== 'all' && c.category !== cat) return false;
    if (status !== 'all' && c.status !== status) return false;
    const q = query.trim().toLowerCase();
    return !q || c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q);
  }), [contests.data, query, cat, status]);

  return (
    <div className="section py-10">
      <SectionHeader eyebrow="Learning contests" title="Compete. Win prizes. Get discovered." subtitle="Tutors submit their best lesson plans and teaching materials. The community votes. Winners earn prizes." />

      <div className="card mt-8 p-4">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search contests…" aria-label="Search contests" className="input pl-10" />
          </div>
          <div className="flex flex-wrap gap-2">
            <select value={cat} onChange={(e) => setCat(e.target.value as Category | 'all')} aria-label="Category" className="input w-auto py-2.5">
              <option value="all">All categories</option>
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={status} onChange={(e) => setStatus(e.target.value as typeof status)} aria-label="Status" className="input w-auto py-2.5">
              <option value="all">All statuses</option><option value="open">Open</option><option value="voting">Voting</option><option value="completed">Completed</option>
            </select>
          </div>
        </div>
      </div>

      {contests.loading ? <Spinner /> : contests.error ? <div className="mt-6"><ErrorNote message={contests.error} onRetry={contests.reload} /></div> : (
        <>
          <p className="mt-6 text-sm text-ink-500">{filtered.length} {filtered.length === 1 ? 'contest' : 'contests'} found</p>
          {filtered.length > 0 ? (
            <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{filtered.map((c) => <ContestCard key={c.id} contest={c} />)}</div>
          ) : (
            <div className="mt-6"><EmptyState icon={<Trophy />} title={(contests.data ?? []).length === 0 ? 'No contests yet' : 'No contests match your filters'} text={(contests.data ?? []).length === 0 ? 'New contests are announced here. Check back soon.' : undefined} /></div>
          )}
        </>
      )}

      <div className="card mt-16 bg-gradient-to-br from-brand-50 to-sky-50 p-8">
        <h2 className="font-display text-2xl font-extrabold text-ink-900">How contests work</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[
            { icon: Trophy, title: 'A contest is announced', text: 'A school, company, or LearnHub itself posts a challenge with a prize.' },
            { icon: Users, title: 'Tutors submit entries', text: 'Tutors submit their best lesson plans, tutorials, or curricula.' },
            { icon: Award, title: 'The community votes', text: 'Everyone can vote once per entry. The most-voted entry wins.' },
          ].map((step, i) => (
            <div key={step.title} className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-sky-500 font-bold text-white">{i + 1}</span>
              <div><h3 className="font-semibold text-ink-900">{step.title}</h3><p className="mt-1 text-sm text-ink-500">{step.text}</p></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
