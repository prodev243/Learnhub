import { ArrowRight, FolderOpen } from 'lucide-react';
import { Link } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useSaved } from '@/context/SavedContext';
import { useAsync } from '@/hooks';
import { listMissionsByIds, listSavedIds, listTutorsByIds } from '@/lib/api';
import { MissionCard, TutorCard } from '@/components/cards';
import { EmptyState, ErrorNote, SectionHeader, Spinner } from '@/components/ui';

export function SavedPage() {
  const { user } = useAuth();
  const { version } = useSaved();
  const saved = useAsync(async () => {
    const [mIds, tIds] = await Promise.all([listSavedIds(user!.id, 'mission'), listSavedIds(user!.id, 'tutor')]);
    const [missions, tutors] = await Promise.all([listMissionsByIds(mIds), listTutorsByIds(tIds)]);
    return { missions, tutors };
  }, [user?.id, version]);

  const missions = saved.data?.missions ?? [];
  const tutors = saved.data?.tutors ?? [];

  return (
    <div className="section py-10">
      <SectionHeader eyebrow="Saved" title="Your bookmarks" subtitle="Goals and tutors you saved for later." />

      {saved.loading && !saved.data ? <Spinner /> : saved.error ? <div className="mt-8"><ErrorNote message={saved.error} onRetry={saved.reload} /></div> : missions.length === 0 && tutors.length === 0 ? (
        <div className="mt-10">
          <EmptyState icon={<FolderOpen />} title="Nothing saved yet" text="Tap the bookmark on any goal or tutor to keep it here."
            action={<div className="flex gap-3"><Link to={{ name: 'missions' }} className="btn-primary">Browse missions <ArrowRight className="h-4 w-4" /></Link><Link to={{ name: 'tutors' }} className="btn-secondary">Find tutors</Link></div>} />
        </div>
      ) : (
        <>
          {missions.length > 0 && (
            <section className="mt-8">
              <h2 className="font-display text-xl font-bold text-ink-900">Saved missions</h2>
              <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{missions.map((m) => <MissionCard key={m.id} mission={m} />)}</div>
            </section>
          )}
          {tutors.length > 0 && (
            <section className="mt-10">
              <h2 className="font-display text-xl font-bold text-ink-900">Saved tutors</h2>
              <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{tutors.map((t) => <TutorCard key={t.id} tutor={t} />)}</div>
            </section>
          )}
        </>
      )}
    </div>
  );
}
