import { useEffect, useState, type FormEvent } from 'react';
import { GraduationCap, Loader2, MailCheck, School, UserRound } from 'lucide-react';
import { Link, useNav } from '@/nav';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { errorMessage } from '@/lib/format';
import type { Role } from '@/types';

export function AuthPage({ mode, next, initialRole }: { mode: 'login' | 'signup'; next?: string; initialRole?: Role }) {
  const { user, profile, signIn, signUp } = useAuth();
  const { navigateToPath } = useNav();
  const toast = useToast();

  const [role, setRole] = useState<Role>(initialRole ?? 'student');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmEmail, setConfirmEmail] = useState(false);

  // Already signed in (or just signed in): move on.
  useEffect(() => {
    if (user && profile) {
      navigateToPath(next ?? (profile.role === 'tutor' ? '/account' : '/dashboard'));
    }
  }, [user, profile, next, navigateToPath]);

  useEffect(() => { setError(null); }, [mode]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (mode === 'signup') {
      if (fullName.trim().length < 2) return setError('Please enter your full name.');
      if (password.length < 8) return setError('Password must be at least 8 characters.');
      if (!agree) return setError('Please accept the Terms of Service and Privacy Policy.');
    }
    setBusy(true);
    try {
      if (mode === 'login') {
        await signIn(email, password);
        toast.success('Welcome back!');
      } else {
        const { needsConfirmation } = await signUp({ email, password, fullName, role });
        if (needsConfirmation) setConfirmEmail(true);
        else toast.success('Your account is ready.');
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  if (confirmEmail) {
    return (
      <div className="section flex min-h-[60vh] flex-col items-center justify-center py-16 text-center">
        <span className="grid h-16 w-16 place-items-center rounded-2xl bg-brand-500 text-white shadow-glow"><MailCheck className="h-8 w-8" /></span>
        <h1 className="mt-6 font-display text-3xl font-extrabold text-ink-900">Check your email</h1>
        <p className="mx-auto mt-3 max-w-md text-ink-500">
          We sent a confirmation link to <span className="font-semibold text-ink-800">{email}</span>. Open it to activate your account, then log in.
        </p>
        <Link to={{ name: 'login', next }} className="btn-primary mt-8">Go to log in</Link>
        <p className="mt-4 text-xs text-ink-400">Nothing arrived? Check your spam folder.</p>
      </div>
    );
  }

  const isSignup = mode === 'signup';
  return (
    <div className="section py-12">
      <div className="mx-auto max-w-md">
        <div className="text-center">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-sky-500 text-white shadow-glow"><GraduationCap className="h-6 w-6" /></span>
          <h1 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-ink-900">{isSignup ? 'Create your account' : 'Welcome back'}</h1>
          <p className="mt-2 text-sm text-ink-500">{isSignup ? 'Join LearnHub as a student or a tutor.' : 'Log in to continue to LearnHub.'}</p>
        </div>

        <form onSubmit={submit} className="card mt-8 space-y-5 p-6 sm:p-8" noValidate>
          {isSignup && (
            <div>
              <p className="label">I want to…</p>
              <div className="mt-2 grid grid-cols-2 gap-3">
                {([
                  { value: 'student' as Role, title: 'Learn', text: 'Post goals, hire tutors', icon: UserRound },
                  { value: 'tutor' as Role, title: 'Teach', text: 'Send proposals, get paid', icon: School },
                ]).map((o) => (
                  <button
                    key={o.value}
                    type="button"
                    onClick={() => setRole(o.value)}
                    aria-pressed={role === o.value}
                    className={`rounded-xl border-2 p-3 text-left transition ${role === o.value ? 'border-brand-500 bg-brand-50' : 'border-ink-100 hover:border-brand-200'}`}
                  >
                    <o.icon className={`h-5 w-5 ${role === o.value ? 'text-brand-600' : 'text-ink-400'}`} />
                    <p className="mt-1.5 text-sm font-semibold text-ink-900">{o.title}</p>
                    <p className="text-xs text-ink-500">{o.text}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {isSignup && (
            <div>
              <label htmlFor="fullName" className="label">Full name</label>
              <input id="fullName" className="input mt-2" autoComplete="name" value={fullName} onChange={(e) => setFullName(e.target.value)} maxLength={80} required />
            </div>
          )}

          <div>
            <label htmlFor="email" className="label">Email</label>
            <input id="email" type="email" className="input mt-2" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="password" className="label">Password</label>
              {!isSignup && <Link to={{ name: 'forgot' }} className="text-xs font-medium text-brand-600 hover:underline">Forgot password?</Link>}
            </div>
            <input
              id="password" type="password" className="input mt-2" required
              autoComplete={isSignup ? 'new-password' : 'current-password'}
              value={password} onChange={(e) => setPassword(e.target.value)}
              placeholder={isSignup ? 'At least 8 characters' : undefined}
            />
          </div>

          {isSignup && (
            <label className="flex cursor-pointer items-start gap-2 text-sm text-ink-600">
              <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} className="mt-0.5 h-4 w-4 rounded accent-brand-500" />
              <span>I agree to the <Link to={{ name: 'terms' }} className="font-medium text-brand-600 hover:underline">Terms of Service</Link> and <Link to={{ name: 'privacy' }} className="font-medium text-brand-600 hover:underline">Privacy Policy</Link>.</span>
            </label>
          )}

          {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{error}</p>}

          <button type="submit" disabled={busy || !email || !password} className="btn-primary w-full disabled:opacity-60">
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} {isSignup ? 'Create account' : 'Log in'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-ink-500">
          {isSignup ? 'Already have an account? ' : 'New to LearnHub? '}
          <Link to={isSignup ? { name: 'login', next } : { name: 'signup', next }} className="font-semibold text-brand-600 hover:underline">
            {isSignup ? 'Log in' : 'Create an account'}
          </Link>
        </p>
      </div>
    </div>
  );
}
