import { useMemo, useState } from 'react';
import {
  ArrowLeft, ArrowRight, BookOpen, Brain, Check, Eye, Heart, Rocket, RefreshCw, Sparkles, Target, Users, Zap,
} from 'lucide-react';
import { useNav } from '@/nav';
import { useAsync } from '@/hooks';
import { listAllTutors } from '@/lib/api';
import { TutorCard } from '@/components/cards';
import { EmptyState, ErrorNote, Spinner } from '@/components/ui';
import type { Category, Tutor } from '@/types';

interface Question {
  id: string;
  question: string;
  subtitle?: string;
  options: { value: string; label: string; icon?: typeof Target }[];
}

const questions: Question[] = [
  {
    id: 'goal', question: 'What do you want to learn?', subtitle: 'Pick the area closest to your goal.',
    options: [
      { value: 'Languages', label: 'A language', icon: Sparkles },
      { value: 'Programming', label: 'Programming & tech', icon: Zap },
      { value: 'Math', label: 'Math & science', icon: Brain },
      { value: 'Music', label: 'Music', icon: Heart },
      { value: 'Design', label: 'Design & creative', icon: Target },
      { value: 'Exam Prep', label: 'Exam preparation', icon: BookOpen },
      { value: 'Business', label: 'Business & career', icon: Users },
    ],
  },
  {
    id: 'style', question: 'How do you learn best?', subtitle: 'There is no wrong answer — this shapes how we rank your matches.',
    options: [
      { value: 'visual', label: 'Visual — diagrams, demos, videos', icon: Eye },
      { value: 'hands-on', label: 'Hands-on — build and do', icon: Zap },
      { value: 'structured', label: 'Structured — plans and steps', icon: BookOpen },
      { value: 'conversational', label: 'Conversational — talk it through', icon: Users },
    ],
  },
  {
    id: 'pace', question: 'What kind of teacher brings out your best?',
    options: [
      { value: 'strict', label: 'Strict & accountable' },
      { value: 'flexible', label: 'Flexible & patient' },
      { value: 'challenging', label: 'Challenging & demanding' },
      { value: 'encouraging', label: 'Warm & encouraging' },
    ],
  },
  {
    id: 'format', question: 'What format do you prefer?',
    options: [
      { value: 'video', label: 'Live video lessons' },
      { value: 'text', label: 'Text & written feedback' },
      { value: 'exercises', label: 'Exercises & quizzes' },
      { value: 'projects', label: 'Real projects' },
    ],
  },
];

/** Words in a tutor's profile that suggest they fit each answer. */
const KEYWORDS: Record<string, string[]> = {
  visual: ['visual', 'diagram', 'demo', 'video', 'slides', 'illustrat'],
  'hands-on': ['hands-on', 'project', 'build', 'practical', 'practice', 'real-world'],
  structured: ['structured', 'plan', 'step', 'curriculum', 'roadmap', 'framework'],
  conversational: ['conversation', 'speaking', 'discussion', 'talk', 'dialogue'],
  strict: ['accountab', 'disciplin', 'strict', 'deadline', 'rigorous'],
  flexible: ['flexible', 'patient', 'patience', 'adapt', 'own pace'],
  challenging: ['challeng', 'advanced', 'demanding', 'stretch', 'competitive'],
  encouraging: ['encourag', 'supportive', 'confidence', 'friendly', 'warm'],
  video: ['video', 'live', 'zoom', 'online'],
  text: ['written', 'feedback', 'notes', 'essay', 'text'],
  exercises: ['exercise', 'quiz', 'drill', 'worksheet', 'mock'],
  projects: ['project', 'portfolio', 'build', 'real-world'],
};

function score(t: Tutor, answers: Record<string, string>): number {
  let s = 0;
  const cat = answers.goal as Category | undefined;
  if (cat && t.categories.includes(cat)) s += 100;
  const haystack = `${t.headline} ${t.bio} ${t.skills.join(' ')} ${t.guarantee ?? ''}`.toLowerCase();
  for (const key of ['style', 'pace', 'format']) {
    const words = KEYWORDS[answers[key]] ?? [];
    if (words.some((w) => haystack.includes(w))) s += 12;
  }
  if (t.rating != null) s += t.rating * 4;
  s += Math.min(t.reviewCount, 20) * 0.5;
  s += Math.min(t.completedProjects, 20) * 0.5;
  if (t.verified) s += 5;
  return s;
}

export function MatchPage() {
  const { navigate } = useNav();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [done, setDone] = useState(false);
  const tutors = useAsync(() => listAllTutors(), []);

  const results = useMemo(() => {
    if (!tutors.data) return [];
    const cat = answers.goal as Category | undefined;
    const pool = cat ? tutors.data.filter((t) => t.categories.includes(cat)) : tutors.data;
    return [...pool].sort((a, b) => score(b, answers) - score(a, answers)).slice(0, 6);
  }, [tutors.data, answers]);

  const select = (qid: string, value: string) => {
    setAnswers((a) => ({ ...a, [qid]: value }));
    if (step < questions.length - 1) setStep((s) => s + 1);
    else setDone(true);
  };

  const restart = () => { setDone(false); setStep(0); setAnswers({}); };

  if (done) {
    return (
      <div className="section py-10">
        <div className="text-center">
          <span className="chip mx-auto bg-brand-50 text-brand-700 ring-1 ring-brand-200"><Sparkles className="h-3.5 w-3.5" /> Your matches</span>
          <h1 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-ink-900 text-balance sm:text-4xl">
            {results.length > 0 ? `${results.length} ${results.length === 1 ? 'tutor fits' : 'tutors fit'} your goal` : 'No matching tutors yet'}
          </h1>
          <p className="mx-auto mt-3 max-w-lg text-ink-500 text-balance">
            We rank tutors by subject, how well their profile fits your learning style, and their reviews. Best match first.
          </p>
        </div>

        <div className="mt-10">
          {tutors.loading ? <Spinner label="Finding your matches…" /> : tutors.error ? <ErrorNote message={tutors.error} onRetry={tutors.reload} /> : results.length > 0 ? (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {results.map((t, i) => (
                <div key={t.id} className="relative">
                  {i === 0 && <span className="chip absolute -top-3 left-1/2 z-10 -translate-x-1/2 whitespace-nowrap bg-sky-500 text-white shadow-md"><Sparkles className="h-3 w-3" /> Best match</span>}
                  <TutorCard tutor={t} />
                </div>
              ))}
            </div>
          ) : (
            <EmptyState icon={<Users />} title="No tutors in this subject yet" text="Post your goal and tutors will come to you with proposals." />
          )}
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <button onClick={restart} className="btn-secondary"><RefreshCw className="h-4 w-4" /> Retake the quiz</button>
          <button onClick={() => navigate({ name: 'post' })} className="btn-primary"><Rocket className="h-4 w-4" /> Post a learning goal</button>
        </div>
      </div>
    );
  }

  const q = questions[step];
  const progress = ((step + 1) / questions.length) * 100;

  return (
    <div className="section py-10">
      <div className="mx-auto max-w-2xl">
        <div className="text-center">
          <span className="chip mx-auto bg-brand-50 text-brand-700 ring-1 ring-brand-200"><Sparkles className="h-3.5 w-3.5" /> Tutor Match</span>
          <h1 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-ink-900 text-balance">Tell us your goal. We'll suggest tutors.</h1>
          <p className="mt-3 text-ink-500 text-balance">Answer a few quick questions about how you learn and we'll rank the tutors who fit best.</p>
        </div>

        <div className="mt-8 flex items-center gap-3">
          <span className="text-xs font-medium text-ink-400">Question {step + 1} of {questions.length}</span>
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-ink-100"><div className="h-full rounded-full bg-brand-500 transition-all duration-500" style={{ width: `${progress}%` }} /></div>
        </div>

        <div key={q.id} className="card mt-6 animate-pop-in p-6 sm:p-8">
          <h2 className="font-display text-xl font-bold text-ink-900 sm:text-2xl">{q.question}</h2>
          {q.subtitle && <p className="mt-1.5 text-sm text-ink-500">{q.subtitle}</p>}

          <div className={`mt-6 grid gap-3 ${q.options.length > 4 ? 'sm:grid-cols-2' : ''}`}>
            {q.options.map((o) => {
              const selected = answers[q.id] === o.value;
              return (
                <button key={o.value} onClick={() => select(q.id, o.value)} className={`flex items-center gap-3 rounded-xl border-2 p-4 text-left transition-all ${selected ? 'border-brand-500 bg-brand-50 shadow-glow' : 'border-ink-100 bg-white hover:border-brand-200 hover:bg-ink-50'}`}>
                  {o.icon && <o.icon className={`h-5 w-5 shrink-0 ${selected ? 'text-brand-600' : 'text-ink-400'}`} />}
                  <span className={`text-sm font-medium ${selected ? 'text-brand-800' : 'text-ink-700'}`}>{o.label}</span>
                  {selected && <Check className="ml-auto h-5 w-5 text-brand-600" />}
                </button>
              );
            })}
          </div>

          <div className="mt-6 flex items-center justify-between">
            <button onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0} className="btn-ghost disabled:opacity-30"><ArrowLeft className="h-4 w-4" /> Back</button>
            {answers[q.id] && (
              <button onClick={() => (step < questions.length - 1 ? setStep((s) => s + 1) : setDone(true))} className="btn-secondary">
                {step < questions.length - 1 ? 'Next' : 'See matches'} <ArrowRight className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
