import { GraduationCap } from 'lucide-react';

export function SetupScreen() {
  return (
    <div className="grid min-h-screen place-items-center bg-ink-50 p-6">
      <div className="card max-w-lg p-8">
        <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-sky-500 text-white"><GraduationCap className="h-6 w-6" /></span>
        <h1 className="mt-4 font-display text-2xl font-extrabold text-ink-900">LearnHub isn't connected yet</h1>
        <p className="mt-2 text-sm text-ink-600">
          The site is missing its Supabase settings. Add these two environment variables (in a local <code className="rounded bg-ink-100 px-1">.env</code> file,
          or in your hosting dashboard) and redeploy:
        </p>
        <pre className="mt-4 overflow-x-auto rounded-xl bg-ink-900 p-4 text-xs text-ink-100">{`VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key`}</pre>
        <p className="mt-4 text-xs text-ink-400">See README.md for the full setup steps.</p>
      </div>
    </div>
  );
}
