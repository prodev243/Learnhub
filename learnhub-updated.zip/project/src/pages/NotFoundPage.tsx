import { Link } from '@/nav';

export function NotFoundPage() {
  return (
    <div className="section flex min-h-[50vh] flex-col items-center justify-center py-20 text-center">
      <p className="font-display text-6xl font-extrabold gradient-text">404</p>
      <h1 className="mt-3 font-display text-2xl font-extrabold text-ink-900">We couldn't find that page</h1>
      <p className="mt-2 text-sm text-ink-500">The link may be broken or the page may have been removed.</p>
      <Link to={{ name: 'home' }} className="btn-primary mt-6">Back to home</Link>
    </div>
  );
}
