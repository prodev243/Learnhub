import { Link } from '@/nav';
import { SUPPORT_EMAIL } from '@/lib/config';

const contact = SUPPORT_EMAIL ? `at ${SUPPORT_EMAIL}` : 'through the contact details on our website';

export function LegalPage({ kind }: { kind: 'terms' | 'privacy' }) {
  return (
    <div className="section py-12">
      <article className="mx-auto max-w-3xl space-y-6 text-sm leading-relaxed text-ink-600">
        <Link to={{ name: 'home' }} className="text-sm font-medium text-brand-600 hover:underline">← Back to home</Link>
        {kind === 'terms' ? <Terms /> : <Privacy />}
        <p className="rounded-xl bg-amber-50 p-4 text-xs text-amber-900">
          This document is a starting template and should be reviewed by a qualified lawyer before you launch.
        </p>
      </article>
    </div>
  );
}

const H = ({ children }: { children: string }) => <h2 className="pt-2 font-display text-lg font-bold text-ink-900">{children}</h2>;

function Terms() {
  return (
    <>
      <h1 className="font-display text-3xl font-extrabold text-ink-900">Terms of Service</h1>
      <p>Last updated: {new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</p>
      <H>1. What LearnHub is</H>
      <p>LearnHub is a marketplace where students post learning goals and independent tutors send proposals. LearnHub is not the employer of any tutor and does not itself provide tuition.</p>
      <H>2. Accounts</H>
      <p>You must provide accurate information, keep your password secure, and be responsible for everything done through your account. You must be 18 or older, or have a parent or guardian's permission.</p>
      <H>3. Goals, proposals and contracts</H>
      <p>When a student accepts a proposal, a contract is created between the student and the tutor, split into the milestones shown in the proposal. Students fund one milestone at a time and approve it once the work is delivered.</p>
      <H>4. Payments and fees</H>
      <p>Payments are processed by Paystack. A platform commission is deducted from each payment and the remainder is sent to the tutor's bank account through Paystack. Payment processor fees and settlement times are set by Paystack.</p>
      <H>5. Conduct</H>
      <p>Do not post unlawful, misleading, abusive or infringing content, do not attempt to move payments outside LearnHub to avoid fees, and do not interfere with the security of the service.</p>
      <H>6. Reviews and contests</H>
      <p>Only students who have completed a contract may review a tutor. Contest entries remain the work of the tutor who submitted them; by entering you allow LearnHub to display them.</p>
      <H>7. Termination</H>
      <p>We may suspend or remove accounts that breach these terms. You may stop using LearnHub at any time.</p>
      <H>8. Liability</H>
      <p>To the extent permitted by law, LearnHub is provided "as is" and is not liable for the quality of tuition or for losses arising from dealings between users.</p>
      <H>9. Contact</H>
      <p>Questions about these terms can be sent to us {contact}.</p>
    </>
  );
}

function Privacy() {
  return (
    <>
      <h1 className="font-display text-3xl font-extrabold text-ink-900">Privacy Policy</h1>
      <p>Last updated: {new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</p>
      <H>What we collect</H>
      <p>Your name, email address, role, the goals, proposals, messages, reviews and contest entries you create, and (for tutors) payout details needed to pay you.</p>
      <H>Payments</H>
      <p>Card and bank details are entered directly into Paystack and are never stored by LearnHub. For tutors, we store only the last four digits of your account number, the bank name and the Paystack payout reference.</p>
      <H>How we use it</H>
      <p>To run the service: show your public profile and goals, connect students with tutors, process payments, send account emails and keep the platform secure.</p>
      <H>Who can see what</H>
      <p>Goals, tutor profiles and reviews are public. Proposals are visible only to the tutor who sent them and the student who received them. Messages are visible only to the two people in the conversation.</p>
      <H>Service providers</H>
      <p>We use Supabase (hosting, database and authentication) and Paystack (payments). They process data on our behalf.</p>
      <H>Your choices</H>
      <p>You can update your name and profile in Account settings. To request access to, or deletion of, your data, contact us {contact}.</p>
    </>
  );
}
