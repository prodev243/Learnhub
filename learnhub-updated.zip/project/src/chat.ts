import { useCallback, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useNav } from '@/nav';
import { startConversation } from '@/lib/api';
import { errorMessage } from '@/lib/format';

/** Open (or create) a conversation with another user, sending logged-out visitors to log in first. */
export function useStartChat() {
  const { user } = useAuth();
  const toast = useToast();
  const { navigate } = useNav();
  const [busy, setBusy] = useState(false);

  const start = useCallback(async (otherUserId: string) => {
    if (!user) {
      navigate({ name: 'login', next: window.location.pathname });
      return;
    }
    if (otherUserId === user.id) return;
    setBusy(true);
    try {
      const id = await startConversation(otherUserId);
      navigate({ name: 'messages', id });
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }, [user, navigate, toast]);

  return { start, busy };
}
