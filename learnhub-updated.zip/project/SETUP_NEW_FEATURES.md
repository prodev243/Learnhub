# LearnHub — new feature setup

## 1. Supabase SQL

Run in this order:

1. `supabase/migrations/20260919000000_init.sql` (if your project already has it, do not rerun it).
2. `supabase/migrations/20260921000000_launch_hardening.sql`.

Then create your first admin:

```sql
insert into public.app_admins(user_id)
values ('YOUR_AUTH_USER_UUID')
on conflict do nothing;
```

## 2. Deploy Edge Functions

```bash
supabase functions deploy paystack-init
supabase functions deploy paystack-verify
supabase functions deploy paystack-banks
supabase functions deploy paystack-subaccount
supabase functions deploy paystack-webhook --no-verify-jwt
supabase functions deploy paystack-refund
supabase functions deploy delete-account
supabase functions deploy send-notification-emails
```

## 3. Paystack secrets

Test mode:

```bash
supabase secrets set PAYSTACK_SECRET_KEY=sk_test_xxxxx PAYSTACK_CURRENCY=NGN
```

Production later:

```bash
supabase secrets set PAYSTACK_SECRET_KEY=sk_live_xxxxx PAYSTACK_CURRENCY=NGN
```

The website must use the matching `pk_test_...` or `pk_live_...` value in `VITE_PAYSTACK_PUBLIC_KEY`.

## 4. Paystack dashboard

Configure:

- Test webhook: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/paystack-webhook`
- Live webhook: the same path after switching the Paystack dashboard to live configuration
- Complete Paystack business verification/KYC before live transactions
- Confirm your settlement bank/account
- Confirm tutor subaccount setup
- Confirm your processing-fee/bearer decision
- Keep refunds available to an authorized LearnHub admin

## 5. Email provider

Set:

```bash
supabase secrets set RESEND_API_KEY=re_xxxxx RESEND_FROM_EMAIL="LearnHub <notifications@yourdomain.com>" APP_ORIGIN=https://yourdomain.com
```

Deploy the email worker and schedule it every few minutes. Do not expose the Resend API key in Vite environment variables.

## 6. Focused launch

Set a single category in the frontend environment, for example:

```env
VITE_LAUNCH_CATEGORY=Programming
```

The default is blank, which keeps all categories available.

## 7. Account deletion

The current workflow anonymizes the user's profile and disables future sign-ins while retaining records needed for financial/accounting/dispute purposes. Review your local privacy/legal obligations and update the legal pages before launch.

## 8. Testing

Use `docs-PAYSTACK_TEST_MATRIX.md` for the payment test cases. Test at least:

- successful payment;
- duplicate clicks;
- popup cancellation;
- network loss after success;
- webhook-only confirmation;
- amount/currency tampering;
- Paystack failure;
- duplicate verification;
- refund;
- repeated refund;
- dispute;
- account anonymization;
- avatar access from another account;
- non-admin access to the admin dashboard.
