# LearnHub Paystack test matrix

Run these tests with Paystack **test keys** and a test webhook. Never use live money for this checklist.

## Happy path

1. Student funds milestone 1 → transaction succeeds → payment is `success` → milestone is `funded`.
2. Student approves delivered milestone → milestone is `released`.
3. Student funds milestone 2 → previous milestone is already released.
4. Paystack webhook arrives after the browser is closed → milestone still becomes funded.

## Browser/network edge cases

- Double-click **Fund this milestone**.
- Refresh while Paystack popup is open.
- Close popup after card authorization.
- Lose internet immediately after Paystack success.
- Browser reports success twice.
- Verify the same reference twice.
- Verify a reference belonging to another payer.
- Use a malformed reference.

Expected: at most one successful payment per milestone; duplicate attempts are recorded as `duplicate` or `abandoned`, never as a second funded milestone.

## Amount/currency tampering

- Change the amount sent from the browser.
- Change currency in the client request.
- Try to verify a valid reference with the wrong amount.

Expected: server-side milestone amount wins; mismatches are rejected and the milestone remains unfunded.

## Paystack failures

- Card declined.
- Transaction abandoned.
- Paystack API timeout during initialization.
- Paystack initialization succeeds but the client loses the response.
- Webhook delivery is retried.

Expected: failed/abandoned payments can be retried safely and no stale `pending` payment blocks the milestone.

## Payout/split checks

For every successful payment, inspect Paystack Dashboard → Transactions and confirm:

- The expected subaccount received the tutor share.
- LearnHub received the configured commission.
- The configured bearer/processing-fee choice matches your business decision.
- The currency matches LearnHub's configured currency.

## Refund/dispute checks

- Open a dispute on a funded/in-review milestone.
- Confirm both contract parties can see the dispute but regular users cannot see unrelated disputes.
- Admin resolves without refund.
- Admin issues a full refund.
- Admin attempts the same refund twice.
- Admin attempts a partial refund larger than the original payment.
- Refund API failure leaves the payment marked `failed` for the refund operation, not falsely `refunded`.

## Production-only checks before live mode

- Complete Paystack business/KYC requirements.
- Configure the **Live** webhook URL.
- Replace `PAYSTACK_SECRET_KEY` with the live secret in Supabase secrets.
- Replace `VITE_PAYSTACK_PUBLIC_KEY` with the live public key in the hosting provider.
- Confirm your settlement bank/subaccount setup.
- Confirm refund policy and who is authorized to issue refunds.
- Run one controlled low-value live transaction before public launch.
