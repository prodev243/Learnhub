# LearnHub

A project-based learning marketplace. Students post learning goals, tutors send proposals, and the student pays **one milestone at a time** through Paystack. Every payment is **split automatically by Paystack**: the tutor's share goes to their bank account and your commission stays in your Paystack account.

Stack: React + TypeScript + Vite + Tailwind · Supabase (Postgres, Auth, Edge Functions) · Paystack.

---

## How the payment split works

1. A tutor adds their bank details in **Account settings**. The browser sends them to the `paystack-subaccount` edge function, which creates a **Paystack subaccount** and stores only the subaccount code + last 4 digits in Supabase (`tutor_payout_accounts`).
2. When a student clicks **Fund this milestone**, the `paystack-init` edge function reads the milestone amount and the tutor's subaccount code **from Supabase** (never from the browser) and starts a Paystack transaction with:
   - `subaccount` = the tutor's subaccount
   - `transaction_charge` = your commission (from `app_config.commission_percent`), which stays with your account
3. The student pays in the Paystack popup. The `paystack-verify` function (and the `paystack-webhook` as a safety net) confirm the payment with Paystack, check the amount and currency, and mark the milestone **funded**.
4. Paystack settles the tutor's share to their bank on its normal settlement schedule.

Because Paystack pays the tutor at payment time, the student protects themselves by funding **one milestone at a time** and approving the work before funding the next. LearnHub does not hold funds and does not offer refunds automatically.

---

## 1. Supabase setup

1. Create a project at supabase.com.
2. **SQL Editor** → paste all of `supabase/migrations/20260919000000_init.sql` → Run. (Run it once, on an empty project.)
3. **Authentication → URL Configuration**
   - *Site URL*: your live website URL (e.g. `https://learnhub.example`)
   - *Redirect URLs*: add the same URL, plus `http://localhost:5173` for local testing.
4. **Authentication → Providers → Email**: keep "Confirm email" **on** for production.
5. **Authentication → SMTP**: configure your own SMTP provider before launch. Supabase's built-in email sender is heavily rate-limited and is meant for testing only.
6. **Project Settings → API**: copy the **Project URL** and the **anon / publishable key**.

## 2. Paystack setup

1. Paystack Dashboard → **Settings → API Keys & Webhooks**. Copy your **test** keys (`pk_test_…`, `sk_test_…`).
2. Set the **Test Webhook URL** to: `https://<your-project-ref>.supabase.co/functions/v1/paystack-webhook`
3. Your currency is set to **NGN**. Paystack also supports GHS, ZAR, KES and USD depending on your account.

## 3. Deploy the server functions

Install the Supabase CLI (`npm i -g supabase`), then from the project folder:

```bash
supabase login
supabase link --project-ref <your-project-ref>

# Secrets live ONLY on the server. Never put these in the website's .env file.
supabase secrets set PAYSTACK_SECRET_KEY=sk_test_xxxxxxxx PAYSTACK_CURRENCY=NGN

supabase functions deploy paystack-init
supabase functions deploy paystack-verify
supabase functions deploy paystack-banks
supabase functions deploy paystack-subaccount
supabase functions deploy paystack-webhook --no-verify-jwt
```

## 4. Run the website

```bash
cp .env.example .env      # then fill in the values
npm install
npm run typecheck
npm run build
npm run dev               # local
```

Environment variables (`.env` locally, and in your host's dashboard for production):

| Variable | Value |
| --- | --- |
| `VITE_SUPABASE_URL` | Project URL |
| `VITE_SUPABASE_ANON_KEY` | anon / publishable key |
| `VITE_PAYSTACK_PUBLIC_KEY` | `pk_test_…` (only used to show the "test mode" banner) |
| `VITE_CURRENCY` | `NGN` (must equal `PAYSTACK_CURRENCY`) |
| `VITE_SUPPORT_EMAIL` | optional, shown in the footer |

Deploy the `dist` folder to Vercel, Netlify or Cloudflare Pages. `vercel.json` and `public/_redirects` are included so page refreshes and deep links work.

**Never** put the Supabase `service_role` key or Paystack `sk_` key in a `VITE_` variable — those are published to every visitor.

---

## 5. Admin tasks (Supabase → SQL Editor)

```sql
-- Give a tutor the "Verified" badge
update public.tutor_profiles set verified = true where user_id = '<user-id>';

-- Create a contest
insert into public.contests (title, sponsor, category, prize, description, deadline, status)
values ('Best IELTS lesson plan', 'LearnHub', 'Languages', 50000,
        'Share your best speaking lesson plan.', now() + interval '14 days', 'open');

-- Move a contest to voting / completed
update public.contests set status = 'voting' where id = '<contest-id>';

-- Change your commission (percent kept by you). Applies to every new payment immediately.
update public.app_config set value = '10' where key = 'commission_percent';
```

---

## 6. Test checklist (Paystack **test** mode)

Use two browsers (or one normal + one private window).

1. **Tutor**: sign up as *Teach* → confirm email → Account settings → fill the public profile → add bank details.
2. **Student**: sign up as *Learn* → Post a goal.
3. **Tutor**: open the goal → send a proposal with 2 milestones. The fee preview should show your commission.
4. **Student**: open the goal → Accept & start contract → Dashboard → **Fund this milestone**. Pay with the Paystack test card `4084 0840 8408 4081`, any future expiry, CVV `408`.
5. Check Paystack Dashboard → Transactions: the payment should show the split (subaccount + your share).
6. **Tutor**: Mark as delivered → **Student**: Approve → fund milestone 2 → approve → the contract completes → leave a review.
7. Try: messages, save/bookmark, invite a tutor, contest voting, password reset, log out / log in.

If Paystack test mode rejects the bank details, use the test bank account details from Paystack's documentation.

## 7. Before you switch to live payments

- [ ] Complete Paystack business verification and switch to `pk_live_` / `sk_live_` (update Supabase secrets **and** the site's `VITE_PAYSTACK_PUBLIC_KEY`; set the **Live** webhook URL).
- [ ] Decide who bears Paystack's processing fee. It is currently your account (`bearer: 'account'` in `supabase/functions/paystack-init/index.ts`); change to `'subaccount'` to deduct it from the tutor's share.
- [ ] Set up custom SMTP in Supabase and customise the auth email templates.
- [ ] Have a lawyer review `Terms` and `Privacy` (`src/pages/LegalPage.tsx`). They are templates.
- [ ] Decide your refund/dispute process — there is no automated refund flow.
- [ ] Enable Supabase backups (Pro plan) and review the Security Advisor.
- [ ] Add your own domain in Supabase Auth URL settings.

## Security summary

- Row Level Security is enabled on every table; the browser can only write the specific columns it needs.
- Contract, milestone and payment state changes only through server-side SQL functions or edge functions.
- Payment amounts and the tutor split are read from the database on the server, and payments are verified with Paystack (plus HMAC signature on webhooks) before a milestone is funded.
- Bank account numbers are never stored — only the Paystack subaccount code and last 4 digits.

---

## Production additions in this release

This release adds:

- Admin dashboard with marketplace metrics, tutor verification queue, disputes and payment refunds.
- Refund records and a dispute workflow for milestone problems.
- In-app notifications plus an email queue for transactional notifications.
- Paystack refund Edge Function and stronger payment initialization cleanup.
- Profile photo uploads using a Supabase Storage `avatars` bucket.
- Tutor verification states (`unsubmitted`, `pending`, `approved`, `rejected`).
- Analytics event tracking in `analytics_events`.
- Account anonymization/deletion handling that protects historical financial records.
- Basic gamification points and badges.
- Optional narrow-launch category using `VITE_LAUNCH_CATEGORY`.
- A Paystack edge-case test matrix in `docs-PAYSTACK_TEST_MATRIX.md`.

### Important: your SQL work

This project uses **Supabase/Postgres**, not Firebase. If your existing SQL work was done in Supabase's SQL Editor, run the new migration after the original migration:

```text
supabase/migrations/20260921000000_launch_hardening.sql
```

Do not run it before the original `20260919000000_init.sql`.

If you already manually created some of these tables/columns, the migration uses `if not exists` for most additions, but review conflicts before running it on a non-standard schema.

### First admin account

After your own user account exists, copy its Auth user UUID and run this once in Supabase SQL Editor:

```sql
insert into public.app_admins(user_id)
values ('YOUR_AUTH_USER_UUID')
on conflict do nothing;
```

Then reload LearnHub. The **Admin dashboard** appears in your account menu.

### Email notifications

The app now creates an in-app notification and an email job for important events. To send the queued emails, configure a transactional provider such as Resend in Supabase Edge Function secrets:

```bash
supabase secrets set RESEND_API_KEY=re_xxxxx RESEND_FROM_EMAIL="LearnHub <notifications@yourdomain.com>" APP_ORIGIN=https://yourdomain.com
```

Deploy:

```bash
supabase functions deploy send-notification-emails
```

The email worker is intentionally separate from the user-facing app. Schedule it every few minutes using your preferred scheduler/cron and call the authenticated Edge Function. Do not expose the Resend key in the frontend.

Before launch, verify your sender domain with your email provider and use an address on your own domain.

### Tutor verification

Tutors can request verification from Account settings. Admins review the queue and approve/reject the request. The verified badge is not user-editable.

For your real verification policy, decide what evidence you require (for example identity, qualification or experience) and how long you retain it. Do not store identity documents in the public avatar bucket.

### Profile photos

The migration creates a public `avatars` storage bucket. Only a signed-in user can upload to their own `<user-id>/` folder. The database stores the resulting public URL.

For launch, consider adding moderation/reporting and an image-content policy before allowing arbitrary uploads at scale.

### Narrow launch focus

Set this in your hosting environment to focus discovery on one category during the first launch:

```env
VITE_LAUNCH_CATEGORY=Programming
```

Leave it blank to keep all categories visible. Choose the actual category based on your launch strategy; the code does not force a category by default.

### Account deletion/data handling

Account deletion is implemented as **anonymization** rather than blindly deleting historical records. Active contracts must be resolved first. Financial/contract records can be retained where necessary for accounting, fraud prevention and disputes.

Before launch, update the Privacy Policy and Terms to state exactly:

- what is deleted immediately;
- what is anonymized;
- what financial records are retained;
- retention periods;
- how a user can request deletion or correction.

### Analytics

Important client actions write to `analytics_events`. Start with these events and add more as the product grows:

- `mission_created`
- `proposal_created`
- `payment_attempt`

Recommended next events are `signup_completed`, `tutor_profile_published`, `verification_requested`, `contract_started`, `milestone_submitted`, `milestone_approved`, `review_created`, and `dispute_opened`.

Do not put payment card data, bank account numbers, passwords or other sensitive data in event properties.

---

## Paystack: what you still need to configure

The code changes do **not** remove the Paystack setup requirements. Before real payments:

1. Complete Paystack business/account verification.
2. Keep the test API keys while testing.
3. Configure the **Test Webhook URL** for `paystack-webhook`.
4. Before production, configure the **Live Webhook URL** separately.
5. Set the Supabase secret `PAYSTACK_SECRET_KEY` to the matching test/live secret.
6. Set the hosting variable `VITE_PAYSTACK_PUBLIC_KEY` to the matching test/live public key.
7. Confirm your settlement account and tutor subaccount configuration.
8. Decide who bears Paystack's processing fee. LearnHub currently uses `bearer: 'account'`, meaning the platform account bears that fee.
9. Decide and document your refund policy. Admins can now trigger a Paystack refund from the dashboard.
10. Run the full matrix in `docs-PAYSTACK_TEST_MATRIX.md` before changing to live mode.

### Paystack refund limitation to understand

A refund is a Paystack-side money operation. LearnHub records the refund result, but your legal/customer-support policy still determines **when** an admin should issue it. Do not automatically refund every dispute without defining the business rules.

### Payment edge cases now handled in code

- duplicate successful payment attempts for one milestone;
- repeated verification calls;
- wrong amount/currency verification;
- failed/abandoned checkout;
- Paystack initialization failure after a local payment row was created;
- webhook confirmation after the student closes the browser;
- refund amount validation and repeated-refund protection.

---

## Production checklist — expanded

- [ ] Run both Supabase migrations.
- [ ] Create the first `app_admins` row.
- [ ] Configure Supabase Auth Site URL and redirect URLs.
- [ ] Configure production SMTP/Auth emails.
- [ ] Configure Resend (or another transactional email provider) and schedule the email worker.
- [ ] Set `VITE_LAUNCH_CATEGORY` if launching with a single category.
- [ ] Complete tutor verification policy and support process.
- [ ] Review Terms and Privacy with a qualified professional.
- [ ] Define dispute response times and refund authority.
- [ ] Enable backups and review Supabase Security Advisor.
- [ ] Test all Paystack cases in the matrix.
- [ ] Test account anonymization with and without historical contracts.
- [ ] Test avatar upload permissions using two different accounts.
- [ ] Test that a non-admin cannot access admin operations.
- [ ] Test analytics contains no sensitive information.
- [ ] Switch Paystack test credentials to live only after the above is complete.
